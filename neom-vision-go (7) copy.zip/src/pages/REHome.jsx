import React, { useState, useEffect, useRef } from "react";
import RENav from "@/components/realestate/RENav";
import REFooter from "@/components/realestate/REFooter";
import { ArrowRight, ArrowUpRight, Play, Bed, Bath, Maximize, Heart, Star, ChevronLeft, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const GOLD = "#c9a76c";

const properties = [
  { title: "The Maple Grove House", type: "Single Family", price: "$1,250,000", beds: 4, baths: 3, sqft: "3,200", image: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=900&q=90", tag: "Featured" },
  { title: "Horizon Glass Villa", type: "Luxury Villa", price: "$2,800,000", beds: 5, baths: 4, sqft: "5,100", image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=900&q=90", tag: "New" },
  { title: "Urban Skyline Penthouse", type: "Penthouse", price: "$4,100,000", beds: 3, baths: 3, sqft: "2,800", image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=900&q=90", tag: "Exclusive" },
  { title: "The Cliffside Retreat", type: "Coastal Home", price: "$3,500,000", beds: 6, baths: 5, sqft: "6,400", image: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=900&q=90", tag: "Hot" },
];

const services = [
  { n: "01", title: "Architecture Design", href: "ServiceDetail", image: "https://images.unsplash.com/photo-1486325212027-8081e485255e?w=700&q=90" },
  { n: "02", title: "Interior Design", href: "ServiceDetail", image: "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=700&q=90" },
  { n: "03", title: "Landscape Planning", href: "ServiceDetail", image: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=700&q=90" },
  { n: "04", title: "3D Visualisation", href: "ServiceDetail", image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=700&q=90" },
  { n: "05", title: "Furniture Design", href: "ServiceDetail", image: "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=700&q=90" },
  { n: "06", title: "Lighting Design", href: "ServiceDetail", image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=700&q=90" },
];

const testimonials = [
  { name: "Amanda K.", role: "Homebuyer, New York", img: "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?w=120&q=90", text: "OnePack didn't just build us a house. They understood our life — how we move, gather, work, and rest — and translated it into spaces that feel bespoke." },
  { name: "David M.", role: "Property Investor", img: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&q=90", text: "The best investment decision I've ever made. They understand market value and design excellence in equal measure — a rare combination." },
  { name: "Sara L.", role: "Luxury Client, LA", img: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=120&q=90", text: "From the first consultation to handover, every step was seamless and joyful. I couldn't imagine our home any other way." },
];

function AnimatedStat({ target, suffix, label, className }) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    let start = 0;
    const duration = 1500;
    const increment = target / (duration / 16);
    const timer = setInterval(() => {
      start += increment;
      if (start >= target) { setCount(target); clearInterval(timer); }
      else setCount(Math.floor(start));
    }, 16);
    return () => clearInterval(timer);
  }, [target]);
  return (
    <div className={className}>
      <div className="font-black text-white text-2xl" style={{ letterSpacing: "-0.03em" }}>{count}{suffix}</div>
      <div className="text-white/35 text-xs font-light mt-0.5">{label}</div>
    </div>
  );
}

function HeroSlider() {
  const slides = [
    { img: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1920&q=90", label: "Beverly Hills, CA", headline: "Properties That\nCreate Community." },
    { img: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=1920&q=90", label: "Malibu Cliffs, CA", headline: "Where Design\nMeets Nature." },
    { img: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=1920&q=90", label: "Manhattan, NY", headline: "Skyline Living\nRedefined." },
  ];
  const [cur, setCur] = useState(0);
  const [animating, setAnimating] = useState(false);
  const touchStartX = useRef(0);
  const handleTouchStart = (e) => { touchStartX.current = e.touches[0].clientX; };
  const handleTouchEnd = (e) => {
    const touchEndX = e.changedTouches[0].clientX;
    if (touchStartX.current - touchEndX > 50) goTo((cur + 1) % slides.length);
    if (touchStartX.current - touchEndX < -50) goTo((cur - 1 + slides.length) % slides.length);
  };
  const goTo = (i) => { if (animating) return; setAnimating(true); setTimeout(() => { setCur(i); setAnimating(false); }, 600); };
  useEffect(() => { const t = setInterval(() => goTo((cur + 1) % slides.length), 6000); return () => clearInterval(t); }, [cur]);

  return (
    <section className="relative w-full h-screen min-h-[700px] overflow-hidden bg-black" onTouchStart={handleTouchStart} onTouchEnd={handleTouchEnd}>
      {slides.map((s, i) => (
        <div key={i} className="absolute inset-0 transition-opacity duration-700" style={{ opacity: i === cur && !animating ? 1 : 0 }}>
          <img src={s.img} alt="" className="w-full h-full object-cover" style={{ filter: "brightness(0.5)" }} />
        </div>
      ))}
      <div className="absolute inset-0" style={{ background: "linear-gradient(135deg, rgba(0,0,0,0.8) 0%, rgba(0,0,0,0.2) 50%, rgba(0,0,0,0.5) 100%)" }} />

      {/* Grain overlay */}
      <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")` }} />

      {/* Content */}
      <div className="absolute inset-0 flex flex-col justify-center px-10 md:px-24">
        <div className="mb-6 flex items-center gap-3">
          <div className="h-px w-12" style={{ background: GOLD }} />
          <span className="text-xs tracking-[0.35em] font-medium uppercase" style={{ color: GOLD }}>{slides[cur].label}</span>
        </div>
        <h1 className="font-black text-white leading-[0.88] mb-8" style={{ fontSize: "clamp(3.5rem, 8vw, 8.5rem)", letterSpacing: "-0.04em", whiteSpace: "pre-line" }}>
          {slides[cur].headline}
        </h1>
        <p className="text-white/50 font-light mb-10 max-w-md leading-relaxed" style={{ fontSize: "1.05rem" }}>
          Extraordinary properties curated for discerning buyers — where architecture, community, and lifestyle converge.
        </p>
        <div className="flex items-center gap-5">
          <Link to={createPageUrl("Portfolio")} className="group flex items-center gap-3 text-white text-sm font-semibold px-8 py-4 rounded-full transition-all hover:gap-4" style={{ background: `linear-gradient(135deg, ${GOLD}, #a07840)` }}>
            View Properties <ArrowRight className="w-4 h-4" />
          </Link>
          <button className="flex items-center gap-3 text-white/60 hover:text-white transition-colors text-sm font-light">
            <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ border: "1px solid rgba(255,255,255,0.25)" }}>
              <Play className="w-4 h-4 ml-0.5" fill="white" />
            </div>
            Watch Film
          </button>
        </div>
      </div>

      {/* Slide counter */}
      <div className="absolute bottom-10 right-10 flex items-center gap-4">
        <button onClick={() => goTo((cur - 1 + slides.length) % slides.length)} className="w-9 h-9 rounded-full border border-white/20 flex items-center justify-center text-white/50 hover:text-white hover:border-white/60 transition-all">
          <ChevronLeft className="w-4 h-4" />
        </button>
        <span className="text-white/30 text-xs font-light tracking-widest">{String(cur + 1).padStart(2, "0")} / {String(slides.length).padStart(2, "0")}</span>
        <button onClick={() => goTo((cur + 1) % slides.length)} className="w-9 h-9 rounded-full border border-white/20 flex items-center justify-center text-white/50 hover:text-white hover:border-white/60 transition-all">
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Stats bar */}
      <div className="absolute bottom-0 left-0 right-0 px-10 md:px-24 pb-10">
        <div className="flex items-stretch rounded-2xl overflow-hidden" style={{ background: "rgba(255,255,255,0.06)", backdropFilter: "blur(24px)", border: "1px solid rgba(255,255,255,0.08)", maxWidth: "520px" }}>
          {[{ v: 250, suf: "+", l: "Properties Sold" }, { v: 12, suf: " yr", l: "Of Excellence" }, { v: 98, suf: "%", l: "Satisfaction" }].map((s, i) => (
            <AnimatedStat key={i} target={s.v} suffix={s.suf} label={s.l} className={`flex-1 px-6 py-4 ${i > 0 ? "border-l border-white/10" : ""}`} />
          ))}
        </div>
      </div>
    </section>
  );
}

function ServiceRow({ s, i }) {
  const [hovered, setHovered] = useState(false);
  return (
    <Link to={createPageUrl(s.href)} onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)}
      className="group flex items-center justify-between py-7 border-b border-black/8 cursor-pointer transition-all duration-300 hover:pl-3"
      style={{ borderColor: "rgba(0,0,0,0.07)" }}>
      <div className="flex items-center gap-6">
        <span className="font-black text-4xl" style={{ color: hovered ? GOLD : "rgba(0,0,0,0.08)", letterSpacing: "-0.04em", transition: "color 0.3s", lineHeight: 1 }}>{s.n}</span>
        <span className="font-black text-gray-900 transition-all" style={{ fontSize: "clamp(1.2rem, 2.5vw, 2rem)", letterSpacing: "-0.02em" }}>{s.title}</span>
      </div>
      <div className="flex items-center gap-6">
        <div className="w-20 h-14 rounded-xl overflow-hidden transition-all duration-500" style={{ opacity: hovered ? 1 : 0, transform: hovered ? "scale(1)" : "scale(0.8)" }}>
          <img src={s.image} alt={s.title} className="w-full h-full object-cover" />
        </div>
        <div className="w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300" style={{ background: hovered ? `linear-gradient(135deg, ${GOLD}, #a07840)` : "rgba(0,0,0,0.06)" }}>
          <ArrowUpRight className="w-4 h-4" style={{ color: hovered ? "white" : "#999" }} />
        </div>
      </div>
    </Link>
  );
}

export default function REHome() {
  const [liked, setLiked] = useState({});
  const [activeTestimonial, setActiveTestimonial] = useState(0);

  return (
    <div className="bg-white text-gray-900 overflow-x-hidden" style={{ fontFamily: "'Outfit', sans-serif" }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap');`}</style>
      <RENav />

      <HeroSlider />

      {/* INTRO — editorial split */}
      <section className="bg-white">
        <div className="grid md:grid-cols-2" style={{ minHeight: "600px" }}>
          <div className="relative overflow-hidden">
            <img src="https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=900&q=90" alt="" className="w-full h-full object-cover" style={{ minHeight: "500px" }} />
            <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(0,0,0,0.5) 0%, transparent 50%)" }} />
            <div className="absolute bottom-8 left-8">
              <span className="text-white/50 text-xs tracking-widest uppercase font-light">Since 2012</span>
            </div>
          </div>
          <div className="flex flex-col justify-center px-10 md:px-16 py-20">
            <div className="flex items-center gap-3 mb-7">
              <div className="h-px w-10" style={{ background: GOLD }} />
              <span className="text-xs tracking-[0.3em] font-semibold uppercase" style={{ color: GOLD }}>About OnePack</span>
            </div>
            <h2 className="font-black text-gray-900 leading-[0.9] mb-7" style={{ fontSize: "clamp(2.2rem, 4vw, 3.8rem)", letterSpacing: "-0.03em" }}>
              We Invite You to Live<br />in a More Meaningful,<br />Vibrant Urban Space.
            </h2>
            <p className="text-gray-400 font-light leading-relaxed mb-4 max-w-md" style={{ fontSize: "0.975rem" }}>
              For over twelve years, we've matched discerning buyers with exceptional homes — guiding every step of the journey with insight, care, and expertise.
            </p>
            <p className="text-gray-400 font-light leading-relaxed mb-10 max-w-md" style={{ fontSize: "0.975rem" }}>
              Our portfolio spans luxury residences, bespoke architectural commissions, and sustainable community developments.
            </p>
            <Link to={createPageUrl("About")} className="group inline-flex items-center gap-3 font-semibold text-sm transition-all hover:gap-4" style={{ color: GOLD }}>
              Discover Our Story <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* PROPERTIES — horizontal scroll feel */}
      <section className="py-20 md:py-28 bg-black text-white">
        <div className="px-10 md:px-24 mb-14 flex items-end justify-between">
          <div>
            <div className="flex items-center gap-3 mb-5">
              <div className="h-px w-10" style={{ background: GOLD }} />
              <span className="text-xs tracking-[0.3em] font-semibold uppercase" style={{ color: GOLD }}>Portfolio</span>
            </div>
            <h2 className="font-black text-white leading-[0.9]" style={{ fontSize: "clamp(2rem, 4vw, 4rem)", letterSpacing: "-0.04em" }}>
              Featured<br />Properties
            </h2>
          </div>
          <Link to={createPageUrl("Portfolio")} className="hidden md:flex items-center gap-2 text-sm font-semibold" style={{ color: GOLD }}>
            View All <ArrowUpRight className="w-4 h-4" />
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-0 border-t border-white/8">
          {properties.map((p, i) => (
            <Link key={i} to={createPageUrl("PropertyDetail")} className="group relative overflow-hidden cursor-pointer border-r border-white/8 last:border-r-0">
              <div className="relative overflow-hidden" style={{ height: "360px" }}>
                <img src={p.image} alt={p.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" style={{ filter: "brightness(0.55)" }} />
                <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0.1) 60%)" }} />
                <div className="absolute top-5 left-5">
                  <span className="text-xs font-semibold px-3 py-1 rounded-full" style={{ background: `linear-gradient(135deg, ${GOLD}, #a07840)`, color: "white" }}>{p.tag}</span>
                </div>
                <button onClick={e => { e.preventDefault(); setLiked(l => ({ ...l, [i]: !l[i] })); }} className="absolute top-5 right-5 w-8 h-8 rounded-full flex items-center justify-center" style={{ background: "rgba(255,255,255,0.15)", backdropFilter: "blur(10px)" }}>
                  <Heart className="w-4 h-4" fill={liked[i] ? "#ef4444" : "none"} stroke={liked[i] ? "#ef4444" : "white"} />
                </button>
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <div className="text-xs font-medium tracking-widest uppercase mb-2" style={{ color: GOLD }}>{p.type}</div>
                  <h3 className="font-bold text-white text-base mb-3 leading-snug">{p.title}</h3>
                  <div className="font-black text-white text-xl mb-4" style={{ letterSpacing: "-0.02em" }}>{p.price}</div>
                  <div className="flex items-center gap-4 text-xs text-white/50 font-light border-t border-white/10 pt-3">
                    <span className="flex items-center gap-1"><Bed className="w-3 h-3" /> {p.beds}</span>
                    <span className="flex items-center gap-1"><Bath className="w-3 h-3" /> {p.baths}</span>
                    <span className="flex items-center gap-1"><Maximize className="w-3 h-3" /> {p.sqft}</span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* SERVICES — editorial list */}
      <section className="bg-white px-10 md:px-24 py-20 md:py-28">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-20 items-start">
            <div className="md:sticky" style={{ top: "120px" }}>
              <div className="flex items-center gap-3 mb-6">
                <div className="h-px w-10" style={{ background: GOLD }} />
                <span className="text-xs tracking-[0.3em] font-semibold uppercase" style={{ color: GOLD }}>What We Do</span>
              </div>
              <h2 className="font-black text-gray-900 leading-[0.9] mb-8" style={{ fontSize: "clamp(2.2rem, 4vw, 4rem)", letterSpacing: "-0.04em" }}>
                We Specialize<br />in Creating<br />Exceptional<br />Spaces
              </h2>
              <p className="text-gray-400 font-light leading-relaxed mb-10 max-w-sm" style={{ fontSize: "0.975rem" }}>
                Every project is an opportunity to redefine what extraordinary living means — from architectural vision to final detail.
              </p>
              <Link to={createPageUrl("Services")} className="group inline-flex items-center gap-3 text-white text-sm font-semibold px-7 py-3.5 rounded-full transition-all hover:opacity-90" style={{ background: `linear-gradient(135deg, ${GOLD}, #a07840)` }}>
                All Services <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
            <div className="pt-4">
              {services.map((s, i) => <ServiceRow key={i} s={s} i={i} />)}
            </div>
          </div>
        </div>
      </section>

      {/* TESTIMONIALS — cinematic */}
      <section className="relative overflow-hidden bg-black py-28">
        <img src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1920&q=90" alt="" className="absolute inset-0 w-full h-full object-cover" style={{ filter: "brightness(0.18)" }} />
        <div className="relative px-10 md:px-24 max-w-5xl mx-auto text-center">
          <div className="flex justify-center gap-1 mb-10">{Array(5).fill(0).map((_, i) => <Star key={i} className="w-5 h-5" fill={GOLD} stroke="none" />)}</div>
          <div className="relative" style={{ minHeight: "160px" }}>
            {testimonials.map((t, i) => (
              <div key={i} className="transition-all duration-500 absolute inset-0 flex flex-col items-center justify-center" style={{ opacity: i === activeTestimonial ? 1 : 0, pointerEvents: i === activeTestimonial ? "auto" : "none" }}>
                <p className="text-white font-light italic leading-relaxed mb-0" style={{ fontSize: "clamp(1.1rem, 2vw, 1.6rem)" }}>"{t.text}"</p>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-center gap-4 mt-12">
            {testimonials.map((t, i) => (
              <button key={i} onClick={() => setActiveTestimonial(i)} className="flex items-center gap-3 group transition-all">
                <img src={t.img} alt={t.name} className="rounded-full object-cover transition-all" style={{ width: i === activeTestimonial ? "52px" : "36px", height: i === activeTestimonial ? "52px" : "36px", border: i === activeTestimonial ? `2px solid ${GOLD}` : "2px solid transparent", filter: i === activeTestimonial ? "none" : "grayscale(1) brightness(0.5)" }} />
                {i === activeTestimonial && (
                  <div className="text-left">
                    <div className="text-white text-sm font-semibold">{t.name}</div>
                    <div className="text-white/40 text-xs font-light">{t.role}</div>
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* AVENGERS TEAM SECTION */}
      <section className="bg-white px-10 md:px-24 py-28 border-t border-gray-100">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="font-black text-gray-900 leading-[0.9] mb-16" style={{ fontSize: "clamp(3rem, 7vw, 7rem)", letterSpacing: "-0.04em" }}>
            Avengers
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { name: "Tom Cruise", role: "CEO & Founder", img: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&q=90" },
              { name: "Jessica Alba", role: "Head of Architecture", img: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&q=90" },
              { name: "Will Smith", role: "Lead Designer", img: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&q=90" },
              { name: "Brad Pitt", role: "Property Consultant", img: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&q=90" },
            ].map((m, i) => (
              <div key={i} className="group relative overflow-hidden bg-gray-50 rounded-lg aspect-[3/4]">
                <img src={m.img} alt={m.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 filter grayscale group-hover:grayscale-0" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="absolute bottom-0 left-0 right-0 p-6 translate-y-4 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-500 text-left">
                  <div className="font-bold text-white text-lg">{m.name}</div>
                  <div className="text-white/70 text-xs font-light tracking-wider uppercase mt-1">{m.role}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA BANNER */}
      <section className="bg-white px-10 md:px-24 py-20">
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-12 items-center">
          <h2 className="font-black text-gray-900 leading-[0.9]" style={{ fontSize: "clamp(2.5rem, 5vw, 5rem)", letterSpacing: "-0.04em" }}>
            Ready to Find<br />Your Perfect<br /><span style={{ color: GOLD }}>Home?</span>
          </h2>
          <div>
            <p className="text-gray-400 font-light leading-relaxed mb-8" style={{ fontSize: "1rem" }}>
              Our team of experts is ready to guide you through every step — from the first conversation to the day you receive your keys.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to={createPageUrl("Contact")} className="flex items-center gap-3 text-white text-sm font-semibold px-8 py-4 rounded-full" style={{ background: `linear-gradient(135deg, ${GOLD}, #a07840)` }}>
                Get In Touch <ArrowRight className="w-4 h-4" />
              </Link>
              <Link to={createPageUrl("Portfolio")} className="flex items-center gap-3 text-gray-900 text-sm font-semibold px-8 py-4 rounded-full" style={{ border: "1.5px solid rgba(0,0,0,0.15)" }}>
                Browse Properties
              </Link>
            </div>
          </div>
        </div>
      </section>

      <REFooter />
    </div>
  );
}