import React, { useState, useEffect, useRef } from "react";
import RENav from "@/components/realestate/RENav";
import REFooter from "@/components/realestate/REFooter";
import { ArrowRight, Play, Star, MapPin, BedDouble, Layers, Maximize } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion, useScroll, useTransform, useSpring, AnimatePresence } from "framer-motion";

const GOLD = "#c9a76c";

// Components
const CustomCursor = () => {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isHover, setIsHover] = useState(false);

  useEffect(() => {
    const updatePos = (e) => setMousePos({ x: e.clientX, y: e.clientY });
    const checkHover = (e) => {
      const target = e.target;
      setIsHover(target.tagName === 'BUTTON' || target.tagName === 'A' || target.closest('button') || target.closest('a') || target.closest('.cursor-hover'));
    };
    window.addEventListener("mousemove", updatePos);
    window.addEventListener("mouseover", checkHover);
    return () => { window.removeEventListener("mousemove", updatePos); window.removeEventListener("mouseover", checkHover); };
  }, []);

  return (
    <motion.div
      className="fixed top-0 left-0 w-4 h-4 rounded-full pointer-events-none z-[9999] mix-blend-difference bg-white flex items-center justify-center transform -translate-x-1/2 -translate-y-1/2 hidden md:flex"
      animate={{ x: mousePos.x, y: mousePos.y, scale: isHover ? 3.5 : 1, opacity: isHover ? 0.8 : 1 }}
      transition={{ type: "spring", stiffness: 400, damping: 30, mass: 0.5 }}
    />
  );
};

const MagneticElement = ({ children, className = "" }) => {
  const ref = useRef(null);
  const [position, setPosition] = useState({ x: 0, y: 0 });

  const handleMouse = (e) => {
    const { clientX, clientY } = e;
    const { height, width, left, top } = ref.current.getBoundingClientRect();
    const middleX = clientX - (left + width / 2);
    const middleY = clientY - (top + height / 2);
    setPosition({ x: middleX * 0.3, y: middleY * 0.3 });
  };

  return (
    <motion.div
      ref={ref}
      onMouseMove={handleMouse}
      onMouseLeave={() => setPosition({ x: 0, y: 0 })}
      animate={{ x: position.x, y: position.y }}
      transition={{ type: "spring", stiffness: 150, damping: 15, mass: 0.1 }}
      className={`inline-block ${className}`}
    >
      {children}
    </motion.div>
  );
};

const FadeIn = ({ children, delay = 0, className = "" }) => (
  <motion.div
    initial={{ opacity: 0, y: 50 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, margin: "-10%" }}
    transition={{ duration: 1, delay: delay / 1000, ease: [0.25, 1, 0.5, 1] }}
    className={className}
  >
    {children}
  </motion.div>
);

const TextReveal = ({ children, delay = 0, as: Component = "span", className = "" }) => {
  if (typeof children !== 'string') return <Component className={className}>{children}</Component>;
  const words = children.split(" ");
  return (
    <Component className={`inline-block ${className}`}>
      {words.map((word, i) => (
        <span key={i} className="inline-block overflow-hidden mr-[0.25em] pb-1">
          <motion.span
            className="inline-block"
            initial={{ y: "100%", rotate: 4 }}
            whileInView={{ y: 0, rotate: 0 }}
            viewport={{ once: true, margin: "-10%" }}
            transition={{ duration: 0.8, delay: delay / 1000 + i * 0.04, ease: [0.25, 1, 0.5, 1] }}
          >
            {word}
          </motion.span>
        </span>
      ))}
    </Component>
  );
};

const ParallaxImage = ({ src, alt, className, speed = 0.2 }) => {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [`-${speed * 100}%`, `${speed * 100}%`]);
  return (
    <div ref={ref} className={`overflow-hidden relative ${className}`}>
      <motion.img src={src} alt={alt} style={{ y, scale: 1.15 }} className="w-full h-full object-cover origin-top" />
    </div>
  );
};

const LiquidGradient = ({ position = "bottom", opacity = 0.7 }) => (
  <div className={`absolute left-0 w-full flex justify-center pointer-events-none z-30 overflow-visible ${position === "bottom" ? "bottom-0 translate-y-[40%]" : "top-0 -translate-y-[40%]"}`} style={{ height: '400px' }}>
    <div className="w-[180%] max-w-[2500px] h-full" style={{ 
      background: `radial-gradient(ellipse at center, ${GOLD} 0%, transparent 70%)`, 
      filter: 'blur(80px)',
      opacity: opacity
    }}></div>
  </div>
);

const SliderSection = () => {
  const [active, setActive] = useState(1);
  return (
    <section className="py-32 bg-[#fcfcfc] overflow-hidden">
      <div className="max-w-[85rem] mx-auto px-6">
        <TextReveal as="h2" className="text-4xl md:text-5xl font-black text-gray-900 leading-[1.1] tracking-tight max-w-xl mb-16">
          Why Us And How Because Of Master
        </TextReveal>
        
        <div className="flex flex-col md:flex-row h-[600px] md:h-[500px] gap-4">
          {[1,2,3,4].map(num => (
             <motion.div 
               key={num} 
               onClick={() => setActive(num)}
               layout
               transition={{ type: "spring", stiffness: 200, damping: 25 }}
               className={`relative overflow-hidden cursor-pointer ${active === num ? 'flex-[4] bg-black rounded-xl' : 'flex-[1] bg-white border border-gray-200 rounded-xl'}`}
             >
                <AnimatePresence mode="wait">
                  {active === num ? (
                     <motion.div 
                        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.5 }}
                        className="absolute inset-0 p-8 md:p-12 flex flex-col justify-between cursor-hover"
                     >
                       <div className="text-[#c9a76c] text-3xl font-light">0{num}</div>
                       <div className="w-full h-[65%] overflow-hidden mt-4 rounded-xl relative group">
                          <ParallaxImage src={
                            num === 1 ? "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=1200&q=90" :
                            num === 2 ? "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=1200&q=90" :
                            num === 3 ? "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1200&q=90" :
                            "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=1200&q=90"
                          } className="w-full h-full group-hover:scale-110 transition-transform duration-1000" alt={`Slide ${num}`} />
                       </div>
                       <motion.h3 
                         initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.3 }}
                         className="text-white text-2xl md:text-3xl font-black mt-6 leading-none"
                       >
                         Architecture Design
                       </motion.h3>
                     </motion.div>
                  ) : (
                     <motion.div 
                        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                        className="absolute inset-0 flex items-center justify-center bg-gray-50/50 hover:bg-gray-100 transition-colors"
                     >
                        <div className="text-gray-300 hover:text-gray-500 transition-colors text-3xl font-light transform md:-rotate-90">0{num}</div>
                     </motion.div>
                  )}
                </AnimatePresence>
             </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default function Properties() {
  const heroRef = useRef(null);
  const { scrollYProgress: heroScroll } = useScroll({ target: heroRef, offset: ["start start", "end start"] });
  const heroY = useTransform(heroScroll, [0, 1], ["0%", "40%"]);
  const heroOpacity = useTransform(heroScroll, [0, 1], [1, 0]);

  return (
    <div className="bg-white text-gray-900 overflow-x-hidden font-['Outfit'] selection:bg-[#c9a76c] selection:text-white">
      <CustomCursor />
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap');`}</style>
      <RENav />

      {/* 1. HERO */}
      <section ref={heroRef} className="relative w-full h-[100svh] min-h-[700px] bg-[#0a0a0a] flex flex-col justify-center overflow-visible">
        <motion.div style={{ y: heroY, opacity: heroOpacity }} className="absolute inset-0 w-full h-full">
          <img src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1920&q=90" alt="Hero" className="w-full h-full object-cover opacity-40 mix-blend-luminosity scale-105" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/60 to-transparent" />
        </motion.div>
        
        {/* Right Dots */}
        <div className="absolute right-8 top-1/2 -translate-y-1/2 flex flex-col gap-4 z-40 hidden md:flex mix-blend-difference">
          {[0,1,2,3,4].map((i) => (
            <motion.div key={i} whileHover={{ scale: 2 }} className={`w-2 h-2 rounded-full cursor-pointer transition-colors ${i === 0 ? 'bg-white' : 'bg-white/30'}`} />
          ))}
        </div>

        <div className="relative z-20 max-w-[85rem] mx-auto px-6 md:px-14 w-full pt-20">
          <h1 className="text-white text-5xl md:text-7xl lg:text-[5.5rem] font-black leading-[1.05] tracking-tight max-w-4xl flex flex-col gap-2">
            <TextReveal delay={100}>Properties That Offer</TextReveal>
            <TextReveal delay={300}>More Than Homes—They</TextReveal>
            <TextReveal delay={500}>Create Community.</TextReveal>
          </h1>
          <FadeIn delay={800}>
            <div className="flex flex-wrap gap-5 mt-12">
              <MagneticElement>
                <button className="bg-[#c9a76c] hover:bg-[#b8955b] text-white px-8 py-4 text-xs font-bold uppercase tracking-widest transition-colors rounded-full shadow-[0_0_40px_rgba(201,167,108,0.4)]">Explore More</button>
              </MagneticElement>
              <MagneticElement>
                <Link to={createPageUrl("Contact")} className="inline-flex items-center justify-center text-white px-8 py-4 text-xs font-bold uppercase tracking-widest border border-white/30 hover:bg-white/10 transition-colors rounded-full backdrop-blur-sm cursor-hover">Contact Us</Link>
              </MagneticElement>
            </div>
          </FadeIn>
        </div>

        <LiquidGradient position="bottom" opacity={0.85} />
      </section>

      {/* 2. SEARCH & SKETCH SECTION */}
      <section className="relative bg-[#fcfcfc] pt-48 pb-32 overflow-hidden z-20">
        {/* HUGE WATERMARK */}
        <motion.div 
           initial={{ x: "-10%" }} whileInView={{ x: "0%" }} transition={{ duration: 2, ease: "easeOut" }}
           className="absolute top-24 left-0 w-full flex justify-center pointer-events-none select-none z-0 opacity-[0.03]"
        >
          <span className="text-[8rem] md:text-[14rem] font-black uppercase tracking-tighter whitespace-nowrap text-[#c9a76c]">Estate Exclusive</span>
        </motion.div>

        <div className="max-w-[85rem] mx-auto px-6 md:px-14 relative z-10">
          <div className="flex flex-col lg:flex-row gap-16 items-center">
            <div className="w-full lg:w-[55%]">
              <h2 className="text-4xl md:text-5xl font-black text-gray-900 leading-[1.1] tracking-tight mb-12 flex flex-col">
                <TextReveal delay={100}>We Help You Build A Better</TextReveal>
                <TextReveal delay={200}>World—Beautifully, Experience,</TextReveal>
                <TextReveal delay={300}>Driven By Quality.</TextReveal>
              </h2>
              
              <FadeIn delay={400}>
                <div className="bg-white p-8 md:p-10 border border-gray-100 shadow-[0_30px_60px_-15px_rgba(0,0,0,0.08)] relative z-20 rounded-2xl cursor-hover">
                   <div className="flex items-center gap-2 mb-8">
                     <div className="flex text-[#c9a76c]"><Star size={16} fill="currentColor"/><Star size={16} fill="currentColor"/><Star size={16} fill="currentColor"/><Star size={16} fill="currentColor"/><Star size={16} fill="currentColor"/></div>
                     <span className="text-sm font-bold ml-2">4.9/5.0</span>
                     <span className="text-xs text-gray-400 font-medium ml-2">Based on 1,200+ reviews</span>
                   </div>
                   
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6 mb-8">
                      {['Property Type', 'Location', 'Price Range', 'Bedrooms'].map((label, idx) => (
                        <div key={label} className="group">
                          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block group-hover:text-[#c9a76c] transition-colors">{label}</label>
                          <select className="w-full border-b border-gray-200 pb-2 text-sm font-bold focus:outline-none bg-transparent cursor-pointer group-hover:border-[#c9a76c] transition-colors">
                            <option>Any {label}</option>
                            <option>Option 1</option>
                            <option>Option 2</option>
                          </select>
                        </div>
                      ))}
                   </div>
                   <MagneticElement className="w-full">
                     <button className="w-full bg-black text-white py-4 text-[11px] font-bold uppercase tracking-[0.2em] hover:bg-[#c9a76c] transition-colors rounded-xl shadow-lg cursor-hover">
                       Search Properties
                     </button>
                   </MagneticElement>
                </div>
              </FadeIn>
            </div>

            <div className="w-full lg:w-[45%] relative">
              <FadeIn delay={600}>
                <motion.div whileHover={{ scale: 1.05 }} transition={{ type: "spring", stiffness: 200, damping: 20 }} className="relative z-10 cursor-pointer">
                  <img src="https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=900&q=90" alt="Building Sketch" className="w-full h-auto object-contain opacity-80 filter contrast-125 saturate-50" style={{ mixBlendMode: 'multiply' }} />
                </motion.div>
                {/* Floating animated elements */}
                <motion.div animate={{ y: [0, -20, 0], rotate: [0, 10, 0] }} transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }} className="absolute top-1/4 -right-10 w-24 h-24 border border-black/10 rounded-full" />
                <motion.div animate={{ y: [0, 20, 0], rotate: [0, -10, 0] }} transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }} className="absolute bottom-1/4 -left-10 w-32 h-32 border border-[#c9a76c]/20 rounded-full" />
              </FadeIn>
            </div>
          </div>
        </div>
      </section>

      {/* 3. PROPERTY GRID */}
      <section className="py-24 bg-[#fcfcfc] relative z-10">
        <div className="max-w-[85rem] mx-auto px-6 md:px-14">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
            <h2 className="text-4xl md:text-5xl font-black text-gray-900 leading-[1.1] tracking-tight max-w-2xl flex flex-col">
              <TextReveal delay={100}>Best Properties For You</TextReveal>
              <TextReveal delay={200}>With A Choice Of Sublocation</TextReveal>
            </h2>
            <FadeIn delay={300}>
              <MagneticElement>
                <Link to={createPageUrl("Portfolio")} className="text-[11px] font-bold uppercase tracking-widest border-b-2 border-black pb-1 hover:text-[#c9a76c] hover:border-[#c9a76c] transition-colors whitespace-nowrap cursor-hover">
                  View All Properties
                </Link>
              </MagneticElement>
            </FadeIn>
          </div>

          <div className="grid md:grid-cols-2 gap-x-10 gap-y-16">
            {[
              { img: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=90", title: "The Onyx Architecture", loc: "Beverly Hills, CA", price: "$4,500,000", beds: "4 Beds", baths: "3 Baths", sqft: "5,200 sqft" },
              { img: "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=800&q=90", title: "Emerald Villa", loc: "Miami, FL", price: "$8,200,000", beds: "5 Beds", baths: "5 Baths", sqft: "6,800 sqft" },
              { img: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&q=90", title: "Sapphire Estate", loc: "Aspen, CO", price: "$12,400,000", beds: "6 Beds", baths: "7 Baths", sqft: "9,500 sqft" },
              { img: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=90", title: "The Pearl House", loc: "Malibu, CA", price: "$6,900,000", beds: "3 Beds", baths: "3 Baths", sqft: "4,100 sqft" }
            ].map((p, i) => (
              <FadeIn key={i} delay={i * 200}>
                <div className="group cursor-pointer bg-white p-4 border border-gray-100 shadow-sm hover:shadow-[0_20px_40px_-15px_rgba(0,0,0,0.1)] transition-all duration-500 rounded-2xl cursor-hover">
                  <div className="overflow-hidden mb-6 h-[300px] md:h-[400px] relative rounded-xl">
                    <img src={p.img} alt={p.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[1.5s] ease-[cubic-bezier(0.25,1,0.5,1)]" />
                    <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-4 py-2 text-[10px] font-bold tracking-widest uppercase rounded-full">For Sale</div>
                  </div>
                  <div className="px-2">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="text-2xl font-black text-gray-900 mb-2 group-hover:text-[#c9a76c] transition-colors">{p.title}</h3>
                        <div className="flex items-center gap-2 text-gray-500 text-sm">
                          <MapPin size={14} className="text-[#c9a76c]" /> {p.loc}
                        </div>
                      </div>
                      <div className="text-xl font-black text-[#c9a76c] bg-[#c9a76c]/10 px-3 py-1 rounded-lg">{p.price}</div>
                    </div>
                    <div className="flex gap-6 border-t border-gray-100 pt-4 mt-4 text-sm font-medium text-gray-600">
                       <span className="flex items-center gap-2"><BedDouble size={16} className="text-gray-400 group-hover:text-gray-900 transition-colors"/> {p.beds}</span>
                       <span className="flex items-center gap-2"><Layers size={16} className="text-gray-400 group-hover:text-gray-900 transition-colors"/> {p.baths}</span>
                       <span className="flex items-center gap-2"><Maximize size={16} className="text-gray-400 group-hover:text-gray-900 transition-colors"/> {p.sqft}</span>
                    </div>
                  </div>
                </div>
              </FadeIn>
            ))}
          </div>

          <div className="mt-24 text-center">
            <MagneticElement>
              <button className="bg-black text-white px-12 py-5 text-[11px] font-bold uppercase tracking-[0.2em] hover:bg-[#c9a76c] transition-colors rounded-full shadow-xl cursor-hover">
                Load More
              </button>
            </MagneticElement>
          </div>
        </div>
      </section>

      {/* 4. EXPERTISE & DARK SECTION */}
      <section className="relative pt-48 pb-32 bg-[#0a0a0a] mt-24">
        <LiquidGradient position="top" opacity={0.9} />

        <div className="absolute top-0 left-0 w-full -translate-y-[60%] flex justify-center pointer-events-none z-10 overflow-hidden">
          <motion.h2 
            initial={{ opacity: 0, y: 100 }} whileInView={{ opacity: 0.9, y: 0 }} transition={{ duration: 1.5, ease: "easeOut" }}
            className="text-[10rem] md:text-[16rem] font-black text-white tracking-tighter" style={{ mixBlendMode: 'overlay' }}
          >
            Expertise
          </motion.h2>
        </div>

        <div className="max-w-[85rem] mx-auto px-6 md:px-14 relative z-20 pt-10 md:pt-32">
          <div className="flex flex-col md:flex-row justify-between mb-24 gap-10">
            <div className="w-full md:w-1/3">
              <div className="flex items-center gap-4 text-[#c9a76c] text-[11px] font-bold uppercase tracking-[0.2em] mb-4">
                <motion.div initial={{ width: 0 }} whileInView={{ width: 40 }} transition={{ duration: 1 }} className="h-px bg-[#c9a76c]" /> What We Do
              </div>
            </div>
            <div className="w-full md:w-2/3 flex flex-col md:flex-row justify-between items-end gap-10">
              <p className="text-white/70 text-2xl font-light leading-relaxed max-w-xl">
                A new era of real estate where you can buy, sell, and rent properties with ease, transparency, and absolute confidence.
              </p>
              <MagneticElement>
                <Link to={createPageUrl("Portfolio")} className="text-white text-[11px] font-bold uppercase tracking-[0.2em] border-b-2 border-white/30 pb-1 hover:border-white hover:text-[#c9a76c] transition-colors whitespace-nowrap cursor-hover">
                  Our Portfolio
                </Link>
              </MagneticElement>
            </div>
          </div>

          <FadeIn delay={200}>
            <div className="relative w-full h-[400px] md:h-[650px] mb-24 cursor-pointer group rounded-3xl overflow-hidden shadow-2xl cursor-hover">
              <motion.img 
                whileHover={{ scale: 1.05 }} transition={{ duration: 1.5, ease: [0.25, 1, 0.5, 1] }}
                src="https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=1920&q=90" className="w-full h-full object-cover filter grayscale brightness-50 group-hover:brightness-90 transition-all duration-1000 origin-center" alt="Video Cover" 
              />
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <MagneticElement>
                  <div className="w-24 h-24 md:w-32 md:h-32 bg-white/10 backdrop-blur-md rounded-full flex items-center justify-center border border-white/20 group-hover:scale-110 group-hover:bg-[#c9a76c]/80 transition-all duration-500">
                    <Play fill="white" className="text-white ml-2 w-8 h-8 md:w-12 md:h-12" />
                  </div>
                </MagneticElement>
              </div>
            </div>
          </FadeIn>

          <FadeIn delay={400}>
            <div className="flex flex-wrap justify-center md:justify-between items-center gap-10 opacity-30 px-10">
              {['A', 'V', 'E', 'N', 'U', 'E'].map((letter, i) => (
                <motion.div key={i} whileHover={{ y: -10, opacity: 1, color: "#c9a76c" }} className="text-3xl md:text-5xl font-black text-white uppercase tracking-widest cursor-pointer transition-colors cursor-hover">{letter}</motion.div>
              ))}
            </div>
          </FadeIn>
        </div>
      </section>

      {/* 5. HAPPY CLIENT (WHITE SECTION) */}
      <section className="py-32 bg-[#fcfcfc] relative">
        <div className="max-w-[85rem] mx-auto px-6 md:px-14">
          <div className="flex flex-col lg:flex-row gap-16">
            <div className="w-full lg:w-[35%]">
              <div className="text-[#c9a76c] text-[11px] font-bold tracking-[0.2em] uppercase mb-4 flex items-center gap-4">
                <motion.span initial={{ width: 0 }} whileInView={{ width: 32 }} transition={{ duration: 1 }} className="h-px bg-[#c9a76c]" /> Happy Client
              </div>
              <h2 className="text-4xl md:text-5xl font-black text-gray-900 leading-[1.1] tracking-tight mb-12 flex flex-col">
                <TextReveal delay={100}>Happy Client, Journey &</TextReveal>
                <TextReveal delay={200}>Brilliant Times.</TextReveal>
              </h2>
              
              <FadeIn delay={300}>
                <div className="bg-[#111] p-10 shadow-2xl relative text-white rounded-3xl cursor-hover overflow-hidden group">
                   <div className="absolute top-0 right-0 w-32 h-32 bg-[#c9a76c] rounded-full blur-3xl opacity-20 group-hover:opacity-40 transition-opacity"></div>
                   <div className="text-[#c9a76c] text-[11px] font-bold uppercase tracking-[0.2em] mb-6 relative z-10">Best Deal</div>
                   <div className="flex items-end gap-4 mb-3 relative z-10">
                     <div className="text-6xl font-black">4.9</div>
                     <div className="flex text-[#c9a76c] mb-2"><Star size={20} fill="currentColor"/><Star size={20} fill="currentColor"/><Star size={20} fill="currentColor"/><Star size={20} fill="currentColor"/><Star size={20} fill="currentColor"/></div>
                   </div>
                   <div className="text-sm text-white/50 font-medium relative z-10">Over 2,400+ reviews from clients worldwide.</div>
                </div>
              </FadeIn>
            </div>
            
            <div className="w-full lg:w-[65%] grid grid-cols-1 md:grid-cols-2 gap-6">
              <FadeIn delay={400} className="h-[300px]">
                <ParallaxImage src="https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=800&q=90" className="w-full h-full rounded-2xl cursor-hover" speed={0.1} />
              </FadeIn>
              <FadeIn delay={500}>
                <div className="h-[300px] bg-white border border-gray-100 p-10 flex flex-col justify-center shadow-[0_20px_40px_-15px_rgba(0,0,0,0.05)] rounded-2xl relative cursor-hover hover:border-[#c9a76c]/30 transition-colors">
                   <div className="absolute top-6 right-8 text-6xl text-[#c9a76c] opacity-20 font-serif leading-none h-10">"</div>
                   <div className="text-2xl font-black text-gray-900 mb-6 leading-tight relative z-10">"The team delivered beyond expectations."</div>
                   <div className="text-sm font-bold text-[#c9a76c] uppercase tracking-widest">Michael R.</div>
                </div>
              </FadeIn>
              <FadeIn delay={600} className="col-span-1 md:col-span-2 h-[400px]">
                 <ParallaxImage src="https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=1200&q=90" className="w-full h-full rounded-3xl cursor-hover" speed={0.15} />
              </FadeIn>
            </div>
          </div>
        </div>
      </section>

      {/* 6. AVENGERS (TEAM) */}
      <section className="py-32 bg-white overflow-hidden">
        <div className="max-w-[85rem] mx-auto px-6 md:px-14 text-center">
          <motion.h2 
            initial={{ scale: 0.9, opacity: 0 }} whileInView={{ scale: 1, opacity: 1 }} transition={{ duration: 1 }}
            className="text-[5rem] md:text-[12rem] font-black text-gray-900 tracking-tighter leading-[0.8] mb-20 text-center uppercase"
          >
            Avengers
          </motion.h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 text-left">
             {[
               { img: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&q=90", name: "David M.", role: "CEO & Founder" },
               { img: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&q=90", name: "Sarah L.", role: "Lead Architect" },
               { img: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&q=90", name: "James K.", role: "Head of Sales" },
               { img: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&q=90", name: "Michael R.", role: "Senior Designer" },
               { img: "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?w=400&q=90", name: "Amanda T.", role: "Marketing Director" },
               { img: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&q=90", name: "Robert W.", role: "Operations Mgr" },
               { img: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&q=90", name: "William B.", role: "Property Consultant" }
             ].map((t, i) => (
               <FadeIn key={i} delay={i * 100}>
                 <div className="group cursor-pointer cursor-hover">
                   <div className="h-[400px] overflow-hidden mb-6 rounded-2xl relative">
                     <img src={t.img} className="w-full h-full object-cover filter grayscale group-hover:grayscale-0 group-hover:scale-110 transition-all duration-700 ease-out origin-center" alt={t.name} />
                     <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors"></div>
                   </div>
                   <h3 className="font-black text-xl text-gray-900 overflow-hidden"><motion.span className="inline-block" whileHover={{ y: -5 }}>{t.name}</motion.span></h3>
                   <p className="text-[#c9a76c] text-[10px] font-bold uppercase tracking-widest mt-1">{t.role}</p>
                 </div>
               </FadeIn>
             ))}
             
             <FadeIn delay={700}>
               <div className="h-[400px] bg-black text-white p-10 flex flex-col justify-center items-center text-center cursor-pointer hover:bg-[#c9a76c] transition-colors duration-500 group rounded-2xl cursor-hover">
                  <h3 className="font-black text-4xl mb-4">Join Us</h3>
                  <p className="text-white/60 text-sm mb-10 max-w-[150px]">Be part of the Avengers team</p>
                  <MagneticElement>
                    <div className="w-16 h-16 rounded-full border border-white/30 flex items-center justify-center group-hover:scale-110 transition-transform bg-white/5 backdrop-blur-sm"><ArrowRight size={24}/></div>
                  </MagneticElement>
               </div>
             </FadeIn>
          </div>
        </div>
      </section>

      {/* 7. SLIDER SECTION */}
      <SliderSection />

      {/* 8. BLOG */}
      <section className="py-32 bg-white relative z-10">
        <div className="max-w-[85rem] mx-auto px-6 md:px-14">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
            <h2 className="text-4xl md:text-5xl font-black text-gray-900 leading-[1.1] tracking-tight max-w-xl flex flex-col">
              <TextReveal delay={100}>On Going Project</TextReveal>
              <TextReveal delay={200}>Content & Masterpiece</TextReveal>
            </h2>
            <FadeIn delay={300}>
              <MagneticElement>
                <Link to={createPageUrl("Blog")} className="bg-black text-white px-10 py-4 text-[11px] font-bold uppercase tracking-[0.2em] hover:bg-[#c9a76c] transition-colors whitespace-nowrap rounded-full shadow-lg cursor-hover">
                  View All
                </Link>
              </MagneticElement>
            </FadeIn>
          </div>

          <div className="grid md:grid-cols-3 gap-10">
             {[
               { img: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=600&q=90", title: "Luxury Living Spaces For The Elite", cat: "Architecture" },
               { img: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=600&q=90", title: "Modern Architecture Trends in 2026", cat: "Design" },
               { img: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=600&q=90", title: "Sustainable Building Materials & Future", cat: "Innovation" }
             ].map((b, i) => (
               <FadeIn key={i} delay={i * 150}>
                 <div className="group cursor-pointer cursor-hover">
                   <div className="h-[300px] overflow-hidden mb-6 relative rounded-2xl">
                     <motion.img 
                       whileHover={{ scale: 1.1 }} transition={{ duration: 1, ease: [0.25, 1, 0.5, 1] }}
                       src={b.img} className="w-full h-full object-cover origin-center" alt={b.title} 
                     />
                     <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-md px-4 py-2 text-[10px] font-bold tracking-widest uppercase rounded-full">{b.cat}</div>
                   </div>
                   <h3 className="text-2xl font-black text-gray-900 leading-tight group-hover:text-[#c9a76c] transition-colors line-clamp-2">{b.title}</h3>
                 </div>
               </FadeIn>
             ))}
          </div>
        </div>
      </section>

      {/* 9. FOOTER TRANSITION & TAGS */}
      <div className="relative bg-[#0a0a0a] overflow-hidden pt-24 pb-10">
        <LiquidGradient position="top" opacity={0.9} />
        
        <div className="relative z-10 max-w-[85rem] mx-auto px-6 md:px-14 mb-10">
           <div className="flex flex-wrap justify-center gap-4">
              {['Real Estate', 'Luxury Homes', 'Modern Design', 'Architecture', 'Interior', 'Visualisation', 'Property Mgmt', 'Consulting'].map((t, i) => (
                <motion.div 
                  key={t} 
                  initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                  whileHover={{ scale: 1.05, backgroundColor: "#fff", color: "#000" }}
                  className="px-6 py-3 border border-white/20 text-white/70 text-[10px] font-bold uppercase tracking-[0.2em] rounded-full transition-colors cursor-pointer cursor-hover"
                >
                  {t}
                </motion.div>
              ))}
           </div>
        </div>
        
        <REFooter />
      </div>
    </div>
  );
}