import React, { useState, useEffect, useRef } from "react";
import RENav from "@/components/realestate/RENav";
import REFooter from "@/components/realestate/REFooter";
import { ArrowRight, Play, Calendar, Clock, ChevronRight, MapPin } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion, useScroll, useTransform, AnimatePresence } from "framer-motion";

const GOLD = "#c9a76c";

// Premium Utilities
const CustomCursor = () => {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isHover, setIsHover] = useState(false);

  useEffect(() => {
    const updatePos = (e) => setMousePos({ x: e.clientX, y: e.clientY });
    const checkHover = (e) => {
      const target = e.target;
      setIsHover(target.tagName === 'BUTTON' || target.tagName === 'A' || target.closest('button') || target.closest('a') || target.closest('.cursor-hover'));
    };
    window.addEventListener("mousemove", updatePos);
    window.addEventListener("mouseover", checkHover);
    return () => { window.removeEventListener("mousemove", updatePos); window.removeEventListener("mouseover", checkHover); };
  }, []);

  return (
    <motion.div
      className="fixed top-0 left-0 w-4 h-4 rounded-full pointer-events-none z-[9999] mix-blend-difference bg-white flex items-center justify-center transform -translate-x-1/2 -translate-y-1/2 hidden md:flex"
      animate={{ x: mousePos.x, y: mousePos.y, scale: isHover ? 3.5 : 1, opacity: isHover ? 0.8 : 1 }}
      transition={{ type: "spring", stiffness: 400, damping: 30, mass: 0.5 }}
    />
  );
};

const MagneticElement = ({ children, className = "" }) => {
  const ref = useRef(null);
  const [position, setPosition] = useState({ x: 0, y: 0 });

  const handleMouse = (e) => {
    const { clientX, clientY } = e;
    const { height, width, left, top } = ref.current.getBoundingClientRect();
    const middleX = clientX - (left + width / 2);
    const middleY = clientY - (top + height / 2);
    setPosition({ x: middleX * 0.2, y: middleY * 0.2 });
  };

  return (
    <motion.div
      ref={ref}
      onMouseMove={handleMouse}
      onMouseLeave={() => setPosition({ x: 0, y: 0 })}
      animate={{ x: position.x, y: position.y }}
      transition={{ type: "spring", stiffness: 150, damping: 15, mass: 0.1 }}
      className={`inline-block ${className}`}
    >
      {children}
    </motion.div>
  );
};

const FadeIn = ({ children, delay = 0, className = "", direction = "up" }) => {
  const variants = {
    up: { y: 40, opacity: 0 },
    down: { y: -40, opacity: 0 },
    left: { x: 40, opacity: 0 },
    right: { x: -40, opacity: 0 }
  };
  return (
    <motion.div
      initial={variants[direction]}
      whileInView={{ x: 0, y: 0, opacity: 1 }}
      viewport={{ once: true, margin: "-10%" }}
      transition={{ duration: 0.8, delay: delay / 1000, ease: [0.25, 1, 0.5, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
};

const TextReveal = ({ children, delay = 0, as: Component = "span", className = "" }) => {
  if (typeof children !== 'string') return <Component className={className}>{children}</Component>;
  const words = children.split(" ");
  return (
    <Component className={`inline-block ${className}`}>
      {words.map((word, i) => (
        <span key={i} className="inline-block overflow-hidden mr-[0.25em] pb-1">
          <motion.span
            className="inline-block"
            initial={{ y: "100%", rotate: 2 }}
            whileInView={{ y: 0, rotate: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: delay / 1000 + i * 0.03, ease: [0.25, 1, 0.5, 1] }}
          >
            {word}
          </motion.span>
        </span>
      ))}
    </Component>
  );
};

// Sub-components
const ArticleCard = ({ img, tag, title, date, excerpt, large = false, dark = false }) => (
  <div className={`group cursor-pointer cursor-hover flex ${large ? 'flex-col h-full' : 'flex-col sm:flex-row gap-6'} w-full`}>
    <div className={`overflow-hidden relative rounded-xl ${large ? 'h-[300px] md:h-[400px] mb-6' : 'w-full sm:w-[240px] h-[160px] flex-shrink-0'}`}>
      <motion.img 
        whileHover={{ scale: 1.05 }} transition={{ duration: 0.8, ease: "easeOut" }}
        src={img} className="w-full h-full object-cover origin-center" alt={title} 
      />
      {tag && <div className={`absolute top-4 left-4 px-3 py-1 text-[10px] font-bold tracking-widest uppercase rounded-md backdrop-blur-md ${dark ? 'bg-black/50 text-white' : 'bg-white/80 text-black'}`}>{tag}</div>}
    </div>
    <div className={`flex flex-col justify-center flex-1`}>
      <div className="flex items-center gap-4 text-xs font-bold text-gray-400 mb-3 tracking-widest uppercase">
        <span className="text-[#c9a76c]">{tag || "News"}</span>
        <span className="w-1 h-1 rounded-full bg-gray-300"></span>
        <span>{date}</span>
      </div>
      <h3 className={`${large ? 'text-2xl md:text-3xl' : 'text-lg md:text-xl'} font-black text-gray-900 leading-snug group-hover:text-[#c9a76c] transition-colors line-clamp-3 mb-3`}>{title}</h3>
      {excerpt && <p className="text-gray-500 text-sm font-medium line-clamp-2 leading-relaxed">{excerpt}</p>}
    </div>
  </div>
);

const EventCard = ({ title, date, location, type }) => (
  <div className="bg-white border border-gray-100 p-8 rounded-2xl hover:shadow-[0_20px_40px_-15px_rgba(0,0,0,0.08)] transition-all duration-500 group cursor-pointer cursor-hover flex flex-col h-full relative overflow-hidden">
    <div className="absolute top-0 right-0 w-32 h-32 bg-[#c9a76c]/5 rounded-bl-full -z-10 group-hover:bg-[#c9a76c]/10 transition-colors"></div>
    <div className="flex justify-between items-start mb-8">
      <div className="bg-gray-50 text-[#c9a76c] text-[10px] font-bold uppercase tracking-widest px-4 py-2 rounded-lg">{type}</div>
      <div className="w-10 h-10 rounded-full border border-gray-100 flex items-center justify-center group-hover:bg-black group-hover:text-white transition-colors">
        <ArrowRight size={16} />
      </div>
    </div>
    <h3 className="text-xl font-black text-gray-900 mb-6 leading-tight group-hover:text-[#c9a76c] transition-colors">{title}</h3>
    <div className="mt-auto space-y-3">
      <div className="flex items-center gap-3 text-sm text-gray-500 font-medium">
        <Calendar size={16} className="text-gray-400" /> {date}
      </div>
      <div className="flex items-center gap-3 text-sm text-gray-500 font-medium">
        <MapPin size={16} className="text-gray-400" /> {location}
      </div>
    </div>
  </div>
);

const InsightCard = ({ title, date, isDark = false }) => (
  <div className={`${isDark ? 'bg-black text-white' : 'bg-[#c9a76c] text-white'} p-8 rounded-2xl cursor-pointer cursor-hover group hover:-translate-y-2 transition-transform duration-500 relative overflow-hidden h-full flex flex-col`}>
    <div className={`absolute -right-10 -bottom-10 w-40 h-40 rounded-full blur-3xl opacity-30 ${isDark ? 'bg-[#c9a76c]' : 'bg-white'}`}></div>
    <div className="text-[10px] font-bold uppercase tracking-widest mb-6 opacity-70">Market Report</div>
    <h3 className="text-xl font-black mb-10 leading-snug z-10">{title}</h3>
    <div className="mt-auto flex justify-between items-center z-10 border-t border-white/20 pt-4">
      <span className="text-xs font-bold tracking-widest opacity-70">{date}</span>
      <ArrowRight size={18} className="group-hover:translate-x-2 transition-transform" />
    </div>
  </div>
);

export default function NewsAndEvents() {
  const [activeFilter, setActiveFilter] = useState("All");
  const filters = ["All", "Architecture", "Market Trends", "Events", "Company News", "Interviews"];

  return (
    <div className="bg-[#fcfcfc] text-gray-900 overflow-x-hidden font-['Outfit'] selection:bg-[#c9a76c] selection:text-white">
      <CustomCursor />
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap');`}</style>
      <RENav light={true} />

      {/* HEADER SECTION */}
      <section className="pt-32 pb-10 bg-white">
        <div className="max-w-[85rem] mx-auto px-6 md:px-14">
          <div className="flex flex-col md:flex-row justify-between items-end gap-6 mb-10 border-b border-gray-100 pb-10">
            <h1 className="text-5xl md:text-7xl font-black text-gray-900 tracking-tight leading-none">
              <TextReveal delay={100}>News &</TextReveal><br/>
              <TextReveal delay={200}>Insights.</TextReveal>
            </h1>
            <FadeIn delay={300}>
              <p className="text-gray-500 max-w-sm text-sm font-medium leading-relaxed">
                Stay updated with the latest trends in luxury real estate, architecture, and exclusive OnePack events around the globe.
              </p>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* HERO GRID (Clone of top section) */}
      <section className="pb-20 bg-white">
        <div className="max-w-[85rem] mx-auto px-6 md:px-14">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 h-auto lg:h-[500px]">
            {/* Main Featured */}
            <div className="lg:col-span-8 h-[400px] lg:h-full relative rounded-2xl overflow-hidden group cursor-pointer cursor-hover">
              <motion.img 
                whileHover={{ scale: 1.05 }} transition={{ duration: 1, ease: "easeOut" }}
                src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1600&q=90" className="w-full h-full object-cover" alt="Main" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent"></div>
              <div className="absolute bottom-0 left-0 p-8 md:p-12 w-full">
                <div className="bg-[#c9a76c] text-white text-[10px] font-bold uppercase tracking-widest px-3 py-1 rounded w-max mb-4">Featured</div>
                <h2 className="text-3xl md:text-4xl lg:text-5xl font-black text-white leading-[1.1] mb-4 group-hover:text-[#c9a76c] transition-colors">
                  The Future of Luxury Living: Integrating Nature with Modern Architecture
                </h2>
                <div className="flex items-center gap-4 text-white/70 text-xs font-bold uppercase tracking-widest">
                  <span>By Sarah L.</span>
                  <span className="w-1 h-1 rounded-full bg-[#c9a76c]"></span>
                  <span>Oct 24, 2026</span>
                </div>
              </div>
            </div>

            {/* Right Side Small Grid */}
            <div className="lg:col-span-4 grid grid-cols-2 lg:grid-cols-1 grid-rows-2 gap-4 h-[400px] lg:h-full">
              {[
                { img: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=600&q=90", title: "Market Report: Q3 Real Estate Trends", tag: "Report" },
                { img: "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=600&q=90", title: "Award Winning Interior Designs of 2025", tag: "Design" }
              ].map((item, i) => (
                <div key={i} className="relative rounded-2xl overflow-hidden group cursor-pointer cursor-hover h-full">
                  <motion.img 
                    whileHover={{ scale: 1.1 }} transition={{ duration: 0.8 }}
                    src={item.img} className="w-full h-full object-cover" alt={item.title} 
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
                  <div className="absolute bottom-0 left-0 p-6 w-full">
                    <div className="text-[#c9a76c] text-[10px] font-bold uppercase tracking-widest mb-2">{item.tag}</div>
                    <h3 className="text-lg font-black text-white leading-tight group-hover:text-[#c9a76c] transition-colors">{item.title}</h3>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FILTER BAR - Sticky */}
      <div className="sticky top-[68px] z-40 bg-white/80 backdrop-blur-xl border-b border-gray-200">
        <div className="max-w-[85rem] mx-auto px-6 md:px-14">
          <div className="flex overflow-x-auto hide-scrollbar py-4 gap-2 items-center">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-widest mr-4 flex-shrink-0">Filter By:</span>
            {filters.map((f) => (
              <button 
                key={f} 
                onClick={() => setActiveFilter(f)}
                className={`flex-shrink-0 px-5 py-2.5 rounded-full text-xs font-bold tracking-widest uppercase transition-all duration-300 cursor-hover ${activeFilter === f ? 'bg-black text-white' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'}`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* EDITOR'S PICK & TRENDING LIST (Split layout clone) */}
      <section className="py-24 bg-white">
        <div className="max-w-[85rem] mx-auto px-6 md:px-14">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
            
            {/* Left: Editor's Pick (List of articles with images) */}
            <div className="lg:col-span-8">
              <div className="flex items-center gap-3 mb-10">
                <div className="w-2 h-6 bg-[#c9a76c] rounded-full"></div>
                <h3 className="text-2xl font-black text-gray-900 uppercase tracking-tight">Editor's Pick</h3>
              </div>
              <div className="space-y-10">
                {[
                  { img: "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=800&q=90", tag: "Architecture", title: "Sustainable Materials Shaping the Future of Skyscrappers in New York", excerpt: "An in-depth look at how developers are pivoting towards carbon-neutral building techniques for the upcoming decade.", date: "Nov 02, 2026" },
                  { img: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=800&q=90", tag: "Interview", title: "Conversation with David M: Navigating the Luxury Market Post-2025", excerpt: "Our CEO shares his thoughts on where ultra-high-net-worth individuals are looking to invest next.", date: "Oct 28, 2026" },
                  { img: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=90", tag: "Company News", title: "OnePack Announces Expansion into the European Market", excerpt: "Opening new offices in Paris, Milan, and London to cater to our growing international clientele.", date: "Oct 15, 2026" },
                  { img: "https://images.unsplash.com/photo-1556912172-45b7abe8d7e1?w=800&q=90", tag: "Design", title: "The Renaissance of Brutalism in Modern Offices", excerpt: "Why raw concrete and bold geometric shapes are making a comeback in corporate headquarters.", date: "Oct 10, 2026" },
                  { img: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&q=90", tag: "Technology", title: "Smart Cities: A Privacy Nightmare or Urban Utopia?", excerpt: "Exploring the delicate balance between data-driven efficiency and personal privacy in tomorrow's metropolises.", date: "Oct 05, 2026" },
                  { img: "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&q=90", tag: "Market", title: "Luxury Rentals: The Shift from Ownership to Access", excerpt: "High-net-worth individuals are increasingly preferring flexibility over equity. Here is why.", date: "Sep 28, 2026" }
                ].map((item, i) => (
                  <FadeIn key={i} delay={i * 100}>
                    <ArticleCard {...item} />
                  </FadeIn>
                ))}
              </div>
              
              <div className="mt-12 text-center lg:text-left">
                <MagneticElement>
                  <button className="bg-white border-2 border-black text-black px-10 py-4 text-[11px] font-bold uppercase tracking-[0.2em] hover:bg-black hover:text-white transition-colors rounded-full cursor-hover">
                    Load More
                  </button>
                </MagneticElement>
              </div>
            </div>

            {/* Right: Trending List (Text only) */}
            <div className="lg:col-span-4">
              <div className="flex items-center gap-3 mb-10">
                <div className="w-2 h-6 bg-black rounded-full"></div>
                <h3 className="text-2xl font-black text-gray-900 uppercase tracking-tight">Trending</h3>
              </div>
              
              <div className="bg-gray-50/50 rounded-2xl p-6 border border-gray-100">
                <ul className="space-y-6">
                  {[
                    "Top 10 Most Expensive Penthouse Sales This Year",
                    "How AI is Revolutionizing Property Valuation",
                    "The Rise of Smart Home Automation in Luxury Estates",
                    "Why Aspen is the New Hotspot for Billionaires",
                    "Interior Design Color Palettes for 2027",
                    "Navigating Mortgage Rates for High-End Properties",
                    "The Architecture of Wellness: Designing for Health"
                  ].map((text, i) => (
                    <li key={i} className="group cursor-pointer flex gap-4 border-b border-gray-200 pb-6 last:border-0 last:pb-0 cursor-hover">
                      <span className="text-xl font-black text-gray-300 group-hover:text-[#c9a76c] transition-colors">0{i+1}</span>
                      <h4 className="text-sm font-bold text-gray-800 leading-snug group-hover:text-[#c9a76c] transition-colors">{text}</h4>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* LATEST NEWS GRID */}
      <section className="py-24 bg-[#fcfcfc] border-t border-gray-100">
        <div className="max-w-[85rem] mx-auto px-6 md:px-14">
          <div className="flex items-center justify-between mb-12">
            <div className="flex items-center gap-3">
              <div className="w-2 h-6 bg-[#c9a76c] rounded-full"></div>
              <h3 className="text-3xl font-black text-gray-900 uppercase tracking-tight">Latest News</h3>
            </div>
            <Link to="#" className="text-xs font-bold text-gray-500 uppercase tracking-widest hover:text-[#c9a76c] transition-colors flex items-center gap-1 cursor-hover">
              View All <ChevronRight size={14}/>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {[
              { img: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=90", tag: "Design", title: "Minimalist Approaches to Grand Spaces", date: "Nov 10, 2026", excerpt: "How to make a 10,000 sqft home feel intimate and connected." },
              { img: "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=800&q=90", tag: "Market", title: "Global Real Estate Investment Index", date: "Nov 08, 2026", excerpt: "Analyzing the flow of capital across major global cities." },
              { img: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&q=90", tag: "Architecture", title: "Reviving Historical Landmarks", date: "Nov 05, 2026", excerpt: "The delicate balance of modernizing while preserving history." },
              { img: "https://images.unsplash.com/photo-1513584685908-78b773c7d286?w=800&q=90", tag: "Market", title: "London's Property Market Sees Unexpected Surge", date: "Nov 02, 2026", excerpt: "Post-election stability brings foreign investors back to the UK capital." },
              { img: "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&q=90", tag: "Design", title: "Tokyo's Micro-Apartments: A Design Masterclass", date: "Oct 30, 2026", excerpt: "How Japanese architects are redefining small-space living with incredible efficiency." },
              { img: "https://images.unsplash.com/photo-1512453979798-5ea904a84894?w=800&q=90", tag: "Projects", title: "Dubai's Newest Artificial Island Project Unveiled", date: "Oct 25, 2026", excerpt: "The Palm Jebel Ali is finally waking up with ambitious new residential plans." }
            ].map((item, i) => (
              <FadeIn key={i} delay={i * 150} direction="up">
                <ArticleCard {...item} large={true} dark={true} />
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* REGIONAL FOCUS */}
      <section className="py-24 bg-black text-white">
        <div className="max-w-[85rem] mx-auto px-6 md:px-14">
          <div className="flex items-center gap-3 mb-12">
            <div className="w-2 h-6 bg-[#c9a76c] rounded-full"></div>
            <h3 className="text-3xl font-black uppercase tracking-tight">Regional Focus</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { region: "North America", title: "New York's Vertical Expansion", img: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=600&q=90" },
              { region: "Europe", title: "Paris: The Green City Initiative", img: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=600&q=90" },
              { region: "Asia Pacific", title: "Singapore's Garden Homes", img: "https://images.unsplash.com/photo-1525625293386-3f8f99389edd?w=600&q=90" },
              { region: "Middle East", title: "Riyadh's New Downtown", img: "https://images.unsplash.com/photo-1586724237569-f3d0c1dee8c6?w=600&q=90" }
            ].map((item, i) => (
              <div key={i} className="group cursor-pointer relative h-[300px] overflow-hidden rounded-xl">
                <img src={item.img} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-70 group-hover:opacity-100" alt={item.title} />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
                <div className="absolute bottom-0 left-0 p-6">
                  <div className="text-[#c9a76c] text-[10px] font-bold uppercase tracking-widest mb-2">{item.region}</div>
                  <h4 className="text-xl font-bold leading-tight">{item.title}</h4>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* IN-DEPTH ANALYSIS */}
      <section className="py-24 bg-white border-b border-gray-100">
        <div className="max-w-[85rem] mx-auto px-6 md:px-14">
          <div className="flex items-center gap-3 mb-12">
            <div className="w-2 h-6 bg-black rounded-full"></div>
            <h3 className="text-3xl font-black text-gray-900 uppercase tracking-tight">In-Depth Analysis</h3>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
             <div className="group cursor-pointer">
               <div className="overflow-hidden rounded-2xl mb-6 h-[400px]">
                 <img src="https://images.unsplash.com/photo-1497366216548-37526070297c?w=1200&q=90" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" alt="Office" />
               </div>
               <div className="flex items-center gap-4 text-xs font-bold text-gray-400 mb-4 tracking-widest uppercase">
                  <span className="text-[#c9a76c]">Commercial</span>
                  <span className="w-1 h-1 rounded-full bg-gray-300"></span>
                  <span>15 Min Read</span>
               </div>
               <h3 className="text-3xl md:text-4xl font-black text-gray-900 mb-4 group-hover:text-[#c9a76c] transition-colors">The Post-Pandemic Office: Data Driven Insights into Hybrid Workspaces</h3>
               <p className="text-gray-500 text-lg leading-relaxed">We analyzed over 500 commercial leases signed in 2026 to understand the new requirements for corporate headquarters. The findings might surprise you.</p>
             </div>
             
             <div className="space-y-8">
               {[
                 { title: "Climate Change vs Coastal Real Estate: A 50 Year Projection", time: "10 Min Read", tag: "Environment" },
                 { title: "The Psychology of Color in Luxury Retail Interiors", time: "8 Min Read", tag: "Design Theory" },
                 { title: "Cryptocurrency in Real Estate: Is the Hype Over?", time: "12 Min Read", tag: "Finance" },
                 { title: "Generational Wealth Transfer: Millennials Entering the Market", time: "7 Min Read", tag: "Demographics" }
               ].map((item, i) => (
                 <div key={i} className="group cursor-pointer flex flex-col sm:flex-row gap-6 border-b border-gray-100 pb-8 last:border-0">
                   <div className="flex-1">
                     <div className="flex items-center gap-3 text-xs font-bold text-gray-400 mb-2 tracking-widest uppercase">
                        <span className="text-[#c9a76c]">{item.tag}</span>
                        <span className="w-1 h-1 rounded-full bg-gray-300"></span>
                        <span>{item.time}</span>
                     </div>
                     <h4 className="text-xl font-bold text-gray-900 group-hover:text-[#c9a76c] transition-colors">{item.title}</h4>
                   </div>
                   <div className="w-12 h-12 rounded-full border border-gray-200 flex items-center justify-center group-hover:bg-black group-hover:border-black group-hover:text-white transition-all flex-shrink-0">
                     <ArrowRight size={18} />
                   </div>
                 </div>
               ))}
             </div>
          </div>
        </div>
      </section>

      {/* UPCOMING EVENTS & REPORTS (Colored Block Cards) */}
      <section className="py-24 bg-white">
        <div className="max-w-[85rem] mx-auto px-6 md:px-14">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            
            {/* Events */}
            <div>
              <div className="flex items-center gap-3 mb-10">
                <div className="w-2 h-6 bg-black rounded-full"></div>
                <h3 className="text-3xl font-black text-gray-900 uppercase tracking-tight">Upcoming Events</h3>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <FadeIn delay={100}><EventCard type="Open House" title="The Onyx Exclusive Viewing" date="Nov 15, 2026" location="Beverly Hills, CA" /></FadeIn>
                <FadeIn delay={200}><EventCard type="Webinar" title="Investing in Commercial Real Estate 2027" date="Nov 22, 2026" location="Online Event" /></FadeIn>
                <FadeIn delay={300}><EventCard type="Gala" title="OnePack Annual Charity Gala" date="Dec 10, 2026" location="New York, NY" /></FadeIn>
                <FadeIn delay={400}><EventCard type="Exhibition" title="Future Architecture Expo" date="Jan 15, 2027" location="Miami, FL" /></FadeIn>
              </div>
            </div>

            {/* Reports (Clone of purple blocks but using theme colors) */}
            <div>
              <div className="flex items-center gap-3 mb-10">
                <div className="w-2 h-6 bg-[#c9a76c] rounded-full"></div>
                <h3 className="text-3xl font-black text-gray-900 uppercase tracking-tight">Market Insights</h3>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 h-[calc(100%-5rem)]">
                <FadeIn delay={100} className="h-full">
                  <InsightCard title="2026 Global Wealth & Property Report" date="DOWNLOAD PDF" isDark={true} />
                </FadeIn>
                <FadeIn delay={200} className="h-full">
                  <InsightCard title="Sustainable Urban Development Index" date="READ ONLINE" isDark={false} />
                </FadeIn>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* VIDEOS & MEDIA */}
      <section className="py-24 bg-[#0a0a0a] text-white overflow-hidden relative">
        <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
           <div className="w-[800px] h-[800px] bg-[#c9a76c] rounded-full blur-[150px] absolute -top-1/2 -left-1/4"></div>
        </div>
        
        <div className="max-w-[85rem] mx-auto px-6 md:px-14 relative z-10">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
            <h2 className="text-4xl md:text-5xl font-black tracking-tight flex flex-col">
              <TextReveal delay={100}>Media &</TextReveal>
              <TextReveal delay={200}>Interviews.</TextReveal>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
             {[
               { img: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=800&q=90", title: "Mastering the Art of Deal Making in 2026", duration: "45:20" },
               { img: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=800&q=90", title: "Designing the Home of Tomorrow", duration: "32:15" },
               { img: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=800&q=90", title: "Economic Forecasts with the CEO", duration: "50:00" },
               { img: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=90", title: "Behind the Scenes: The Sapphire Estate", duration: "18:40" },
               { img: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=90", title: "Touring a $50M Bel Air Mansion", duration: "42:10" },
               { img: "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=800&q=90", title: "Architect Interview: Zaha Hadid Architects", duration: "55:00" },
               { img: "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=800&q=90", title: "The Art of Staging: Selling Lifestyle", duration: "25:30" },
               { img: "https://images.unsplash.com/photo-1560520653-9e0e4c89eb11?w=800&q=90", title: "Tech in Real Estate: VR Tours", duration: "20:15" }
             ].map((v, i) => (
               <FadeIn key={i} delay={i * 150}>
                 <div className="group cursor-pointer cursor-hover flex flex-col sm:flex-row gap-6 bg-white/5 border border-white/10 p-4 rounded-2xl hover:bg-white/10 transition-colors">
                   <div className="w-full sm:w-[200px] h-[140px] relative rounded-xl overflow-hidden flex-shrink-0">
                     <img src={v.img} className="w-full h-full object-cover filter grayscale group-hover:grayscale-0 transition-all duration-700" alt={v.title} />
                     <div className="absolute inset-0 flex items-center justify-center">
                       <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center group-hover:bg-[#c9a76c] transition-colors">
                         <Play fill="white" className="text-white w-5 h-5 ml-1" />
                       </div>
                     </div>
                     <div className="absolute bottom-2 right-2 bg-black/80 px-2 py-1 text-[10px] font-bold rounded">{v.duration}</div>
                   </div>
                   <div className="flex flex-col justify-center">
                     <div className="text-[#c9a76c] text-[10px] font-bold uppercase tracking-widest mb-2">Video Podcast</div>
                     <h3 className="text-xl font-bold leading-snug group-hover:text-[#c9a76c] transition-colors">{v.title}</h3>
                   </div>
                 </div>
               </FadeIn>
             ))}
          </div>
        </div>
      </section>

      <REFooter />
    </div>
  );
}