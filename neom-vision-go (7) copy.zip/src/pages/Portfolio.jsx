import React, { useState, useEffect, useRef } from "react";
import RENav from "@/components/realestate/RENav";
import REFooter from "@/components/realestate/REFooter";
import { ArrowRight, ArrowUpRight, Download, ChevronDown, Play } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const GOLD = "#c9a76c";

const tabs = ["Overview", "Services", "Gallery", "News"];

const stats = [
  { value: "250+", label: "Properties Delivered" },
  { value: "500+", label: "Happy Clients" },
  { value: "15", label: "Countries Served" },
  { value: "18", label: "Awards Won" },
  { value: "12yr", label: "In Business" },
];

const pillars = [
  {
    title: "Architecture Design",
    desc: "OnePack's architectural studios translate ambitious briefs into enduring built form. From concept massing through technical detailing and site oversight, our architects work at the intersection of art, engineering, and human experience — creating homes and commercial developments that stand apart.",
    image: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=900&q=90",
  },
  {
    title: "Interior & Landscape",
    desc: "Our interior and landscape teams work in concert — ensuring that every space, from the entry hall to the garden boundary, forms a coherent, considered whole. Materials are selected for tactile quality and longevity; planting for ecology, seasonality, and beauty.",
    image: "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=900&q=90",
  },
  {
    title: "Property Consulting",
    desc: "With deep market intelligence and a global network of relationships, our advisory team guides investors and owner-occupiers alike — identifying opportunity, structuring transactions, and navigating the full complexity of high-value real estate acquisition and disposal.",
    image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=900&q=90",
  },
];

const services = [
  { title: "Architecture Design", img: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=600&q=90", desc: "Full-spectrum architectural services from concept through construction oversight — for residential, commercial and mixed-use commissions at every scale." },
  { title: "Interior Design", img: "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=600&q=90", desc: "Bespoke interiors that balance beauty and function — from space planning and material selection to custom furniture design and final installation." },
  { title: "Landscape Planning", img: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=600&q=90", desc: "Landscape design that extends the architecture into the natural world — from intimate gardens to expansive estate grounds, with sustainability at its core." },
  { title: "Visualisation", img: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=600&q=90", desc: "Photorealistic renders, animated flythroughs, and immersive VR walkthroughs that make your vision undeniably real before a single stone is laid." },
  { title: "Property Consulting", img: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=600&q=90", desc: "Expert investment advisory backed by global market intelligence — from acquisition strategy and valuation through negotiation and legal coordination." },
  { title: "Architecture Support", img: "https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=600&q=90", desc: "End-to-end project management and on-site oversight — ensuring every detail is delivered on time, on budget, and to the highest standard of quality." },
];

const whyChoose = [
  { icon: "🏆", title: "Award-Winning Excellence", desc: "18 international design awards across residential, commercial and sustainable development categories — a testament to consistent creative and technical achievement." },
  { icon: "🌍", title: "Global Reach, Local Insight", desc: "Active in 15 countries, with deep knowledge of local markets, planning systems, and cultural contexts — enabling seamless delivery wherever your project is located." },
  { icon: "⚡", title: "Innovation & Technology", desc: "Pioneering the use of AI-driven design tools, parametric modelling, and digital twin technology — bringing precision, speed, and creative possibility to every commission." },
];

const news = [
  { tag: "Architecture", title: "OnePack Wins International Residential Design Award for The Cliffside Retreat", date: "January 2025", img: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=500&q=90" },
  { tag: "Interior Design", title: "The Maple Grove House Featured in Architectural Digest's Best of 2025", date: "December 2024", img: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=500&q=90" },
  { tag: "Sustainability", title: "OnePack Achieves Net-Zero Carbon Certification for Full Portfolio", date: "November 2024", img: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=500&q=90" },
];

const downloads = [
  { title: "Company Capabilities Brochure", date: "December 2024", size: "4.2 MB", img: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=200&q=80" },
  { title: "Services & Pricing Guide", date: "January 2025", size: "2.8 MB", img: "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=200&q=80" },
];

export default function Portfolio() {
  const [activeTab, setActiveTab] = useState("Overview");
  const [activePillar, setActivePillar] = useState(0);
  const [scrolled, setScrolled] = useState(false);
  const [navVisible, setNavVisible] = useState(false);
  const [filter, setFilter] = useState("All");

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 80);
      setNavVisible(window.scrollY > 500);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (id) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="bg-black text-white overflow-x-hidden" style={{ fontFamily: "'Outfit', sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap');
        .tab-underline { position: relative; }
        .tab-underline::after { content: ''; position: absolute; bottom: -2px; left: 0; right: 0; height: 2px; background: ${GOLD}; transform: scaleX(0); transition: transform 0.3s; }
        .tab-underline.active::after { transform: scaleX(1); }
      `}</style>
      <RENav />

      {/* HERO — full bleed cinematic */}
      <section className="relative w-full h-screen min-h-[700px] overflow-hidden bg-black">
        <img
          src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1920&q=90"
          alt=""
          className="w-full h-full object-cover"
          style={{ filter: "brightness(0.45)" }}
        />
        <div className="absolute inset-0" style={{ background: "linear-gradient(to bottom, rgba(0,0,0,0.3) 0%, rgba(0,0,0,0.75) 100%)" }} />

        {/* Breadcrumb */}
        <div className="absolute top-24 left-10 md:left-24 flex items-center gap-2 text-xs text-white/40 font-light tracking-widest uppercase">
          <span>OnePack</span>
          <span>/</span>
          <span style={{ color: GOLD }}>Our Portfolio</span>
        </div>

        {/* Logo badge */}
        <div className="absolute top-24 left-1/2 -translate-x-1/2">
          <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.2)" }}>
            <span className="text-white font-black text-xs">ONE</span>
          </div>
        </div>

        {/* Headline */}
        <div className="absolute inset-0 flex flex-col justify-end px-10 md:px-24 pb-24">
          <h1 className="font-black text-white leading-[0.88] mb-5" style={{ fontSize: "clamp(4rem, 10vw, 11rem)", letterSpacing: "-0.04em" }}>
            ONEPACK<br />REAL ESTATE
          </h1>
          <p className="text-white/50 font-light mb-10 max-w-xl leading-relaxed" style={{ fontSize: "1.05rem" }}>
            Extraordinary properties and award-winning design services — delivered with precision, vision, and uncompromising quality for over twelve years.
          </p>
          <Link to={createPageUrl("Contact")} className="inline-flex items-center gap-2 text-white text-xs font-semibold tracking-widest uppercase pb-1" style={{ borderBottom: `1px solid ${GOLD}`, width: "fit-content", color: GOLD }}>
            Contact Us →
          </Link>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
          <ChevronDown className="w-5 h-5 text-white/30" />
        </div>
      </section>

      {/* STICKY SECTION NAV */}
      <div className="sticky top-0 z-40 transition-all duration-300" style={{ background: "rgba(10,10,10,0.97)", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
        <div className="px-10 md:px-24 flex items-center gap-10 overflow-x-auto" style={{ scrollbarWidth: "none" }}>
          {tabs.map(tab => (
            <button key={tab} onClick={() => { setActiveTab(tab); scrollToSection(tab.toLowerCase()); }}
              className={`tab-underline text-xs font-semibold tracking-widest uppercase py-5 flex-shrink-0 transition-colors ${activeTab === tab ? "active" : ""}`}
              style={{ color: activeTab === tab ? GOLD : "rgba(255,255,255,0.4)", borderBottom: activeTab === tab ? `2px solid ${GOLD}` : "2px solid transparent" }}>
              {tab}
            </button>
          ))}
          <div className="ml-auto flex-shrink-0 py-3">
            <Link to={createPageUrl("Contact")} className="text-xs font-semibold tracking-widest uppercase px-6 py-2.5 rounded-full" style={{ background: `linear-gradient(135deg, ${GOLD}, #a07840)`, color: "white" }}>
              Get In Touch
            </Link>
          </div>
        </div>
      </div>

      {/* OVERVIEW SECTION */}
      <section id="overview" className="px-10 md:px-24 py-24" style={{ background: "#0a0a0a" }}>
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-20 items-center">
          <div>
            <div className="flex items-center gap-3 mb-7">
              <div className="h-px w-10" style={{ background: GOLD }} />
              <span className="text-xs tracking-[0.3em] font-semibold uppercase" style={{ color: GOLD }}>About OnePack</span>
            </div>
            <h2 className="font-black text-white leading-[0.9] mb-8" style={{ fontSize: "clamp(2rem, 4vw, 4rem)", letterSpacing: "-0.04em" }}>
              OnePack is a strategic<br />gateway to exceptional<br />real estate.
            </h2>
            <p className="text-white/45 font-light leading-relaxed mb-5 max-w-lg" style={{ fontSize: "0.975rem" }}>
              At the intersection of architectural vision, interior craft, and investment intelligence, OnePack connects clients with properties and design services that genuinely change how people live and work.
            </p>
            <p className="text-white/45 font-light leading-relaxed mb-10 max-w-lg" style={{ fontSize: "0.975rem" }}>
              Already delivering completed projects across 15 countries, we handle architecture, interior design, landscape planning, 3D visualisation, and property consulting — ensuring predictable, at-scale performance that delivers quality and reliability.
            </p>
            <div className="flex items-center gap-4">
              <Link to={createPageUrl("Contact")} className="flex items-center gap-2 text-white text-xs font-semibold px-6 py-3 rounded-full" style={{ background: `linear-gradient(135deg, ${GOLD}, #a07840)` }}>
                Contact Us <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
          <div className="rounded-2xl overflow-hidden" style={{ height: "420px" }}>
            <img src="https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=900&q=90" alt="" className="w-full h-full object-cover" />
          </div>
        </div>
      </section>

      {/* OPEN FOR BUSINESS — tabbed pillar section like Port of NEOM */}
      <section className="bg-black py-0">
        <div className="px-10 md:px-24 py-16 max-w-7xl mx-auto">
          <h2 className="font-black text-white leading-[0.9] mb-4" style={{ fontSize: "clamp(2rem, 4vw, 4rem)", letterSpacing: "-0.04em" }}>
            OnePack is open<br />for business
          </h2>
        </div>

        {/* Pillar tabs */}
        <div className="border-t border-b border-white/8">
          <div className="px-10 md:px-24 flex gap-0">
            {pillars.map((p, i) => (
              <button key={i} onClick={() => setActivePillar(i)}
                className="flex-1 py-5 px-4 text-left text-sm font-semibold transition-all border-r border-white/8 last:border-r-0"
                style={{ color: activePillar === i ? GOLD : "rgba(255,255,255,0.4)", borderBottom: activePillar === i ? `2px solid ${GOLD}` : "2px solid transparent" }}>
                {p.title}
              </button>
            ))}
          </div>
        </div>

        {/* Pillar content */}
        <div className="max-w-7xl mx-auto px-10 md:px-24 py-16">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <p className="text-white/50 font-light leading-relaxed mb-10" style={{ fontSize: "1rem" }}>{pillars[activePillar].desc}</p>
              <Link to={createPageUrl("Services")} className="inline-flex items-center gap-2 text-xs font-semibold tracking-widest uppercase pb-1" style={{ color: GOLD, borderBottom: `1px solid ${GOLD}` }}>
                Explore Services <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
            <div className="rounded-2xl overflow-hidden" style={{ height: "340px" }}>
              <img src={pillars[activePillar].image} alt={pillars[activePillar].title} className="w-full h-full object-cover transition-all duration-500" />
            </div>
          </div>
        </div>
      </section>

      {/* STATS BAR */}
      <section style={{ background: "#111", borderTop: "1px solid rgba(255,255,255,0.05)", borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
        <div className="px-10 md:px-24 py-10 grid grid-cols-2 md:grid-cols-5 gap-0 divide-x divide-white/5">
          {stats.map((s, i) => (
            <div key={i} className="px-8 first:pl-0 text-center">
              <div className="font-black text-white mb-1" style={{ fontSize: "clamp(1.6rem, 3vw, 2.8rem)", letterSpacing: "-0.04em" }}>{s.value}</div>
              <div className="text-white/35 text-xs font-light tracking-wide">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* SERVICES SECTION */}
      <section id="services" className="py-24 bg-black">
        <div className="px-10 md:px-24 max-w-7xl mx-auto">
          <div className="flex items-center gap-3 mb-5">
            <div className="h-px w-10" style={{ background: GOLD }} />
            <span className="text-xs tracking-[0.3em] font-semibold uppercase" style={{ color: GOLD }}>What We Do</span>
          </div>
          <h2 className="font-black text-white leading-[0.9] mb-16" style={{ fontSize: "clamp(2rem, 4vw, 4rem)", letterSpacing: "-0.04em" }}>
            OnePack Services
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((s, i) => (
              <div key={i} className="group rounded-2xl overflow-hidden relative cursor-pointer" style={{ height: "320px" }}>
                <img src={s.img} alt={s.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" style={{ filter: "brightness(0.45)" }} />
                <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(0,0,0,0.92) 0%, rgba(0,0,0,0.3) 50%, transparent 100%)" }} />
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <h3 className="font-black text-white mb-2 text-lg" style={{ letterSpacing: "-0.02em" }}>{s.title}</h3>
                  <p className="text-white/40 text-xs font-light leading-relaxed mb-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">{s.desc}</p>
                  <Link to={createPageUrl("ServiceDetail")} className="inline-flex items-center gap-1.5 text-xs font-semibold tracking-widest uppercase" style={{ color: GOLD }}>
                    Learn More <ArrowRight className="w-3 h-3" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* WHY CHOOSE — dark panel like NEOM */}
      <section style={{ background: "#0d0d0d" }} className="py-24">
        <div className="px-10 md:px-24 max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16 mb-20 items-end">
            <div>
              <div className="flex items-center gap-3 mb-5">
                <div className="h-px w-10" style={{ background: GOLD }} />
                <span className="text-xs tracking-[0.3em] font-semibold uppercase" style={{ color: GOLD }}>Our Advantage</span>
              </div>
              <h2 className="font-black text-white leading-[0.9]" style={{ fontSize: "clamp(2rem, 4vw, 4rem)", letterSpacing: "-0.04em" }}>
                Why Choose<br />OnePack?
              </h2>
            </div>
            <p className="text-white/40 font-light leading-relaxed" style={{ fontSize: "0.975rem" }}>
              Three pillars define the OnePack difference — a strategic approach to location and opportunity, a commitment to sustainable, future-ready design, and a culture of continuous innovation that keeps us at the forefront of global real estate.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-px" style={{ background: "rgba(255,255,255,0.04)" }}>
            {whyChoose.map((w, i) => (
              <div key={i} className="p-10" style={{ background: "#0d0d0d" }}>
                <div className="text-3xl mb-5">{w.icon}</div>
                <h3 className="font-bold text-white mb-4 text-base">{w.title}</h3>
                <p className="text-white/35 text-sm font-light leading-relaxed">{w.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* GALLERY */}
      <section id="gallery" className="py-24 bg-black">
        <div className="px-10 md:px-24 max-w-7xl mx-auto mb-14">
          <div className="flex items-center gap-3 mb-5">
            <div className="h-px w-10" style={{ background: GOLD }} />
            <span className="text-xs tracking-[0.3em] font-semibold uppercase" style={{ color: GOLD }}>Our Work</span>
          </div>
          <h2 className="font-black text-white leading-[0.9] mb-10" style={{ fontSize: "clamp(2rem, 4vw, 4rem)", letterSpacing: "-0.04em" }}>
            Project Gallery
          </h2>
          
          {/* Filters */}
          <div className="flex flex-wrap items-center gap-3">
            {["All", "Residential", "Commercial", "Interior", "Landscape"].map(c => (
              <button key={c} onClick={() => setFilter(c)} className={`px-5 py-2.5 rounded-full text-xs font-semibold tracking-widest uppercase transition-all ${filter === c ? "bg-white text-black" : "bg-white/5 text-white/50 hover:bg-white/10"}`}>
                {c}
              </button>
            ))}
          </div>
        </div>

        {/* Masonry-ish grid */}
        <div className="px-10 md:px-24 max-w-7xl mx-auto grid grid-cols-12 gap-3">
          {[
            { img: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=900&q=90", col: "col-span-12 md:col-span-7", h: "380px", cat: "Residential", title: "Maple Grove House" },
            { img: "https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=700&q=90", col: "col-span-12 md:col-span-5", h: "380px", cat: "Commercial", title: "Apex Tower" },
            { img: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=700&q=90", col: "col-span-12 md:col-span-4", h: "300px", cat: "Landscape", title: "Zen Gardens" },
            { img: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=900&q=90", col: "col-span-12 md:col-span-4", h: "300px", cat: "Interior", title: "Minimalist Loft" },
            { img: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=700&q=90", col: "col-span-12 md:col-span-4", h: "300px", cat: "Residential", title: "Cliffside Retreat" },
            { img: "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=900&q=90", col: "col-span-12 md:col-span-8", h: "320px", cat: "Interior", title: "Oak Finish Suite" },
            { img: "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=700&q=90", col: "col-span-12 md:col-span-4", h: "320px", cat: "Residential", title: "Glass Villa" },
          ].filter(i => filter === "All" || i.cat === filter).map((item, i) => (
            <div key={i} className={`${item.col} rounded-xl overflow-hidden group relative`} style={{ height: item.h }}>
              <img src={item.img} alt="" className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" style={{ filter: "brightness(0.7)" }} />
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-8">
                <div className="text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: GOLD }}>{item.cat}</div>
                <h3 className="font-bold text-white text-xl">{item.title}</h3>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* DOWNLOADS */}
      <section style={{ background: "#0a0a0a" }} className="py-20">
        <div className="px-10 md:px-24 max-w-7xl mx-auto">
          <div className="flex items-center gap-3 mb-5">
            <div className="h-px w-10" style={{ background: GOLD }} />
            <span className="text-xs tracking-[0.3em] font-semibold uppercase" style={{ color: GOLD }}>Resources</span>
          </div>
          <h2 className="font-black text-white leading-[0.9] mb-14" style={{ fontSize: "clamp(1.5rem, 3vw, 3rem)", letterSpacing: "-0.04em" }}>
            Downloads
          </h2>
          <div className="grid md:grid-cols-2 gap-5">
            {downloads.map((d, i) => (
              <div key={i} className="flex items-center gap-5 p-5 rounded-2xl group transition-all hover:bg-white/[0.03]" style={{ border: "1px solid rgba(255,255,255,0.07)" }}>
                <div className="w-20 h-16 rounded-xl overflow-hidden flex-shrink-0">
                  <img src={d.img} alt={d.title} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-semibold tracking-widest uppercase mb-1" style={{ color: GOLD }}>PDF</div>
                  <h4 className="font-bold text-white text-sm mb-0.5 truncate">{d.title}</h4>
                  <div className="text-white/30 text-xs font-light">{d.date} · {d.size}</div>
                </div>
                <button className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 transition-all group-hover:scale-110" style={{ background: `linear-gradient(135deg, ${GOLD}, #a07840)` }}>
                  <Download className="w-4 h-4 text-white" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* NEWS */}
      <section id="news" className="py-24 bg-black">
        <div className="px-10 md:px-24 max-w-7xl mx-auto">
          <div className="flex items-end justify-between mb-14">
            <div>
              <div className="flex items-center gap-3 mb-5">
                <div className="h-px w-10" style={{ background: GOLD }} />
                <span className="text-xs tracking-[0.3em] font-semibold uppercase" style={{ color: GOLD }}>Latest News</span>
              </div>
              <h2 className="font-black text-white leading-[0.9]" style={{ fontSize: "clamp(2rem, 4vw, 4rem)", letterSpacing: "-0.04em" }}>
                OnePack News
              </h2>
            </div>
            <Link to={createPageUrl("Contact")} className="hidden md:flex items-center gap-2 text-xs font-semibold tracking-widest uppercase pb-1" style={{ color: GOLD, borderBottom: `1px solid ${GOLD}` }}>
              Load More
            </Link>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {news.map((n, i) => (
              <div key={i} className="group cursor-pointer">
                <div className="rounded-2xl overflow-hidden mb-5" style={{ height: "220px" }}>
                  <img src={n.img} alt={n.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" style={{ filter: "brightness(0.6)" }} />
                </div>
                <div className="text-xs font-semibold tracking-widest uppercase mb-2" style={{ color: GOLD }}>{n.tag}</div>
                <h3 className="font-bold text-white text-base leading-snug mb-3">{n.title}</h3>
                <div className="flex items-center justify-between">
                  <span className="text-white/30 text-xs font-light">{n.date}</span>
                  <ArrowRight className="w-4 h-4 text-white/30 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SOCIAL FOLLOW */}
      <section style={{ background: "#0a0a0a", borderTop: "1px solid rgba(255,255,255,0.05)" }} className="py-10">
        <div className="px-10 md:px-24 max-w-7xl mx-auto flex flex-wrap items-center gap-5">
          <span className="text-white/30 text-xs font-light tracking-widest uppercase">Follow Us</span>
          {["LinkedIn", "Instagram", "Facebook", "Twitter", "YouTube"].map(s => (
            <a key={s} href="#" className="text-xs font-semibold tracking-wide transition-colors hover:text-white" style={{ color: "rgba(255,255,255,0.4)" }}>{s}</a>
          ))}
        </div>
      </section>

      <REFooter />
    </div>
  );
}