import React, { useState } from "react";
import RENav from "@/components/realestate/RENav";
import REFooter from "@/components/realestate/REFooter";
import { ArrowRight, Phone, Mail, MapPin, Clock, Send, CheckCircle } from "lucide-react";

const GOLD = "#c9a76c";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", service: "", subject: "", message: "" });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <div className="bg-white text-gray-900 overflow-x-hidden" style={{ fontFamily: "'Outfit', sans-serif" }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap');`}</style>
      <RENav />

      {/* HERO */}
      <section className="relative w-full h-screen min-h-[700px] overflow-hidden bg-black">
        <img src="https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=1920&q=90" alt="" className="w-full h-full object-cover" style={{ filter: "brightness(0.25)" }} />
        <div className="absolute inset-0" style={{ background: "linear-gradient(to bottom, rgba(0,0,0,0.4) 0%, rgba(0,0,0,0.8) 100%)" }} />
        <div className="absolute inset-0 flex flex-col justify-end px-10 md:px-24 pb-20">
          <div className="flex items-center gap-3 mb-6">
            <div className="h-px w-10" style={{ background: GOLD }} />
            <span className="text-xs tracking-[0.35em] font-semibold uppercase" style={{ color: GOLD }}>Reach Us</span>
          </div>
          <h1 className="font-black text-white leading-[0.88] mb-8" style={{ fontSize: "clamp(4rem, 9vw, 10rem)", letterSpacing: "-0.04em" }}>
            Let's Start<br />a Conversation.
          </h1>
          <p className="text-white/40 font-light max-w-lg leading-relaxed" style={{ fontSize: "1.05rem" }}>
            Whether you're ready to begin a project or simply want to explore possibilities — we're here to listen, guide, and deliver.
          </p>
        </div>
      </section>

      {/* CONTACT INFO ROW */}
      <section className="bg-black border-b border-white/5">
        <div className="px-10 md:px-24 py-10 grid grid-cols-2 md:grid-cols-4 gap-0 divide-x divide-white/5">
          {[
            { icon: Phone, label: "Phone", value: "+123 456 789", sub: "Mon–Fri 9am–6pm" },
            { icon: Mail, label: "Email", value: "hello@onepack.com", sub: "2-hour response" },
            { icon: MapPin, label: "Address", value: "123 Main St, NY", sub: "By appointment" },
            { icon: Clock, label: "Hours", value: "Mon–Fri, 9–6pm", sub: "Weekend by appt." },
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-4 px-8 first:pl-0">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: "rgba(201,167,108,0.12)" }}>
                <item.icon className="w-4 h-4" style={{ color: GOLD }} />
              </div>
              <div>
                <div className="text-white/35 text-xs font-light mb-0.5">{item.label}</div>
                <div className="text-white text-sm font-semibold">{item.value}</div>
                <div className="text-white/25 text-xs font-light">{item.sub}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FORM + MAP */}
      <section className="bg-white px-10 md:px-24 py-24">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-20 items-start">
          {/* Left: copy */}
          <div>
            <div className="flex items-center gap-3 mb-7">
              <div className="h-px w-10" style={{ background: GOLD }} />
              <span className="text-xs tracking-[0.3em] font-semibold uppercase" style={{ color: GOLD }}>Send a Message</span>
            </div>
            <h2 className="font-black text-gray-900 leading-[0.9] mb-8" style={{ fontSize: "clamp(2.2rem, 4vw, 4rem)", letterSpacing: "-0.04em" }}>
              We'd Love to<br />Hear From You.
            </h2>
            <p className="text-gray-400 font-light leading-relaxed mb-10 max-w-md" style={{ fontSize: "0.975rem" }}>
              Our team of experts is available to discuss your project, answer questions, and guide you through every step of the process.
            </p>

            {/* Offices */}
            <div className="space-y-5">
              {[
                { city: "New York", address: "123 Fifth Avenue, NY 10011", phone: "+1 212 456 7890" },
                { city: "Los Angeles", address: "456 Wilshire Blvd, Beverly Hills, CA", phone: "+1 310 456 7890" },
                { city: "London", address: "78 Brompton Road, Knightsbridge", phone: "+44 20 7890 1234" },
              ].map((o, i) => (
                <div key={i} className="flex items-start gap-5 py-5 border-b border-gray-80" style={{ borderColor: "rgba(0,0,0,0.06)" }}>
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: "rgba(201,167,108,0.08)" }}>
                    <MapPin className="w-4 h-4" style={{ color: GOLD }} />
                  </div>
                  <div>
                    <div className="font-bold text-gray-900 mb-0.5">{o.city}</div>
                    <div className="text-gray-400 text-sm font-light">{o.address}</div>
                    <div className="text-gray-400 text-sm font-light flex items-center gap-1.5 mt-0.5"><Phone className="w-3 h-3" />{o.phone}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right: form */}
          <div>
            {sent ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-20">
                <div className="w-20 h-20 rounded-full flex items-center justify-center mb-6" style={{ background: `rgba(201,167,108,0.12)` }}>
                  <CheckCircle className="w-10 h-10" style={{ color: GOLD }} />
                </div>
                <h3 className="font-black text-gray-900 text-2xl mb-3" style={{ letterSpacing: "-0.03em" }}>Message Sent!</h3>
                <p className="text-gray-400 font-light mb-8">We'll get back to you within 2 hours.</p>
                <button onClick={() => setSent(false)} className="text-sm font-semibold" style={{ color: GOLD }}>Send another message →</button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-600 mb-2 tracking-wide">Full Name *</label>
                    <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} required className="w-full px-5 py-4 rounded-xl text-sm font-light text-gray-900 focus:outline-none transition-all" style={{ border: "1.5px solid rgba(0,0,0,0.1)", background: "#fafafa" }} placeholder="John Doe" onFocus={e => e.target.style.borderColor = GOLD} onBlur={e => e.target.style.borderColor = "rgba(0,0,0,0.1)"} />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-600 mb-2 tracking-wide">Email *</label>
                    <input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} required className="w-full px-5 py-4 rounded-xl text-sm font-light text-gray-900 focus:outline-none transition-all" style={{ border: "1.5px solid rgba(0,0,0,0.1)", background: "#fafafa" }} placeholder="john@email.com" onFocus={e => e.target.style.borderColor = GOLD} onBlur={e => e.target.style.borderColor = "rgba(0,0,0,0.1)"} />
                  </div>
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-600 mb-2 tracking-wide">Phone</label>
                    <input value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} className="w-full px-5 py-4 rounded-xl text-sm font-light text-gray-900 focus:outline-none" style={{ border: "1.5px solid rgba(0,0,0,0.1)", background: "#fafafa" }} placeholder="+1 234 567 890" onFocus={e => e.target.style.borderColor = GOLD} onBlur={e => e.target.style.borderColor = "rgba(0,0,0,0.1)"} />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-600 mb-2 tracking-wide">Service Interest</label>
                    <select value={form.service} onChange={e => setForm(f => ({ ...f, service: e.target.value }))} className="w-full px-5 py-4 rounded-xl text-sm font-light text-gray-500 focus:outline-none appearance-none" style={{ border: "1.5px solid rgba(0,0,0,0.1)", background: "#fafafa" }}>
                      <option value="">Select a service</option>
                      {["Architecture Design", "Interior Design", "Landscape Planning", "Visualisation", "Furniture Design", "Lighting Design", "Property Purchase"].map(s => <option key={s}>{s}</option>)}
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-2 tracking-wide">Subject</label>
                  <input value={form.subject} onChange={e => setForm(f => ({ ...f, subject: e.target.value }))} className="w-full px-5 py-4 rounded-xl text-sm font-light text-gray-900 focus:outline-none" style={{ border: "1.5px solid rgba(0,0,0,0.1)", background: "#fafafa" }} placeholder="How can we help?" onFocus={e => e.target.style.borderColor = GOLD} onBlur={e => e.target.style.borderColor = "rgba(0,0,0,0.1)"} />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-2 tracking-wide">Message *</label>
                  <textarea value={form.message} onChange={e => setForm(f => ({ ...f, message: e.target.value }))} required rows={5} className="w-full px-5 py-4 rounded-xl text-sm font-light text-gray-900 focus:outline-none resize-none" style={{ border: "1.5px solid rgba(0,0,0,0.1)", background: "#fafafa" }} placeholder="Tell us about your project, timeline, and vision..." onFocus={e => e.target.style.borderColor = GOLD} onBlur={e => e.target.style.borderColor = "rgba(0,0,0,0.1)"} />
                </div>
                <button type="submit" className="w-full flex items-center justify-center gap-3 text-white font-semibold py-5 rounded-xl transition-all hover:opacity-90 text-sm" style={{ background: `linear-gradient(135deg, ${GOLD}, #a07840)` }}>
                  Send Message <Send className="w-4 h-4" />
                </button>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* MAP */}
      <section className="px-10 md:px-24 pb-20 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="w-full rounded-2xl overflow-hidden flex items-center justify-center" style={{ height: "380px", background: "linear-gradient(135deg, #f5f5f5, #ebebeb)" }}>
            <div className="text-center">
              <MapPin className="w-12 h-12 mx-auto mb-4" style={{ color: GOLD }} />
              <p className="text-gray-500 font-light">123 Main Street, New York, NY 10001</p>
              <p className="text-gray-400 text-sm font-light mt-1">Our flagship office</p>
            </div>
          </div>
        </div>
      </section>

      <REFooter />
    </div>
  );
}