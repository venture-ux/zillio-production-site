import React, { useState } from "react";
import RENav from "@/components/realestate/RENav";
import REFooter from "@/components/realestate/REFooter";
import { ArrowRight, Bed, Bath, Maximize, MapPin, Phone, Mail, Calendar, Wifi, Dumbbell, Waves, ParkingSquare, Trees, Flame, Star, ChevronLeft, ChevronRight, Heart, Share2 } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const GOLD = "#c9a76c";

const images = [
  "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1400&q=90",
  "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=1400&q=90",
  "https://images.unsplash.com/photo-1616594039964-ae9021a400a0?w=1400&q=90",
  "https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=1400&q=90",
];

const amenities = [
  { icon: Bed, label: "4 Bedrooms" }, { icon: Bath, label: "3 Bathrooms" }, { icon: Maximize, label: "3,200 Sq Ft" },
  { icon: ParkingSquare, label: "2-Car Garage" }, { icon: Waves, label: "Infinity Pool" }, { icon: Dumbbell, label: "Home Gym" },
  { icon: Trees, label: "Private Garden" }, { icon: Wifi, label: "Smart Home" }, { icon: Flame, label: "Fireplace" },
];

const specs = [
  { label: "Property Type", value: "Single Family" },
  { label: "Year Built", value: "2024" },
  { label: "Lot Size", value: "1.4 Acres" },
  { label: "Garage", value: "2 Cars" },
  { label: "Status", value: "For Sale" },
  { label: "Agent", value: "Jeremy Lestor" },
];

export default function PropertyDetail() {
  const [activeImg, setActiveImg] = useState(0);
  const [liked, setLiked] = useState(false);
  const [lightbox, setLightbox] = useState(false);

  return (
    <div className="bg-white text-gray-900 overflow-x-hidden" style={{ fontFamily: "'Outfit', sans-serif" }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap');`}</style>
      <RENav />

      {/* FULL-BLEED HERO IMAGE GALLERY */}
      <section className="relative w-full bg-black overflow-hidden" style={{ height: "85vh", minHeight: "600px" }}>
        {images.map((img, i) => (
          <div key={i} className="absolute inset-0 transition-opacity duration-700 cursor-pointer" style={{ opacity: i === activeImg ? 1 : 0 }} onClick={() => setLightbox(true)}>
            <img src={img} alt="" className="w-full h-full object-cover transition-transform hover:scale-105 duration-1000" style={{ filter: "brightness(0.6)" }} />
          </div>
        ))}
        <div className="absolute inset-0" style={{ background: "linear-gradient(to bottom, rgba(0,0,0,0.3) 0%, rgba(0,0,0,0.7) 100%)" }} />

        {/* Breadcrumb */}
        <div className="absolute top-24 left-10 md:left-24">
          <span className="text-xs font-semibold tracking-widest uppercase" style={{ color: GOLD }}>
            Portfolio <span className="text-white/30">›</span> The Maple Grove House
          </span>
        </div>

        {/* Property info overlay */}
        <div className="absolute bottom-0 left-0 right-0 px-10 md:px-24 pb-12">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-8">
            <div>
              <div className="text-xs font-semibold tracking-widest uppercase mb-3" style={{ color: GOLD }}>Single Family · Maple Grove, MN</div>
              <h1 className="font-black text-white leading-[0.88] mb-4" style={{ fontSize: "clamp(2.5rem, 6vw, 6rem)", letterSpacing: "-0.04em" }}>
                The Maple<br />Grove House
              </h1>
              <div className="flex items-center gap-2 mb-4">
                {Array(5).fill(0).map((_, i) => <Star key={i} className="w-4 h-4" fill={GOLD} stroke="none" />)}
                <span className="text-white/40 text-xs font-light ml-1">(48 verified reviews)</span>
              </div>
            </div>
            <div className="text-right">
              <div className="font-black text-white" style={{ fontSize: "clamp(2rem, 4vw, 3.5rem)", letterSpacing: "-0.04em" }}>$1,250,000</div>
              <div className="text-white/40 text-xs font-light mt-1">Starting Price</div>
              <div className="flex gap-3 mt-5 justify-end">
                <button onClick={() => setLiked(l => !l)} className="w-11 h-11 rounded-full flex items-center justify-center" style={{ background: "rgba(255,255,255,0.12)", backdropFilter: "blur(10px)" }}>
                  <Heart className="w-5 h-5" fill={liked ? "#ef4444" : "none"} stroke={liked ? "#ef4444" : "white"} />
                </button>
                <button className="w-11 h-11 rounded-full flex items-center justify-center" style={{ background: "rgba(255,255,255,0.12)", backdropFilter: "blur(10px)" }}>
                  <Share2 className="w-5 h-5 text-white" />
                </button>
                <Link to={createPageUrl("Contact")} className="flex items-center gap-2 text-white text-sm font-semibold px-7 py-3 rounded-full" style={{ background: `linear-gradient(135deg, ${GOLD}, #a07840)` }}>
                  <Calendar className="w-4 h-4" /> Schedule Visit
                </Link>
              </div>
            </div>
          </div>
          {/* Thumbnail strip */}
          <div className="flex gap-3 mt-8">
            {images.map((img, i) => (
              <button key={i} onClick={() => setActiveImg(i)} className="rounded-xl overflow-hidden flex-shrink-0 transition-all" style={{ width: "80px", height: "56px", outline: activeImg === i ? `2px solid ${GOLD}` : "2px solid transparent", outlineOffset: "2px" }}>
                <img src={img} alt="" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        </div>

        {/* Nav arrows */}
        <button onClick={() => setActiveImg(i => (i - 1 + images.length) % images.length)} className="absolute left-6 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full flex items-center justify-center" style={{ background: "rgba(255,255,255,0.12)", backdropFilter: "blur(10px)" }}>
          <ChevronLeft className="w-5 h-5 text-white" />
        </button>
        <button onClick={() => setActiveImg(i => (i + 1) % images.length)} className="absolute right-6 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full flex items-center justify-center" style={{ background: "rgba(255,255,255,0.12)", backdropFilter: "blur(10px)" }}>
          <ChevronRight className="w-5 h-5 text-white" />
        </button>
      </section>

      {/* CONTENT + SIDEBAR */}
      <section className="px-10 md:px-24 py-20 max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-3 gap-16">
          {/* Main */}
          <div className="lg:col-span-2 space-y-16">

            {/* Overview & Specs combined as in benchmark */}
            <div className="border-b border-gray-100 pb-12">
              <h2 className="font-bold text-gray-900 mb-6" style={{ fontSize: "1.5rem", letterSpacing: "-0.02em" }}>Property Overview</h2>
              <p className="text-gray-500 font-light leading-relaxed mb-10 text-sm">
                The Maple Grove House is a masterwork of contemporary residential design, set across a wooded hillside lot of 1.4 acres. The floor plan flows organically from the entrance hall through open living and dining spaces, extending seamlessly to a wrap-around terrace and private pool. Materials were selected for their tactile quality — exposed concrete, white oak flooring, and hand-laid stone feature walls create a palette of warmth and precision.
              </p>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-y-8 gap-x-4">
                {specs.slice(0, 4).map((s, i) => (
                  <div key={i}>
                    <div className="text-gray-400 text-xs font-semibold uppercase tracking-widest mb-1.5">{s.label}</div>
                    <div className="font-bold text-gray-900 text-lg">{s.value}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Interior Details */}
            <div className="border-b border-gray-100 pb-12">
              <h2 className="font-bold text-gray-900 mb-6" style={{ fontSize: "1.5rem", letterSpacing: "-0.02em" }}>Interior Details</h2>
              <div className="grid md:grid-cols-5 gap-8 items-center">
                <div className="md:col-span-3 space-y-4">
                  <p className="text-gray-500 font-light leading-relaxed text-sm">
                    The interior balances proportion, scale and carefully curated materials. Hand-poured concrete columns serve as structural centrepieces, while white oak floors bring warmth and acoustic dampening to the living zones.
                  </p>
                  <p className="text-gray-500 font-light leading-relaxed text-sm">
                    <strong>Custom Kitchen & Dining:</strong> Fully integrated appliances, custom millwork, and an oversized island designed for both entertaining and practical family use.
                  </p>
                  <p className="text-gray-500 font-light leading-relaxed text-sm">
                    <strong>Primary Suite:</strong> Spanning the entire east wing, it features a bespoke walk-in wardrobe, and a spa-like en suite with heated stone floors and a soaking tub overlooking the gardens.
                  </p>
                </div>
                <div className="md:col-span-2">
                  <div className="rounded-xl overflow-hidden aspect-[4/3]">
                    <img src="https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=800&q=90" alt="Interior" className="w-full h-full object-cover" />
                  </div>
                </div>
              </div>
            </div>

            {/* Features & Amenities */}
            <div className="border-b border-gray-100 pb-12">
              <h2 className="font-bold text-gray-900 mb-6" style={{ fontSize: "1.5rem", letterSpacing: "-0.02em" }}>Features & Amenities</h2>
              <div className="bg-gray-50 rounded-2xl p-8 border border-gray-100">
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-y-8 gap-x-4">
                  {amenities.map((a, i) => (
                    <div key={i} className="flex flex-col items-center text-center gap-3">
                      <div className="w-12 h-12 rounded-full flex items-center justify-center bg-white shadow-sm border border-gray-100">
                        <a.icon className="w-5 h-5 text-gray-700" strokeWidth={1.5} />
                      </div>
                      <span className="text-xs font-medium text-gray-600">{a.label}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Image gallery */}
            <div>
              <div className="flex items-center gap-3 mb-7">
                <div className="h-px w-10" style={{ background: GOLD }} />
                <span className="text-xs tracking-[0.3em] font-semibold uppercase" style={{ color: GOLD }}>Property Gallery</span>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {images.map((img, i) => (
                  <div key={i} className="rounded-2xl overflow-hidden cursor-pointer group" onClick={() => setActiveImg(i)} style={{ height: i === 0 || i === 3 ? "280px" : "200px" }}>
                    <img src={img} alt="" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                  </div>
                ))}
              </div>
            </div>

            {/* Location */}
            <div>
              <div className="flex items-center gap-3 mb-7">
                <div className="h-px w-10" style={{ background: GOLD }} />
                <span className="text-xs tracking-[0.3em] font-semibold uppercase" style={{ color: GOLD }}>Neighbourhood</span>
              </div>
              <div className="space-y-3 mb-6">
                {["0.4 mi — Maple Grove Elementary School", "1.2 mi — Central Park & Nature Reserve", "2.8 mi — Shopping & Dining District", "5.0 mi — Minneapolis International Airport"].map((l, i) => (
                  <div key={i} className="flex items-center gap-3 text-sm text-gray-500 font-light py-3 border-b border-gray-50">
                    <MapPin className="w-3.5 h-3.5 flex-shrink-0" style={{ color: GOLD }} />{l}
                  </div>
                ))}
              </div>
              <div className="w-full rounded-2xl overflow-hidden flex items-center justify-center" style={{ height: "300px", background: "linear-gradient(135deg, #f3f4f6, #e9eaec)" }}>
                <div className="text-center">
                  <MapPin className="w-8 h-8 mx-auto mb-2" style={{ color: GOLD }} />
                  <p className="text-gray-500 text-sm font-light">Maple Valley Tower, MN 55100</p>
                </div>
              </div>
            </div>
          </div>

          {/* Sticky Sidebar */}
          <div>
            <div className="md:sticky" style={{ top: "100px" }}>
              {/* Agent */}
              <div className="p-7 rounded-2xl mb-5 shadow-sm" style={{ border: "1px solid rgba(0,0,0,0.07)" }}>
                <h4 className="font-bold text-gray-900 mb-5">Listing Agent</h4>
                <div className="flex items-center gap-4 mb-6">
                  <img src="https://images.unsplash.com/photo-1560250097-0b93528c311a?w=80&q=90" alt="Agent" className="w-14 h-14 rounded-full object-cover" style={{ border: `2px solid ${GOLD}` }} />
                  <div>
                    <div className="font-bold text-gray-900">Jeremy Lestor</div>
                    <div className="text-xs font-medium mt-0.5" style={{ color: GOLD }}>Principal Agent</div>
                  </div>
                </div>
                <div className="space-y-3 mb-6">
                  <div className="flex items-center gap-2.5 text-sm text-gray-500 font-light"><Phone className="w-4 h-4 flex-shrink-0" style={{ color: GOLD }} /> +123 456 789</div>
                  <div className="flex items-center gap-2.5 text-sm text-gray-500 font-light"><Mail className="w-4 h-4 flex-shrink-0" style={{ color: GOLD }} /> jeremy@onepack.com</div>
                </div>
                <Link to={createPageUrl("Contact")} className="w-full flex items-center justify-center gap-2 text-white text-sm font-semibold py-4 rounded-xl mb-3" style={{ background: `linear-gradient(135deg, ${GOLD}, #a07840)` }}>
                  Schedule a Visit <Calendar className="w-4 h-4" />
                </Link>
                <button className="w-full py-3.5 rounded-xl text-sm font-light text-gray-500 hover:bg-gray-50 transition-all" style={{ border: "1px solid rgba(0,0,0,0.1)" }}>
                  Request Info
                </button>
              </div>

              {/* Quick specs card */}
              <div className="p-7 rounded-2xl" style={{ background: `linear-gradient(135deg, rgba(201,167,108,0.08), rgba(160,120,64,0.05))`, border: `1px solid rgba(201,167,108,0.2)` }}>
                <h4 className="font-bold text-gray-900 mb-4 text-sm">Property Summary</h4>
                <div className="grid grid-cols-3 gap-4 text-center">
                  {[{ v: "4", l: "Beds" }, { v: "3", l: "Baths" }, { v: "3,200", l: "Sq Ft" }].map((s, i) => (
                    <div key={i}>
                      <div className="font-black text-gray-900 text-xl" style={{ letterSpacing: "-0.02em" }}>{s.v}</div>
                      <div className="text-gray-400 text-xs font-light">{s.l}</div>
                    </div>
                  ))}
                </div>
                <div className="border-t border-black/5 mt-5 pt-5 text-center">
                  <div className="text-gray-400 text-xs font-light">OnePack Real Estate</div>
                  <div className="text-xs font-light text-gray-400 mt-0.5">Maple Valley Tower, MN 55100</div>
                </div>
              </div>

              {/* Mortgage Calculator */}
              <div className="p-7 rounded-2xl mt-5 shadow-sm" style={{ border: "1px solid rgba(0,0,0,0.07)" }}>
                <h4 className="font-bold text-gray-900 mb-5 text-sm">Mortgage Calculator</h4>
                <div className="space-y-4">
                  <div>
                    <label className="text-xs text-gray-500 font-medium mb-1 flex justify-between">
                      <span>Property Price</span>
                      <span id="price-val" className="text-gray-900 font-semibold">$1,250,000</span>
                    </label>
                    <input type="range" min="500000" max="5000000" step="50000" defaultValue="1250000" className="w-full accent-[#c9a76c]" onChange={(e) => { 
                      document.getElementById('price-val').innerText = '$' + parseInt(e.target.value).toLocaleString();
                      const price = parseInt(e.target.value);
                      const dp = document.getElementById('dp-range').value;
                      const r = 5.5 / 100 / 12;
                      const n = 30 * 12;
                      const p = price - dp;
                      const m = p > 0 ? (p * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1) : 0;
                      document.getElementById('monthly-val').innerText = '$' + Math.round(m).toLocaleString();
                    }} />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium mb-1 flex justify-between">
                      <span>Down Payment</span>
                      <span id="dp-val" className="text-gray-900 font-semibold">$250,000</span>
                    </label>
                    <input type="range" id="dp-range" min="0" max="1000000" step="10000" defaultValue="250000" className="w-full accent-[#c9a76c]" onChange={(e) => { 
                      document.getElementById('dp-val').innerText = '$' + parseInt(e.target.value).toLocaleString();
                      const price = parseInt(document.querySelector('input[type="range"]').value);
                      const dp = parseInt(e.target.value);
                      const r = 5.5 / 100 / 12;
                      const n = 30 * 12;
                      const p = price - dp;
                      const m = p > 0 ? (p * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1) : 0;
                      document.getElementById('monthly-val').innerText = '$' + Math.round(m).toLocaleString();
                    }} />
                  </div>
                  <div className="pt-4 border-t border-gray-100 flex justify-between items-center">
                    <span className="text-sm text-gray-500">Est. Monthly</span>
                    <span className="font-bold text-lg" style={{ color: GOLD }} id="monthly-val">$5,678</span>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </section>

      {/* ANY INQUIRY — clean light design as benchmark */}
      <section className="bg-white py-32 border-t border-gray-100">
        <div className="max-w-5xl mx-auto px-10 md:px-24">
          <div className="text-center mb-16 relative">
            <h2 className="font-black text-gray-900 leading-none" style={{ fontSize: "clamp(4rem, 10vw, 8rem)", letterSpacing: "-0.04em" }}>
              Any Inquiry
            </h2>
          </div>
          
          <div className="grid md:grid-cols-3 gap-12">
            <div className="md:col-span-1 space-y-6">
              <div>
                <div className="text-xs font-semibold text-gray-400 uppercase tracking-widest mb-1">Email</div>
                <a href="#" className="text-gray-900 font-medium">hello@onepack.com</a>
              </div>
              <div>
                <div className="text-xs font-semibold text-gray-400 uppercase tracking-widest mb-1">Phone</div>
                <div className="text-gray-900 font-medium">+123 456 789 0</div>
              </div>
              <div>
                <div className="text-xs font-semibold text-gray-400 uppercase tracking-widest mb-1">Location</div>
                <div className="text-gray-900 font-medium text-sm leading-relaxed">14956VAL, Apple Valley Tower, MN 55120</div>
              </div>
            </div>
            
            <div className="md:col-span-2">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                {["Your Name*", "Email Address*", "Phone Number", "Subject"].map(ph => (
                  <input key={ph} placeholder={ph} className="px-5 py-4 rounded-xl text-sm focus:outline-none bg-gray-50 border border-gray-100 text-gray-900 placeholder-gray-400 focus:border-gray-300 transition-colors" />
                ))}
              </div>
              <textarea rows={5} placeholder="Message*" className="w-full px-5 py-4 rounded-xl text-sm focus:outline-none bg-gray-50 border border-gray-100 text-gray-900 placeholder-gray-400 focus:border-gray-300 transition-colors mb-6 resize-none" />
              <button className="w-full bg-black text-white text-sm font-semibold py-4 rounded-xl hover:bg-gray-800 transition-colors">
                Send Message
              </button>
            </div>
          </div>
        </div>
      </section>

      <REFooter />

      {/* LIGHTBOX */}
      {lightbox && (
        <div className="fixed inset-0 z-[100] bg-black/95 flex items-center justify-center backdrop-blur-sm">
          <button onClick={() => setLightbox(false)} className="absolute top-8 right-8 text-white/50 hover:text-white"><Maximize className="w-8 h-8" /></button>
          <img src={images[activeImg]} className="max-w-[90vw] max-h-[90vh] object-contain rounded-lg shadow-2xl" alt="" />
          <button onClick={() => setActiveImg(i => (i - 1 + images.length) % images.length)} className="absolute left-8 top-1/2 -translate-y-1/2 w-14 h-14 rounded-full flex items-center justify-center bg-white/10 hover:bg-white/20 transition-all">
            <ChevronLeft className="w-8 h-8 text-white" />
          </button>
          <button onClick={() => setActiveImg(i => (i + 1) % images.length)} className="absolute right-8 top-1/2 -translate-y-1/2 w-14 h-14 rounded-full flex items-center justify-center bg-white/10 hover:bg-white/20 transition-all">
            <ChevronRight className="w-8 h-8 text-white" />
          </button>
        </div>
      )}
    </div>
  );
}