import React, { useState, useEffect, useRef } from "react";
import RENav from "@/components/realestate/RENav";
import REFooter from "@/components/realestate/REFooter";
import { ArrowRight, Check, ChevronDown, ChevronUp, Maximize, BedDouble, Layers, Star } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const GOLD = "#c9a76c";

const servicesList = [
  { title: "Architecture Design", desc: "We design homes that transcend trends — timeless architectural solutions that respond to the land, the light, and the lives they shelter.", img: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=900&q=90", price: "$45,000" },
  { title: "Interior Design", desc: "Our interior design team crafts environments that are as functional as they are beautiful — where each element tells a coherent, personal story.", img: "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=900&q=90", price: "$22,000" },
  { title: "Landscape Planning", desc: "From intimate courtyard gardens to expansive estate grounds, we design outdoor environments that celebrate the natural world.", img: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=900&q=90", price: "$12,000" },
  { title: "Visualisation Consult", desc: "Photorealistic 3D renderings, animated walkthroughs, and virtual reality experiences that make your vision undeniably real.", img: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=900&q=90", price: "$8,000" },
  { title: "Property Consultancy", desc: "Our property consultants bring deep market knowledge and negotiation expertise to every deal — ensuring you invest wisely.", img: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=900&q=90", price: "$5,000" },
  { title: "Architecture Support", desc: "Comprehensive architectural support — from initial planning permission through technical coordination and on-site supervision.", img: "https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=900&q=90", price: "$18,000" }
];

const featuresList = ["Planning", "Design Concept", "Architecture", "Management", "Floor Plan", "Construction"];

const FadeIn = ({ children, delay = 0, className = "" }) => {
  const [isVisible, setVisible] = useState(false);
  const domRef = useRef();
  useEffect(() => {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => { if (entry.isIntersecting) setVisible(true); });
    }, { threshold: 0.1 });
    const currentRef = domRef.current;
    if (currentRef) observer.observe(currentRef);
    return () => { if (currentRef) observer.disconnect(); };
  }, []);
  return (
    <div ref={domRef} className={`transition-all duration-1000 ease-out ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-16'} ${className}`} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
};

export default function Services() {
  return (
    <div className="bg-[#fafafa] text-gray-900 overflow-x-hidden" style={{ fontFamily: "'Outfit', sans-serif" }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap');`}</style>
      <RENav />

      {/* HERO */}
      <section className="relative w-full overflow-hidden bg-black" style={{ height: "45vh", minHeight: "400px" }}>
        <img src="https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=1920&q=90" alt="" className="w-full h-full object-cover" style={{ filter: "brightness(0.3)" }} />
        <div className="absolute inset-0" style={{ background: "linear-gradient(to right, rgba(0,0,0,0.8) 0%, transparent 100%)" }} />
        <div className="absolute inset-0 flex flex-col justify-center px-10 md:px-24">
          <div className="text-xs font-semibold tracking-widest uppercase text-gray-400 mb-5">
            Home <span className="mx-3 text-white/20">-</span> <span className="text-white">Services</span>
          </div>
          <h1 className="font-black text-white leading-[1.05]" style={{ fontSize: "clamp(2.5rem, 5vw, 4.5rem)", letterSpacing: "-0.02em", maxWidth: "700px" }}>
            Tailored Real Estate Solutions To Meet Every Need
          </h1>
        </div>
      </section>

      {/* FIXED SIDE DOTS */}
      <div className="fixed right-8 top-1/2 -translate-y-1/2 z-50 hidden xl:flex flex-col gap-3">
        {[0, 1, 2, 3, 4, 5, 6, 7].map(i => (
          <div key={i} className="w-3 h-3 rounded-full bg-black border-[2.5px] border-white shadow-sm cursor-pointer hover:scale-150 transition-transform" />
        ))}
      </div>

      {/* SERVICES LIST */}
      <section className="py-24 px-6 md:px-14 pb-48">
        <div className="max-w-[70rem] mx-auto flex flex-col gap-24 relative">
          {servicesList.map((s, i) => (
            <div 
              key={i} 
              className="sticky w-full transition-transform duration-500 ease-out"
              style={{ top: `calc(100px + ${i * 40}px)`, zIndex: i }}
            >
              <div className="flex flex-col lg:flex-row bg-white rounded-none p-6 shadow-[0_-10px_40px_-15px_rgba(0,0,0,0.1)] border border-gray-100 transition-shadow">
                <div className="w-full lg:w-[45%] h-[350px] overflow-hidden relative group cursor-pointer">
                  <img src={s.img} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000 ease-out"/>
                </div>
                <div className="w-full lg:w-[55%] p-8 lg:p-12 flex flex-col justify-center">
                  <h3 className="text-3xl font-black text-gray-900 mb-5" style={{ letterSpacing: "-0.02em" }}>{s.title}</h3>
                  <p className="text-gray-500 text-sm font-light leading-relaxed mb-8">{s.desc}</p>
                  <div className="grid grid-cols-2 gap-y-4 gap-x-6 mb-10">
                    {featuresList.map((f, j) => (
                      <div key={j} className="flex items-center gap-3">
                        <div className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0" style={{ border: `1px solid ${GOLD}` }}>
                          <Check size={12} style={{ color: GOLD }} strokeWidth={3}/>
                        </div>
                        <span className="text-sm font-medium text-gray-700">{f}</span>
                      </div>
                    ))}
                  </div>
                  <div className="flex flex-wrap items-center gap-6 mt-auto pt-6 border-t border-gray-50">
                    <Link to={createPageUrl("ServiceDetail")} className="bg-black text-white text-xs font-bold uppercase tracking-widest px-8 py-4 hover:bg-gray-800 transition-colors">
                      Discover More
                    </Link>
                    <span className="text-gray-400 text-sm font-medium">Start from <span className="text-gray-900 font-bold ml-1">{s.price}</span></span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* TESTIMONIALS & BENTO */}
      <section className="py-12 px-6 md:px-14 bg-white">
        <div className="max-w-[70rem] mx-auto">
          {/* Testimonials */}
          <div className="grid md:grid-cols-3 gap-6 mb-24">
            {[1, 2].map((i) => (
              <FadeIn key={i} delay={i * 100} className="h-full">
                <div className="bg-white p-10 shadow-sm relative border border-gray-100 h-full flex flex-col justify-between">
                  <div className="absolute top-6 right-8 text-6xl text-[#c9a76c] opacity-20 font-serif leading-none h-10">"</div>
                  <div>
                    <div className="text-[#c9a76c] font-bold uppercase tracking-widest text-[10px] mb-5">Good Work</div>
                    <p className="text-gray-500 text-[15px] leading-relaxed mb-8 relative z-10 font-light">The level of detail and care that went into every aspect of our home was extraordinary. OnePack exceeded our expectations in every single way.</p>
                  </div>
                  <div className="flex justify-between items-end border-t border-gray-50 pt-6">
                    <div>
                      <div className="font-bold text-gray-900 text-sm">Jeremy Lestor</div>
                      <div className="text-xs text-gray-400 font-medium">Property Buyer</div>
                    </div>
                    <div className="flex text-[#c9a76c]"><Star size={12} fill="currentColor"/><Star size={12} fill="currentColor"/><Star size={12} fill="currentColor"/><Star size={12} fill="currentColor"/><Star size={12} fill="currentColor"/></div>
                  </div>
                </div>
              </FadeIn>
            ))}
            <FadeIn delay={300} className="h-full">
              <div className="bg-[#1a1a1a] text-white p-10 shadow-sm relative h-full flex flex-col justify-between">
                <div className="absolute top-6 right-8 text-6xl text-white opacity-10 font-serif leading-none h-10">"</div>
                <div>
                  <div className="text-white font-bold uppercase tracking-widest text-[10px] mb-5">Excellent</div>
                  <p className="text-gray-300 text-[15px] leading-relaxed mb-8 relative z-10 font-light">Working with this team was the single best investment decision I've ever made. They understand both market value and design excellence.</p>
                </div>
                <div className="flex justify-between items-end border-t border-white/10 pt-6">
                  <div>
                    <div className="font-bold text-white text-sm">David M.</div>
                    <div className="text-xs text-gray-400 font-medium">Property Investor</div>
                  </div>
                  <div className="flex text-[#c9a76c]"><Star size={12} fill="currentColor"/><Star size={12} fill="currentColor"/><Star size={12} fill="currentColor"/><Star size={12} fill="currentColor"/><Star size={12} fill="currentColor"/></div>
                </div>
              </div>
            </FadeIn>
          </div>

          <FadeIn>
            <div className="mb-14 text-center md:text-left">
              <div className="text-[#c9a76c] text-[10px] font-bold tracking-widest uppercase mb-3 flex items-center justify-center md:justify-start gap-2">
                <span className="w-8 h-px bg-[#c9a76c]"></span> Offer
              </div>
              <h2 className="text-4xl md:text-5xl font-black text-gray-900 leading-tight" style={{ letterSpacing: "-0.02em" }}>
                Happy Mom, Happy &<br />Brilliant Times.
              </h2>
            </div>
          </FadeIn>

          <div className="grid md:grid-cols-12 gap-5">
            {/* Col 1 */}
            <div className="col-span-12 md:col-span-3 flex flex-col gap-5">
              <FadeIn delay={100} className="h-[240px]">
                <div className="bg-white p-8 border border-gray-100 shadow-sm flex flex-col justify-between h-full">
                  <div>
                    <div className="flex text-[#c9a76c] mb-3"><Star size={14} fill="currentColor"/><Star size={14} fill="currentColor"/><Star size={14} fill="currentColor"/><Star size={14} fill="currentColor"/><Star size={14} fill="currentColor"/></div>
                    <div className="text-[10px] font-bold text-gray-900 uppercase tracking-widest">Best Deal</div>
                  </div>
                  <div>
                    <div className="text-4xl font-black text-gray-900 mb-1" style={{ letterSpacing: "-0.03em" }}>4.9/5.0</div>
                    <div className="text-[13px] text-gray-500 font-medium">$47.65 per sq.ft starting from</div>
                  </div>
                </div>
              </FadeIn>
              <FadeIn delay={200} className="h-[320px]">
                <div className="overflow-hidden h-full cursor-pointer group relative">
                  <img src="https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=600&q=90" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"/>
                  <div className="absolute inset-0 flex items-center justify-center bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center"><ArrowRight size={20}/></div>
                  </div>
                </div>
              </FadeIn>
            </div>

            {/* Col 2 */}
            <div className="col-span-12 md:col-span-4 flex flex-col gap-5">
              <FadeIn delay={300} className="h-[280px]">
                <div className="overflow-hidden relative h-full cursor-pointer group">
                  <img src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=600&q=90" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"/>
                  <button className="absolute bottom-5 right-5 w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-lg hover:bg-gray-50 transition-colors"><ArrowRight size={20} className="text-black"/></button>
                </div>
              </FadeIn>
              <FadeIn delay={400} className="h-[280px]">
                <div className="bg-[#1a1a1a] text-white p-10 flex flex-col justify-center h-full">
                  <p className="text-[15px] font-light leading-relaxed mb-8">Our properties are thoughtfully designed to connect people with nature and the surrounding environment, creating a harmonious and vibrant living experience.</p>
                  <div className="text-[10px] font-bold uppercase tracking-widest text-white/50 hover:text-white cursor-pointer transition-colors w-fit">Read More →</div>
                </div>
              </FadeIn>
            </div>

            {/* Col 3 */}
            <div className="col-span-12 md:col-span-5 flex flex-col gap-5">
              <FadeIn delay={500} className="h-[160px]">
                <div className="bg-[#c9a76c] h-full flex flex-col justify-center p-8 text-white">
                    <div className="text-4xl font-black mb-2">200+</div>
                    <div className="text-sm">Projects Delivered</div>
                </div>
              </FadeIn>
              <div className="flex flex-col sm:flex-row gap-5 h-[400px]">
                <FadeIn delay={600} className="flex-1 h-full">
                  <div className="w-full h-full overflow-hidden relative cursor-pointer group">
                    <img src="https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=600&q=90" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"/>
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
                    <div className="absolute bottom-6 left-6 text-white font-bold text-xl leading-tight">Green Architecture<br/>Design</div>
                  </div>
                </FadeIn>
                <FadeIn delay={700} className="flex-1 h-full">
                  <div className="w-full h-full bg-white p-8 border border-gray-100 shadow-sm flex flex-col justify-center hover:shadow-md transition-shadow">
                    <p className="text-[15px] text-gray-500 leading-relaxed mb-8 font-light">OnePack real estate is your best partner in building a future where design meets sustainability.</p>
                    <div className="text-[11px] font-bold text-gray-900 uppercase tracking-widest cursor-pointer w-fit border-b-2 border-black pb-1">Explore Projects</div>
                  </div>
                </FadeIn>
              </div>
            </div>
          </div>
        </div>
      </section>

      <REFooter />
    </div>
  );
}