import React, { useState } from "react";
import RENav from "@/components/realestate/RENav";
import REFooter from "@/components/realestate/REFooter";
import { ArrowRight, ArrowUpRight, Check, ChevronDown, ChevronUp, Phone } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const GOLD = "#c9a76c";

const relatedServices = [
  { title: "Interior Design", image: "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=400&q=90" },
  { title: "Landscape Planning", image: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400&q=90" },
  { title: "Visualisation Consult", image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=400&q=90" },
  { title: "Furniture Design", image: "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400&q=90" },
  { title: "Lighting Design", image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&q=90" },
];

const processSteps = [
  { n: "01", title: "Discovery & Consultation", desc: "An in-depth conversation about your site, aspirations, lifestyle, and budget — before a single line is drawn." },
  { n: "02", title: "Concept Development", desc: "Initial sketches, mood boards, and spatial concepts presented with clarity and creative ambition." },
  { n: "03", title: "Schematic Design", desc: "Developed plans, sections, and 3D massing studies bring the concept into a clear architectural form." },
  { n: "04", title: "Design Development", desc: "All materials, finishes, systems, and specifications are selected and fully coordinated." },
  { n: "05", title: "Building Permissions", desc: "We prepare and submit all planning applications with expert navigation of regulations." },
  { n: "06", title: "Construction Oversight", desc: "Regular site visits and quality control ensure the project realised to the highest standard." },
];

const faqs = [
  { q: "What does architecture design involve?", a: "Architecture design encompasses everything from initial concept and site analysis, through planning submissions, detailed design, and construction documentation. We guide you through every stage." },
  { q: "What is the first step to working with you?", a: "The first step is a no-obligation discovery consultation, where we learn about your project, goals, timeline, and budget. From there, we propose a tailored scope of work." },
  { q: "What is the timeline for a typical project?", a: "Timelines vary by complexity. A residential commission typically spans 18–36 months from concept to completion, while smaller projects may be completed in 6–12 months." },
  { q: "Do you work internationally?", a: "Yes — we have delivered projects in 15 countries and are experienced in navigating international planning frameworks." },
  { q: "Can I see your past work?", a: "Absolutely. Our full portfolio is available on the Portfolio page, showcasing residential, luxury, and commercial projects across all service types." },
];

export default function ServiceDetail() {
  const [openFaq, setOpenFaq] = useState(0);

  return (
    <div className="bg-white text-gray-900 overflow-x-hidden" style={{ fontFamily: "'Outfit', sans-serif" }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap');`}</style>
      <RENav />

      {/* HERO */}
      <section className="relative w-full h-screen min-h-[700px] overflow-hidden bg-black">
        <img src="https://images.unsplash.com/photo-1486325212027-8081e485255e?w=1920&q=90" alt="" className="w-full h-full object-cover" style={{ filter: "brightness(0.3)" }} />
        <div className="absolute inset-0" style={{ background: "linear-gradient(to right, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0.3) 60%, transparent 100%)" }} />
        <div className="absolute inset-0 flex flex-col justify-end px-10 md:px-24 pb-20">
          <div className="text-xs font-semibold tracking-widest uppercase mb-6" style={{ color: GOLD }}>
            Services <span className="text-white/30">›</span> Architecture Design
          </div>
          <h1 className="font-black text-white leading-[0.88] mb-8" style={{ fontSize: "clamp(3.5rem, 8vw, 9rem)", letterSpacing: "-0.04em" }}>
            Everything<br />You Need to<br />Know About<br /><span style={{ color: GOLD }}>Services.</span>
          </h1>
        </div>
      </section>

      {/* CONTENT + SIDEBAR */}
      <section className="px-10 md:px-24 py-20 max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-3 gap-16">
          {/* Main content */}
          <div className="lg:col-span-2 space-y-16">

            {/* Service intro */}
            <div>
              <div className="rounded-2xl overflow-hidden mb-10" style={{ height: "440px" }}>
                <img src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1200&q=90" alt="" className="w-full h-full object-cover" />
              </div>
              <div className="flex items-center gap-3 mb-5">
                <div className="h-px w-10" style={{ background: GOLD }} />
                <span className="text-xs tracking-[0.3em] font-semibold uppercase" style={{ color: GOLD }}>Architecture Design</span>
              </div>
              <h2 className="font-black text-gray-900 leading-[0.9] mb-7" style={{ fontSize: "clamp(2rem, 4vw, 3.5rem)", letterSpacing: "-0.04em" }}>Architecture Design</h2>
              <p className="text-gray-400 font-light leading-relaxed mb-5">
                Architecture design is the practice of envisioning and realising structures that are functional, beautiful, and enduring. At OnePack, we approach every commission as an opportunity to create something genuinely exceptional — a building that responds intelligently to its site, its occupants, and its era.
              </p>
              <h3 className="font-bold text-gray-900 mb-4 text-lg">What We Offer?</h3>
              <p className="text-gray-400 font-light leading-relaxed mb-4">
                <strong className="text-gray-700 font-semibold">Feasibility & Site Analysis —</strong> Understanding the potential and constraints of every site before committing to a direction.
              </p>
              <p className="text-gray-400 font-light leading-relaxed mb-4">
                <strong className="text-gray-700 font-semibold">Concept Design —</strong> Translating your ambitions into compelling spatial ideas, expressed with clarity and creative confidence.
              </p>
              <p className="text-gray-400 font-light leading-relaxed mb-10">
                <strong className="text-gray-700 font-semibold">Architecture Design —</strong> Evolving the concept into fully developed architectural proposals, rich with detail and precision.
              </p>
              <div className="grid grid-cols-2 gap-4">
                <img src="https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=600&q=90" alt="" className="w-full rounded-2xl object-cover" style={{ height: "220px" }} />
                <img src="https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=600&q=90" alt="" className="w-full rounded-2xl object-cover" style={{ height: "220px" }} />
              </div>
            </div>

            {/* Process */}
            <div>
              <div className="flex items-center gap-3 mb-7">
                <div className="h-px w-10" style={{ background: GOLD }} />
                <span className="text-xs tracking-[0.3em] font-semibold uppercase" style={{ color: GOLD }}>How We Work</span>
              </div>
              <h2 className="font-black text-gray-900 leading-[0.9] mb-10" style={{ fontSize: "clamp(1.8rem, 3.5vw, 3rem)", letterSpacing: "-0.04em" }}>Our Design Process</h2>
              <div className="grid md:grid-cols-2 gap-4">
                {processSteps.map((step, i) => (
                  <div key={i} className="p-8 rounded-2xl bg-white border border-gray-100 shadow-sm hover:border-gray-200 transition-colors">
                    <div className="flex items-center justify-between mb-6">
                      <span className="text-xs font-semibold tracking-widest text-gray-400">{step.n}</span>
                      <ArrowUpRight className="w-4 h-4 text-gray-300" />
                    </div>
                    <h3 className="font-bold text-gray-900 mb-3 text-lg">{step.title}</h3>
                    <p className="text-gray-500 text-sm font-light leading-relaxed">{step.desc}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Why us */}
            <div className="p-10 rounded-2xl bg-black relative overflow-hidden">
              <div className="absolute inset-0 opacity-5 pointer-events-none select-none flex items-end overflow-hidden">
                <span className="font-black text-white whitespace-nowrap" style={{ fontSize: "120px", letterSpacing: "-0.04em", lineHeight: 1 }}>Why Us</span>
              </div>
              <div className="relative">
                <div className="flex items-center gap-3 mb-5">
                  <div className="h-px w-10" style={{ background: GOLD }} />
                  <span className="text-xs tracking-[0.3em] font-semibold uppercase" style={{ color: GOLD }}>Why Choose Us</span>
                </div>
                <h3 className="font-black text-white leading-[0.9] mb-8" style={{ fontSize: "clamp(1.8rem, 3vw, 2.5rem)", letterSpacing: "-0.03em" }}>The OnePack<br />Difference</h3>
                <div className="grid md:grid-cols-2 gap-x-10 gap-y-4">
                  {["End-to-end service from concept to completion", "Over 250 successful projects delivered", "Award-winning team with international reach", "Transparent process and clear communication", "Sustainable design philosophy throughout", "On-time, on-budget delivery commitment"].map((item, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5" style={{ background: "rgba(201,167,108,0.2)" }}>
                        <Check className="w-3 h-3" style={{ color: GOLD }} />
                      </div>
                      <span className="text-white/55 text-sm font-light">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* FAQ */}
            <div>
              <div className="flex items-center gap-3 mb-7">
                <div className="h-px w-10" style={{ background: GOLD }} />
                <span className="text-xs tracking-[0.3em] font-semibold uppercase" style={{ color: GOLD }}>FAQ</span>
              </div>
              <h2 className="font-black text-gray-900 leading-[0.9] mb-10" style={{ fontSize: "clamp(1.8rem, 3.5vw, 3rem)", letterSpacing: "-0.04em" }}>More Questions?</h2>
              <div className="border-t border-gray-100">
                {faqs.map((f, i) => (
                  <div key={i} className="border-b border-gray-100">
                    <button onClick={() => setOpenFaq(openFaq === i ? null : i)} className="w-full flex items-center justify-between py-7 text-left">
                      <span className="font-semibold text-gray-900 pr-8">{f.q}</span>
                      <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 transition-all" style={{ background: openFaq === i ? `linear-gradient(135deg, ${GOLD}, #a07840)` : "rgba(0,0,0,0.06)" }}>
                        {openFaq === i ? <ChevronUp className="w-4 h-4 text-white" /> : <ChevronDown className="w-4 h-4 text-gray-500" />}
                      </div>
                    </button>
                    <div className="overflow-hidden transition-all duration-400" style={{ maxHeight: openFaq === i ? "200px" : "0" }}>
                      <p className="text-gray-400 text-sm font-light leading-relaxed pb-7">{f.a}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sticky sidebar */}
          <div>
            <div className="md:sticky space-y-5" style={{ top: "100px" }}>
              {/* Related services */}
              <div className="p-7 rounded-2xl" style={{ border: "1px solid rgba(0,0,0,0.07)" }}>
                <h4 className="font-bold text-gray-900 text-sm mb-5">More Services</h4>
                <div className="space-y-3">
                  {relatedServices.map((s, i) => (
                    <Link key={i} to={createPageUrl("ServiceDetail")} className="flex items-center gap-3 group py-2 transition-all hover:pl-1">
                      <div className="w-10 h-10 rounded-xl overflow-hidden flex-shrink-0">
                        <img src={s.image} alt={s.title} className="w-full h-full object-cover" />
                      </div>
                      <span className="text-sm text-gray-600 font-light group-hover:text-gray-900 transition-colors">{s.title}</span>
                      <ArrowUpRight className="w-3.5 h-3.5 text-gray-300 group-hover:text-gray-600 ml-auto transition-colors" />
                    </Link>
                  ))}
                </div>
              </div>

              {/* CTA */}
              <div className="p-7 rounded-2xl text-white" style={{ background: `linear-gradient(135deg, ${GOLD}, #a07840)` }}>
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
                    <span className="text-white font-bold text-xs">ONE</span>
                  </div>
                  <span className="font-bold text-white text-sm">OnePack</span>
                </div>
                <p className="text-white/75 text-xs font-light leading-relaxed mb-5">We help you find the perfect property or getting value for this architecture project.</p>
                <Link to={createPageUrl("Contact")} className="w-full flex items-center justify-center gap-2 bg-white text-sm font-semibold py-3.5 rounded-xl transition-all hover:bg-white/90" style={{ color: "#a07840" }}>
                  Get In Touch <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>

              {/* Phone */}
              <div className="p-7 rounded-2xl flex items-center gap-4" style={{ border: "1px solid rgba(0,0,0,0.07)" }}>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: `rgba(201,167,108,0.1)` }}>
                  <Phone className="w-4 h-4" style={{ color: GOLD }} />
                </div>
                <div>
                  <div className="text-gray-400 text-xs font-light mb-0.5">Call Us Directly</div>
                  <div className="font-black text-gray-900 text-lg" style={{ letterSpacing: "-0.02em" }}>+123 456 789</div>
                  <div className="text-gray-400 text-xs font-light">Mon–Fri, 9am–6pm</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <REFooter />
    </div>
  );
}