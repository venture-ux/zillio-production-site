import React, { useState, useEffect } from "react";
import NeomNav from "@/components/neom/NeomNav";
import NeomFooter from "@/components/neom/NeomFooter";
import { Play } from "lucide-react";
import { motion } from "framer-motion";

const FadeIn = ({ children, delay = 0, y = 30, className = "" }) => (
  <motion.div
    initial={{ opacity: 0, y }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, margin: "-10%" }}
    transition={{ duration: 0.8, delay, ease: [0.16, 1, 0.3, 1] }}
    className={className}
  >
    {children}
  </motion.div>
);

const sections = [
  { id: "hero", label: "Intro" },
  { id: "future", label: "Future" },
  { id: "revolution", label: "Revolution" },
  { id: "experience", label: "Experience" },
  { id: "preservation", label: "Preservation" },
  { id: "quote", label: "Vision" }
];

export default function TheLine() {
  const [activeSection, setActiveSection] = useState(0);
  const [videoOpen, setVideoOpen] = useState(false);
  const [infographicIndex, setInfographicIndex] = useState(0);
  const [wondersIndex, setWondersIndex] = useState(0);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleScroll = () => {
      let current = 0;
      sections.forEach((s, i) => {
        const el = document.getElementById(s.id);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= window.innerHeight / 2) current = i;
        }
      });
      setActiveSection(current);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    const handleMouseMove = (e) => {
      setMousePos({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  return (
    <div className="bg-black text-white min-h-screen overflow-x-hidden font-sans" style={{ fontFamily: "'Outfit', sans-serif" }}>
       <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap');
       `}</style>
       <NeomNav light={false} />
       
       {/* Sidebar Dots */}
       <div className="fixed right-6 top-1/2 -translate-y-1/2 z-50 flex-col gap-4 hidden lg:flex">
          {sections.map((s, i) => (
             <button
                key={s.id}
                onClick={() => document.getElementById(s.id).scrollIntoView({ behavior: 'smooth' })}
                className="group relative flex items-center justify-end"
             >
                <span className="mr-4 text-[10px] font-bold tracking-[0.2em] uppercase opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap text-white">
                   {s.label}
                </span>
                <div 
                   className="w-1.5 h-1.5 rounded-full transition-all duration-300"
                   style={{ 
                      background: activeSection === i ? "#c9a76c" : "rgba(255,255,255,0.3)",
                      transform: activeSection === i ? "scale(1.5)" : "scale(1)",
                      boxShadow: activeSection === i ? "0 0 10px rgba(201,167,108,0.5)" : "none"
                   }}
                />
             </button>
          ))}
       </div>

       {/* HERO */}
       <section id="hero" className="relative h-screen w-full flex items-center justify-center pt-20">
          <img src="https://neom.scene7.com/is/image/neom/line-hero-thumbnail-new?wid=1920&hei=1080" alt="The Line" className="absolute inset-0 w-full h-full object-cover opacity-80" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-black/80" />
          
          <FadeIn className="relative z-10 text-center flex flex-col items-center mt-10">
             <div className="w-14 h-14 mb-8 rounded-full border border-white/20 flex items-center justify-center backdrop-blur-sm" style={{ background: "rgba(255,255,255,0.05)" }}>
                <span className="text-white font-black text-[10px] tracking-[0.2em]">NEOM</span>
             </div>
             <h1 className="text-[12vw] leading-none font-black tracking-tighter uppercase text-white mb-6" style={{ letterSpacing: "-0.04em", textShadow: "0 10px 30px rgba(0,0,0,0.3)" }}>
                THE LINE
             </h1>
             <p className="text-xs md:text-sm tracking-[0.4em] uppercase text-white/90 font-bold mb-10">
                New Wonders For The World
             </p>
             <button className="px-8 py-3.5 bg-white text-black text-xs font-bold tracking-widest uppercase rounded-full hover:bg-[#c9a76c] hover:text-white transition-colors duration-300 shadow-xl">
                Get In Touch
             </button>
          </FadeIn>
       </section>

       {/* FUTURE OF URBAN LIVING */}
       <section id="future" className="relative bg-[#f6f5f1] text-black pt-24 pb-0">
          <div className="px-6 md:px-16 lg:px-24 max-w-5xl mx-auto text-center mb-20">
             <FadeIn>
                <div className="w-px h-16 bg-[#c9a76c] mx-auto mb-8" />
                <h2 className="text-xs md:text-sm font-bold tracking-[0.3em] uppercase mb-10" style={{ color: "#c9a76c" }}>The Future of Urban Living</h2>
                <p className="text-2xl md:text-3xl font-light leading-relaxed text-gray-800 max-w-4xl mx-auto">
                   A cognitive city stretching across 170 kilometers, from the epic mountains of NEOM across inspirational desert valleys to the beautiful Red Sea. A mirrored architectural masterpiece towering 500 meters above sea level, but a land-saving 200 meters wide. THE LINE redefines the concept of urban development and what cities of the future will look like.
                </p>
             </FadeIn>
          </div>
          
          <div className="w-full relative">
             <img src="https://neom.scene7.com/is/image/neom/line-top-desktop?wid=1920&hei=692" alt="The Line view" className="w-full h-auto object-cover block" />
             <div className="absolute inset-0 bg-gradient-to-t from-[#f6f5f1] via-transparent to-transparent" />
          </div>
          
          <div className="py-24 px-6 md:px-16 lg:px-24 max-w-5xl mx-auto text-center">
             <FadeIn>
                <p className="text-xl md:text-2xl font-light leading-relaxed text-gray-700 mb-10">
                   No roads, cars or emissions, it will run on 100% renewable energy and 95% of land will be preserved for nature. People's health and wellbeing will be prioritized over transportation and infrastructure, unlike traditional cities.
                </p>
                <p className="text-xl md:text-2xl font-light leading-relaxed text-gray-700">
                   THE LINE will eventually accommodate 9 million people and will be built on a footprint of just 34 square kilometers. This will mean a reduced infrastructure footprint, creating never-before-seen efficiencies in city functions. The ideal climate all-year-round will ensure that residents can enjoy the surrounding nature.
                </p>
             </FadeIn>
          </div>

          <div className="w-full relative">
             <div className="absolute inset-0 bg-gradient-to-b from-[#f6f5f1] via-transparent to-[#050505] z-10" />
             <img src="https://neom.scene7.com/is/image/neom/line-bottom-desktop?wid=1920&hei=1065" alt="The Line exterior" className="w-full h-auto object-cover relative z-0" />
          </div>
       </section>

       {/* REVOLUTION */}
       <section id="revolution" className="py-32 bg-[#050505] text-white relative z-20">
          <FadeIn className="text-center mb-24 px-6">
             <h2 className="text-5xl md:text-7xl font-light tracking-[0.2em] uppercase leading-[1.1]" style={{ letterSpacing: "0.15em" }}>
                A Revolution <br/> in Civilization
             </h2>
          </FadeIn>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 w-full h-auto xl:h-[750px]">
             {[
               { title: "UNPARALLELED ACCESS TO NATURE", img: "https://neom.scene7.com/is/image/neom/line-blinds-1-1000x1200-50-quality?wid=768&hei=922", desc: "Our progressive design offers immediate and uninterrupted access to nature within a two-minute walk – through its diverse open spaces, suspended on multiple levels." },
               { title: "CLEAN AIR FOR EVERYONE", img: "https://neom.scene7.com/is/image/neom/line-blinds-2-1000x1200-50-quality?wid=768&hei=922", desc: "The city will be zero-carbon, due to the elimination of unecessary infrastructure, cars and roads. It will operate on 100% renewable energy." },
               { title: "MORE TIME TO SPEND WITH LOVED ONES", img: "https://neom.scene7.com/is/image/neom/line-blinds-3-1000x1200-50-quality?wid=768&hei=922", desc: "All daily essentials will be accessible within a five-minute walk and an efficient public transport network will offer a rapid end-to-end journey." },
               { title: "A PERFECT CLIMATE ALL-YEAR-ROUND", img: "https://neom.scene7.com/is/image/neom/line-blinds-4-1000x1200-50-quality?wid=768&hei=922", desc: "To ensure the establishment of microclimatic spaces, the environment has been carefully designed to allow for an optimal balance of sunlight, shade and natural ventilation." }
             ].map((c, i) => (
                <motion.div 
                   key={i} 
                   className="relative group overflow-hidden border-r border-white/5 last:border-r-0 h-[400px] xl:h-full cursor-pointer"
                   whileHover={{ scale: 1.02 }}
                   transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                >
                   <motion.img 
                      src={c.img} 
                      alt={c.title} 
                      className="absolute inset-0 w-full h-full object-cover opacity-50 group-hover:opacity-100"
                      whileHover={{ scale: 1.1 }}
                      transition={{ duration: 2, ease: "easeOut" }}
                   />
                   <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/40 to-transparent p-10 flex flex-col justify-end transition-all duration-500">
                      <motion.div 
                         className="w-12 h-[2px] bg-[#c9a76c] mb-6"
                         initial={{ scaleX: 1 }}
                         whileHover={{ scaleX: 1.5 }}
                         style={{ transformOrigin: "left" }}
                         transition={{ duration: 0.5 }}
                      />
                      <h3 className="text-xl font-bold tracking-[0.15em] uppercase mb-4 leading-snug">{c.title}</h3>
                      <div className="overflow-hidden">
                         <motion.p 
                            className="text-sm font-light text-white/80 leading-relaxed"
                            initial={{ y: "100%", opacity: 0 }}
                            whileHover={{ y: 0, opacity: 1 }}
                            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
                         >
                            {c.desc}
                         </motion.p>
                      </div>
                   </div>
                </motion.div>
             ))}
          </div>
       </section>

       {/* EXPLAINER VIDEO */}
       <section onClick={() => setVideoOpen(true)} className="relative w-full h-[70vh] min-h-[500px] flex items-center justify-center cursor-pointer group overflow-hidden">
          <img src="https://neom.scene7.com/is/image/neom/line-explainer-video-thumbnail?wid=1920&hei=1080" alt="Video thumbnail" className="absolute inset-0 w-full h-full object-cover transition-transform duration-[1.5s] group-hover:scale-105" />
          <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-colors duration-500" />
          
          <FadeIn className="relative z-10 flex flex-col items-center">
             <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mb-6 text-black group-hover:scale-110 transition-transform duration-500 shadow-2xl">
                <Play className="w-8 h-8 ml-1" fill="currentColor" />
             </div>
             <span className="text-xs font-bold tracking-[0.3em] uppercase text-white drop-shadow-lg">Play Video To Discover The Line</span>
          </FadeIn>
       </section>

       {/* VIDEO MODAL */}
       {videoOpen && (
          <div onClick={() => setVideoOpen(false)} className="fixed inset-0 bg-black/95 z-[100] flex items-center justify-center p-4 animate-in fade-in duration-300">
             <button onClick={() => setVideoOpen(false)} className="absolute top-8 right-8 text-white/70 hover:text-white text-4xl font-light z-10">×</button>
             <div className="w-full max-w-5xl aspect-video bg-black/50 rounded-lg overflow-hidden shadow-2xl">
                <div className="w-full h-full flex items-center justify-center text-white/50 text-sm">
                   Video Player (Demo)
                </div>
             </div>
          </div>
       )}

       {/* EXPERIENCE / ZIG ZAG */}
       <section id="experience" className="relative py-32 bg-[#faf9f6] text-black overflow-hidden border-y border-black/5">
          <div className="absolute inset-0 opacity-[0.04]" style={{ backgroundImage: `url(https://www.neom.com/content/dam/neom/theline/group/line-content-group-pattern.png)`, backgroundSize: "cover" }} />
          
          <div className="max-w-6xl mx-auto px-6 relative z-10 space-y-32">
             {[
               { title: "WORLD-CLASS QUALITY OF LIFE", desc: "Where the best and the brightest live. A place of unparalleled social and economic experimentation – without pollution and traffic – coupled with world-class preventative healthcare, so people will live longer.", img: "https://neom.scene7.com/is/image/neom/line-content-01-new?scl=1" },
               { title: "A PLACE TO PROTOTYPE BUSINESSES", desc: "Built around humans, not technology. A cognitive city that predicts and reacts to what we need, not the other way round. Zero-gravity living will mean a higher-density footprint creates a richer human experience, and new business opportunities – plus large-scale job creation.", img: "https://neom.scene7.com/is/image/neom/line-content-02updated?scl=1" },
               { title: "ENVIRONMENTAL SOLUTION TO URBANISM", desc: "Our zero-car environment is part of a 100% sustainable transport system – with zero pollution and zero wait time. Reduced commutes will create more time for leisure. Not paying for expenses like car insurance, fuel and parking will mean higher disposable incomes for citizens.", img: "https://neom.scene7.com/is/image/neom/line-content-03updated?scl=1" },
               { title: "A COMMUNITY INVENTING THE FUTURE", desc: "Advanced tech planning logistics and modular construction will enable efficient delivery of THE LINE. And the community will live close to, and in harmony with, nature – with 95% of land being protected for nature. Our vertical garden city will mean you are always only two mins from nature.", img: "https://neom.scene7.com/is/image/neom/line-content-04-unchanged?scl=1" }
             ].map((z, i) => (
                <div key={i} className={`flex flex-col md:flex-row items-center gap-12 lg:gap-20 ${i % 2 === 1 ? 'md:flex-row-reverse' : ''}`}>
                   <FadeIn className="flex-1" delay={0.1}>
                      <h2 className="text-[11px] font-bold tracking-[0.3em] uppercase mb-6" style={{ color: "#c9a76c" }}>{z.title}</h2>
                      <motion.div 
                         className="h-px bg-[#c9a76c] mb-8"
                         initial={{ width: "48px" }}
                         whileInView={{ width: "80px" }}
                         viewport={{ once: true }}
                         transition={{ duration: 0.8, delay: 0.3 }}
                      />
                      <p className="text-xl md:text-2xl font-light leading-relaxed text-gray-800">{z.desc}</p>
                   </FadeIn>
                   <FadeIn className="flex-1 w-full" delay={0.2}>
                      <motion.div 
                         className="overflow-hidden shadow-2xl rounded-sm group cursor-pointer"
                         whileHover={{ scale: 1.02, rotate: 0.5 }}
                         transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
                      >
                         <motion.img 
                            src={z.img} 
                            alt={z.title} 
                            className="w-full h-auto"
                            whileHover={{ scale: 1.1 }}
                            transition={{ duration: 1, ease: "easeOut" }}
                         />
                      </motion.div>
                   </FadeIn>
                </div>
             ))}
          </div>
       </section>

       {/* DESIGNED TO DELIVER NEW WONDERS - INTERACTIVE CAROUSEL */}
       <section className="bg-black relative overflow-hidden">
          <div className="relative h-screen min-h-[700px]">
             {/* Background image carousel */}
             <motion.img 
                key={wondersIndex}
                src={[
                   "https://neom.scene7.com/is/image/neom/line-c58-a-no-gradient?wid=1920&hei=1120",
                   "https://neom.scene7.com/is/image/neom/line-c58-b-no-gradient?wid=1920&hei=1120",
                   "https://neom.scene7.com/is/image/neom/line-c58-c-no-gradient?wid=1920&hei=1120",
                   "https://neom.scene7.com/is/image/neom/line-c58-d-no-gradient?wid=1920&hei=1120",
                   "https://neom.scene7.com/is/image/neom/line-c58-e-no-gradient?wid=1920&hei=1120",
                   "https://neom.scene7.com/is/image/neom/line-c58-f-no-gradient?wid=1920&hei=1120",
                   "https://neom.scene7.com/is/image/neom/line-c58-g-no-gradient?wid=1920&hei=1120",
                   "https://neom.scene7.com/is/image/neom/line-c58-h-no-gradient?wid=1920&hei=1120"
                ][wondersIndex]}
                alt="The Line wonders"
                className="absolute inset-0 w-full h-full object-cover"
                initial={{ opacity: 0, scale: 1.05 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
             />
             <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-black/40" />
             
             <div className="relative z-10 h-full flex flex-col justify-end pb-32 px-6 md:px-16 lg:px-24 max-w-7xl mx-auto">
                <motion.div
                   key={`content-${wondersIndex}`}
                   initial={{ opacity: 0, y: 30 }}
                   animate={{ opacity: 1, y: 0 }}
                   transition={{ duration: 0.8, delay: 0.2 }}
                >
                   <div className="w-12 h-px bg-[#c9a76c] mb-8" />
                   <h3 className="text-[11px] font-bold tracking-[0.3em] uppercase mb-5" style={{ color: "#c9a76c" }}>
                      {[
                         "THIS IS THE LINE",
                         "ENHANCED HUMAN LIVABILITY",
                         "MIRRORED DESIGN BLENDING IN WITH NATURE",
                         "IDEAL CLIMATE ALL-YEAR-ROUND",
                         "EVERYTHING YOU NEED WITHIN 5 MINUTES",
                         "ADVANCED CONSTRUCTION & MANUFACTURING",
                         "A 20-MINUTE JOURNEY END-TO-END",
                         "SOLUTIONS TO ENVIRONMENTAL CRISES"
                      ][wondersIndex]}
                   </h3>
                   <h2 className="text-4xl md:text-7xl font-black uppercase tracking-tighter text-white leading-none mb-12" style={{ letterSpacing: "-0.03em" }}>
                      {[
                         <>DESIGNED TO DELIVER <br/> NEW WONDERS</>,
                         <>VERTICAL <br/> URBANISM</>,
                         <>A MODEL FOR NATURE <br/> PRESERVATION</>,
                         <>REDUCED INFRASTRUCTURE <br/> FOOTPRINT</>,
                         <>ALTERNATIVE WAYS FOR <br/> HUMANITY TO LIVE</>,
                         <>UNMATCHED BUSINESS <br/> OPPORTUNITIES</>,
                         <>HIGH-SPEED LINEAR <br/> MOBILITY</>,
                         <>95% OF LAND & SEA <br/> PROTECTED FOR NATURE</>
                      ][wondersIndex]}
                   </h2>
                </motion.div>

                {/* Navigation */}
                <div className="flex items-center gap-4">
                   <button 
                      onClick={() => setWondersIndex(prev => (prev - 1 + 8) % 8)}
                      className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white/20 transition-all duration-300 hover:scale-110"
                   >
                      ←
                   </button>
                   <div className="flex gap-1.5">
                      {[0,1,2,3,4,5,6,7].map(i => (
                         <button 
                            key={i}
                            onClick={() => setWondersIndex(i)}
                            className="transition-all duration-300"
                            style={{ 
                               width: wondersIndex === i ? "32px" : "8px",
                               height: "3px",
                               background: wondersIndex === i ? "#c9a76c" : "rgba(255,255,255,0.3)",
                               borderRadius: "2px"
                            }}
                         />
                      ))}
                   </div>
                   <button 
                      onClick={() => setWondersIndex(prev => (prev + 1) % 8)}
                      className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white/20 transition-all duration-300 hover:scale-110"
                   >
                      →
                   </button>
                   <span className="text-xs text-white/50 ml-4 font-light">{wondersIndex + 1} / 8</span>
                </div>
             </div>
          </div>
       </section>

       {/* PRESERVATION */}
       <section id="preservation" className="relative h-screen min-h-[700px] flex items-end pb-32">
          <motion.img 
             src="https://neom.scene7.com/is/image/neom/line-c58-c-no-gradient?wid=1920&hei=1120" 
             alt="Nature preservation" 
             className="absolute inset-0 w-full h-full object-cover"
             style={{
                transform: `translate(${mousePos.x * 0.01}px, ${mousePos.y * 0.01}px) scale(1.05)`
             }}
             transition={{ type: "spring", stiffness: 50, damping: 20 }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-black/40" />
          
          <div className="relative z-10 max-w-7xl mx-auto w-full px-6 md:px-16 lg:px-24">
             <FadeIn>
                <div className="w-12 h-px bg-[#c9a76c] mb-8" />
                <h3 className="text-[11px] font-bold tracking-[0.3em] uppercase mb-5" style={{ color: "#c9a76c" }}>
                   Mirrored Design Blending In With Nature
                </h3>
                <h2 className="text-4xl md:text-7xl font-black uppercase tracking-tighter text-white leading-none" style={{ letterSpacing: "-0.03em" }}>
                   A Model For Nature <br/> Preservation
                </h2>
             </FadeIn>
          </div>
       </section>

       {/* INFOGRAPHIC / DIMENSIONS - INTERACTIVE CAROUSEL */}
       <section className="bg-black py-24 px-6 border-b border-white/5">
          <div className="max-w-6xl mx-auto">
             <div className="relative">
                <FadeIn>
                   <img 
                      src={[
                         "https://neom.scene7.com/is/image/neom/the-line-info-graph-en-1?scl=1",
                         "https://neom.scene7.com/is/image/neom/the-line-info-graph-en-2?wid=1024&hei=576",
                         "https://neom.scene7.com/is/image/neom/the-line-info-graph-en-3?wid=1024&hei=576",
                         "https://neom.scene7.com/is/image/neom/the-line-info-graph-en-4?wid=1024&hei=576"
                      ][infographicIndex]} 
                      alt="The Line Dimensions" 
                      className="w-full h-auto opacity-90 hover:opacity-100 transition-all duration-700" 
                   />
                </FadeIn>
                
                {/* Navigation dots */}
                <div className="flex justify-center gap-2 mt-8">
                   {[0,1,2,3].map(i => (
                      <button 
                         key={i}
                         onClick={() => setInfographicIndex(i)}
                         className="w-2 h-2 rounded-full transition-all duration-300"
                         style={{ 
                            background: infographicIndex === i ? "#c9a76c" : "rgba(255,255,255,0.2)",
                            transform: infographicIndex === i ? "scale(1.5)" : "scale(1)"
                         }}
                      />
                   ))}
                </div>

                {/* Navigation arrows */}
                {infographicIndex > 0 && (
                   <button 
                      onClick={() => setInfographicIndex(prev => prev - 1)}
                      className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white/20 transition-all duration-300 hover:scale-110"
                   >
                      ←
                   </button>
                )}
                {infographicIndex < 3 && (
                   <button 
                      onClick={() => setInfographicIndex(prev => prev + 1)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white/20 transition-all duration-300 hover:scale-110"
                   >
                      →
                   </button>
                )}
             </div>
          </div>
       </section>

       {/* QUOTE */}
       <section id="quote" className="py-32 bg-[#0a0a0a] text-white text-center px-6 relative">
          <div className="absolute inset-0 bg-[url('https://www.neom.com/content/dam/neom/theline/group/line-content-group-pattern.png')] opacity-[0.02] mix-blend-screen" />
          <FadeIn className="max-w-4xl mx-auto flex flex-col items-center relative z-10">
             <div className="mb-12 flex items-center justify-center">
                <svg viewBox="0 0 24 24" fill="currentColor" className="w-12 h-12 text-[#c9a76c]">
                   <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
                </svg>
             </div>
             <p className="text-2xl md:text-4xl font-light leading-relaxed italic mb-14 text-white/90 font-serif">
                "THE LINE will tackle the challenges facing humanity in urban life today and will shine a light on alternative ways to live. We cannot ignore the livability and environmental crises facing our world’s cities, and NEOM is at the forefront of delivering new and imaginative solutions to address these issues."
             </p>
             <div className="w-20 h-20 rounded-full overflow-hidden mb-6 mx-auto border border-[#c9a76c]/30 p-1">
                <img src="https://www.neom.com/content/dam/neom/mipim/the-line.jpeg" alt="HRH" className="w-full h-full object-cover rounded-full grayscale" />
             </div>
             <h4 className="text-xs font-bold tracking-[0.2em] uppercase text-[#c9a76c]">His Royal Highness</h4>
             <p className="text-[10px] tracking-widest uppercase text-white/40 mt-3">Mohammed bin Salman</p>
             <p className="text-[10px] tracking-widest uppercase text-white/30 mt-1 max-w-sm">Crown Prince and Chairman of the NEOM Company Board of Directors</p>
          </FadeIn>
       </section>

       <NeomFooter />
    </div>
  );
}