import React from "react";
import NeomNav from "@/components/neom/NeomNav";
import HeroSection from "@/components/neom/HeroSection";
import VideoSection from "@/components/neom/VideoSection";
import MapSection from "@/components/neom/MapSection";
import FeaturedSection from "@/components/neom/FeaturedSection";
import OxagonSection from "@/components/neom/OxagonSection";
import SectorsSection from "@/components/neom/SectorsSection";
import NewsSection from "@/components/neom/NewsSection";
import NeomFooter from "@/components/neom/NeomFooter";

export default function Home() {
  return (
    <div className="bg-black text-white font-sans overflow-x-hidden">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        body { font-family: 'Inter', sans-serif; margin: 0; padding: 0; }
        * { box-sizing: border-box; }
        .neom-btn {
          display: inline-block;
          border: 1.5px solid white;
          color: white;
          padding: 12px 28px;
          font-size: 13px;
          font-weight: 500;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          cursor: pointer;
          transition: background 0.2s, color 0.2s;
          background: transparent;
          text-decoration: none;
        }
        .neom-btn:hover {
          background: white;
          color: black;
        }
      `}</style>
      <NeomNav />
      <HeroSection />
      <VideoSection />
      <MapSection />
      <FeaturedSection />
      <OxagonSection />
      <SectorsSection />
      <NewsSection />
      <NeomFooter />
    </div>
  );
}