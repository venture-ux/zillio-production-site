import React, { useState, useEffect } from "react";
import RENav from "@/components/realestate/RENav";
import REFooter from "@/components/realestate/REFooter";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const GOLD = "#c9a76c";

const team = [
  { name: "Jeremy Lestor", role: "Principal Architect & Founder", image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=600&q=90", bio: "With over 20 years in luxury real estate, Jeremy leads with an uncompromising vision for design excellence." },
  { name: "Sarah Chen", role: "Head of Interior Design", image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=600&q=90", bio: "Featured in Architectural Digest and Elle Decor, earning international acclaim for timeless, human-centered design." },
  { name: "Marcus Webb", role: "Senior Development Lead", image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=600&q=90", bio: "Marcus oversees all construction, ensuring every detail meets our exacting standards of quality and craftsmanship." },
  { name: "Priya Nair", role: "Landscape Architecture Director", image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=600&q=90", bio: "Priya transforms outdoor spaces into living art — integrating sustainability with breathtaking aesthetic results." },
  { name: "Tom Bradley", role: "Property Investment Advisor", image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&q=90", bio: "Tom's market insights have helped over 300 clients make transformative investment decisions." },
  { name: "Lena Müller", role: "Visualisation & Tech Lead", image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=600&q=90", bio: "Lena leads digital innovation — using cutting-edge 3D visualisation to bridge imagination and reality." },
];

const values = [
  { n: "01", title: "Excellence Without Compromise", desc: "Every decision, every material, every detail is held to the highest possible standard — no exceptions." },
  { n: "02", title: "Design That Endures", desc: "We create spaces that are timeless — not trend-driven. Built to grow more beautiful with every passing year." },
  { n: "03", title: "Client-First Philosophy", desc: "Your vision is our north star. We listen deeply, communicate clearly, and deliver beyond expectation." },
  { n: "04", title: "Sustainable Innovation", desc: "Responsible design is beautiful design. We embed sustainability into every stage of our creative process." },
];

function StatCounter({ value, label }) {
  return (
    <div className="border-b border-white/10 pb-8">
      <div className="font-black text-white mb-2" style={{ fontSize: "clamp(2.5rem, 5vw, 5rem)", letterSpacing: "-0.04em", lineHeight: 1 }}>{value}</div>
      <div className="text-white/40 text-sm font-light tracking-wide">{label}</div>
    </div>
  );
}

export default function About() {
  const [activeTeam, setActiveTeam] = useState(null);

  return (
    <div className="bg-white text-gray-900 overflow-x-hidden" style={{ fontFamily: "'Inter', sans-serif" }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap');`}</style>
      <RENav />

      {/* HERO — full bleed cinematic */}
      <section className="relative w-full h-screen min-h-[700px] overflow-hidden bg-black">
        <img src="https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=1920&q=90" alt="" className="w-full h-full object-cover" style={{ filter: "brightness(0.38)" }} />
        <div className="absolute inset-0" style={{ background: "linear-gradient(to right, rgba(0,0,0,0.8) 0%, rgba(0,0,0,0.3) 60%, transparent 100%)" }} />
        <div className="absolute inset-0 flex flex-col justify-end px-10 md:px-24 pb-20">
          <div className="flex items-center gap-3 mb-6">
            <div className="h-px w-10" style={{ background: GOLD }} />
            <span className="text-xs tracking-[0.35em] font-semibold uppercase" style={{ color: GOLD }}>Our Story</span>
          </div>
          <h1 className="font-black text-white leading-[0.88] mb-8" style={{ fontSize: "clamp(4rem, 9vw, 10rem)", letterSpacing: "-0.04em" }}>
            About<br />OnePack.
          </h1>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-3xl">
            {[{ v: "250+", l: "Homes Built" }, { v: "12yr", l: "In Business" }, { v: "18", l: "Awards Won" }, { v: "15", l: "Countries" }].map((s, i) => (
              <div key={i} className="border-l-2 pl-4" style={{ borderColor: GOLD }}>
                <div className="font-black text-white text-2xl" style={{ letterSpacing: "-0.03em" }}>{s.v}</div>
                <div className="text-white/40 text-xs font-light mt-0.5">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* STORY — editorial */}
      <section className="bg-white">
        <div className="grid md:grid-cols-2" style={{ minHeight: "700px" }}>
          <div className="flex flex-col justify-center px-10 md:px-20 py-24">
            <div className="flex items-center gap-3 mb-7">
              <div className="h-px w-10" style={{ background: GOLD }} />
              <span className="text-xs tracking-[0.3em] font-semibold uppercase" style={{ color: GOLD }}>Founded 2012</span>
            </div>
            <h2 className="font-black text-gray-900 leading-[0.9] mb-8" style={{ fontSize: "clamp(2rem, 4vw, 4rem)", letterSpacing: "-0.04em" }}>
              Built on Trust,<br />Driven by Design<br />Excellence.
            </h2>
            <p className="text-gray-400 font-light leading-relaxed mb-5 max-w-md" style={{ fontSize: "0.975rem" }}>
              OnePack began with a bold mission: to redefine what exceptional real estate means. We believe homes are more than structures — they're the backdrop of life's most important moments.
            </p>
            <p className="text-gray-400 font-light leading-relaxed mb-10 max-w-md" style={{ fontSize: "0.975rem" }}>
              Over twelve years, we've grown from a boutique consultancy into a full-service firm trusted by over 500 clients across 15 countries.
            </p>
            <Link to={createPageUrl("Services")} className="group inline-flex items-center gap-3 font-semibold text-sm transition-all hover:gap-4" style={{ color: GOLD }}>
              Explore Our Services <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="relative overflow-hidden" style={{ minHeight: "500px" }}>
            <img src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=900&q=90" alt="" className="absolute inset-0 w-full h-full object-cover" />
            <div className="absolute inset-0" style={{ background: "linear-gradient(to left, transparent 60%, rgba(255,255,255,0.1))" }} />
          </div>
        </div>
      </section>

      {/* STATS — dark full bleed */}
      <section className="bg-black py-24 px-10 md:px-24 relative overflow-hidden">
        <div className="absolute inset-0 opacity-[0.04]" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Ccircle cx='1' cy='1' r='1'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")` }} />
        <div className="relative max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-12">
          <StatCounter value="250+" label="Properties Delivered" />
          <StatCounter value="500+" label="Happy Clients" />
          <StatCounter value="18" label="Design Awards" />
          <StatCounter value="15" label="Countries Served" />
        </div>
      </section>

      {/* TEAM — immersive hover */}
      <section className="bg-white py-24 px-10 md:px-24">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-end justify-between mb-16">
            <div>
              <div className="flex items-center gap-3 mb-5">
                <div className="h-px w-10" style={{ background: GOLD }} />
                <span className="text-xs tracking-[0.3em] font-semibold uppercase" style={{ color: GOLD }}>The Avengers</span>
              </div>
              <h2 className="font-black text-gray-900 leading-[0.9]" style={{ fontSize: "clamp(2rem, 4vw, 4rem)", letterSpacing: "-0.04em" }}>
                Meet the Minds<br />Behind Every Project.
              </h2>
            </div>
          </div>

          {/* Team list — hover reveal */}
          <div className="border-t border-gray-100">
            {team.map((m, i) => (
              <div key={i} className="group flex items-center justify-between py-7 border-b border-gray-100 cursor-pointer transition-all duration-300 hover:pl-4"
                onMouseEnter={() => setActiveTeam(i)} onMouseLeave={() => setActiveTeam(null)}>
                <div className="flex items-center gap-6">
                  <img src={m.image} alt={m.name} className="rounded-full object-cover transition-all duration-300" style={{ width: activeTeam === i ? "56px" : "40px", height: activeTeam === i ? "56px" : "40px", filter: activeTeam === i ? "none" : "grayscale(1) brightness(0.7)" }} />
                  <div>
                    <h3 className="font-bold text-gray-900 transition-all" style={{ fontSize: activeTeam === i ? "1.25rem" : "1rem" }}>{m.name}</h3>
                    <p className="text-xs font-medium transition-colors" style={{ color: activeTeam === i ? GOLD : "#aaa" }}>{m.role}</p>
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <p className="text-gray-400 text-sm font-light leading-relaxed max-w-sm hidden md:block transition-all duration-300" style={{ opacity: activeTeam === i ? 1 : 0 }}>{m.bio}</p>
                  <div className="w-10 h-10 rounded-full flex items-center justify-center transition-all" style={{ background: activeTeam === i ? `linear-gradient(135deg, ${GOLD}, #a07840)` : "rgba(0,0,0,0.05)" }}>
                    <ArrowUpRight className="w-4 h-4" style={{ color: activeTeam === i ? "white" : "#bbb" }} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* VALUES — editorial dark */}
      <section className="bg-black py-24 px-10 md:px-24 relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-1/2 hidden lg:block" style={{ overflow: "hidden" }}>
          <img src="https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=900&q=90" alt="" className="w-full h-full object-cover" style={{ filter: "brightness(0.35)" }} />
          <div className="absolute inset-0" style={{ background: "linear-gradient(to right, #000 0%, transparent 50%)" }} />
        </div>
        <div className="relative max-w-7xl mx-auto">
          <div className="max-w-xl">
            <div className="flex items-center gap-3 mb-7">
              <div className="h-px w-10" style={{ background: GOLD }} />
              <span className="text-xs tracking-[0.3em] font-semibold uppercase" style={{ color: GOLD }}>Our Principles</span>
            </div>
            <h2 className="font-black text-white leading-[0.9] mb-14" style={{ fontSize: "clamp(2rem, 4vw, 4rem)", letterSpacing: "-0.04em" }}>
              We Bring Bold Ideas<br />to Life with a Simple,<br />Fun Approach.
            </h2>
            <div className="space-y-0">
              {values.map((v, i) => (
                <div key={i} className="py-6 border-b border-white/10 flex items-start gap-6">
                  <span className="font-black text-2xl flex-shrink-0" style={{ color: "rgba(201,167,108,0.3)", letterSpacing: "-0.04em", lineHeight: 1 }}>{v.n}</span>
                  <div>
                    <h3 className="font-bold text-white mb-2">{v.title}</h3>
                    <p className="text-white/40 text-sm font-light leading-relaxed">{v.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FULL BLEED QUOTE */}
      <section className="relative overflow-hidden py-32">
        <img src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1920&q=90" alt="" className="absolute inset-0 w-full h-full object-cover" style={{ filter: "brightness(0.25)" }} />
        <div className="relative text-center px-10 max-w-4xl mx-auto">
          <div className="text-8xl text-white/10 font-black leading-none mb-6" style={{ fontFamily: "Georgia, serif" }}>"</div>
          <p className="font-light text-white leading-relaxed mb-10" style={{ fontSize: "clamp(1.2rem, 2.5vw, 1.8rem)" }}>
            OnePack didn't just build us a house. They understood our life — how we move, gather, work, and rest — and translated it into spaces that feel like they were made just for us.
          </p>
          <div className="flex items-center justify-center gap-4">
            <img src="https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?w=80&q=90" alt="" className="w-14 h-14 rounded-full object-cover" style={{ border: `2px solid ${GOLD}` }} />
            <div className="text-left">
              <div className="text-white font-semibold">Amanda & Robert K.</div>
              <div className="text-white/40 text-sm font-light">Long-term Clients, New York</div>
            </div>
          </div>
        </div>
      </section>

      <REFooter />
    </div>
  );
}