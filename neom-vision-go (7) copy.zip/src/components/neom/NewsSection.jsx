import React from "react";
import { ArrowRight } from "lucide-react";

const news = [
  { tag: "Press Release", title: "SAVVY GAMES GROUP AND NEOM SIGN MOU TO STRENGTHEN SAUDI ARABIA'S GAMES STARTUP PIPELINE", date: "January 26, 2026", image: "https://images.unsplash.com/photo-1612287230202-1ff1d85d1bdf?w=800&q=90" },
  { tag: "Press Release", title: "NEOM AND ABB SIGN LANDMARK AGREEMENT TO ADVANCE INDUSTRIAL AUTOMATION", date: "January 20, 2026", image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&q=90" },
  { tag: "Story", title: "NEOM BREAKS GROUND ON THE PORT OF NEOM EXPANSION PROJECT", date: "January 15, 2026", image: "https://images.unsplash.com/photo-1486325212027-8081e485255e?w=800&q=90" },
  { tag: "Innovation", title: "GREEN HYDROGEN: NEOM'S CLEAN ENERGY VISION POWERS THE CITIES OF TOMORROW", date: "January 10, 2026", image: "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?w=800&q=90" },
];

export default function NewsSection() {
  return (
    <section className="bg-black text-white border-t border-white/10">
      <div className="px-8 md:px-20 py-14 flex items-end justify-between border-b border-white/10">
        <div>
          <div className="flex items-center gap-3 mb-5">
            <div className="h-px w-8" style={{ background: "rgba(201,167,108,0.7)" }} />
            <span className="text-xs tracking-[0.3em] uppercase font-light" style={{ color: "rgba(201,167,108,0.9)" }}>News & Insights</span>
          </div>
          <h2 className="font-bold text-white" style={{ fontSize: "clamp(1.75rem, 4vw, 3.5rem)", letterSpacing: "-0.02em" }}>Latest From NEOM</h2>
        </div>
        <div className="hidden md:flex items-center gap-2 text-white/40 hover:text-white cursor-pointer transition-colors group">
          <span className="text-xs tracking-widest uppercase">All news</span>
          <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4">
        {news.map((item, i) => (
          <div key={i} className="border-r border-b border-white/10 last:border-r-0 group cursor-pointer overflow-hidden flex flex-col">
            <div className="relative overflow-hidden" style={{ height: "240px" }}>
              <img src={item.image} alt={item.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" style={{ filter: "brightness(0.65) saturate(0.8)" }} />
              <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(0,0,0,0.6) 0%, transparent 60%)" }} />
              <div className="absolute top-4 left-4">
                <span className="text-white/60 text-xs tracking-widest uppercase border border-white/20 px-2.5 py-1 backdrop-blur-sm bg-black/30">{item.tag}</span>
              </div>
            </div>
            <div className="p-7 flex flex-col flex-1">
              <h3 className="text-white text-sm font-semibold leading-snug mb-auto group-hover:text-white/75 transition-colors" style={{ lineHeight: 1.5 }}>{item.title}</h3>
              <div className="flex items-center justify-between mt-6 pt-5 border-t border-white/10">
                <span className="text-white/35 text-xs font-light">{item.date}</span>
                <ArrowRight className="w-4 h-4 text-white/30 group-hover:text-white group-hover:translate-x-1 transition-all duration-200" />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="md:hidden px-8 py-8">
        <div className="flex items-center gap-2 text-white/40 hover:text-white cursor-pointer transition-colors group">
          <span className="text-xs tracking-widest uppercase">All news</span>
          <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
        </div>
      </div>
    </section>
  );
}