import React, { useState } from "react";
import { Play, X } from "lucide-react";

export default function VideoSection() {
  const [playing, setPlaying] = useState(false);

  return (
    <section className="relative w-full bg-black overflow-hidden">
      <div className="relative w-full" style={{ aspectRatio: "21/9", minHeight: "400px" }}>
        <img src="https://images.unsplash.com/photo-1547036967-23d11aacaee0?w=1920&q=90" alt="NEOM Region" className="w-full h-full object-cover" style={{ filter: "brightness(0.5)" }} />
        <div className="absolute inset-0" style={{ background: "linear-gradient(135deg, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.2) 100%)" }} />
        <div className="absolute inset-0 opacity-5" style={{ backgroundImage: "linear-gradient(rgba(255,255,255,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.3) 1px, transparent 1px)", backgroundSize: "80px 80px" }} />

        <div className="absolute inset-0 flex flex-col items-start justify-end p-8 md:p-16 lg:p-24">
          <div className="flex items-center gap-3 mb-6">
            <div className="h-px w-12" style={{ background: "rgba(201,167,108,0.8)" }} />
            <p className="text-xs tracking-[0.35em] uppercase font-light" style={{ color: "rgba(201,167,108,0.9)" }}>The Region</p>
          </div>
          <h2 className="font-bold text-white mb-6 leading-tight" style={{ fontSize: "clamp(2rem, 5vw, 5rem)", letterSpacing: "-0.02em", maxWidth: "700px" }}>
            A LAND UNLIKE<br />ANY OTHER
          </h2>
          <p className="text-white/60 text-sm md:text-base mb-10 max-w-md font-light leading-relaxed">
            From mountains to coral reefs — NEOM spans an extraordinary diversity of landscapes that inspire a new way of living.
          </p>
          <button onClick={() => setPlaying(true)} className="flex items-center gap-4 text-white group">
            <div className="w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 group-hover:scale-110" style={{ border: "1.5px solid rgba(201,167,108,0.6)", background: "rgba(201,167,108,0.1)" }}>
              <Play className="w-4 h-4 ml-1" fill="white" />
            </div>
            <span className="text-xs tracking-[0.25em] uppercase font-light group-hover:text-white/70 transition-colors">Watch the film</span>
          </button>
        </div>
      </div>

      {playing && (
        <div className="fixed inset-0 z-50 bg-black/98 flex items-center justify-center" onClick={() => setPlaying(false)}>
          <button className="absolute top-8 right-8 text-white/50 hover:text-white transition-colors" onClick={() => setPlaying(false)}>
            <X className="w-7 h-7" />
          </button>
          <div className="w-full max-w-5xl aspect-video bg-black/60 flex items-center justify-center border border-white/5">
            <div className="text-white/20 text-sm tracking-widest uppercase">Film Loading...</div>
          </div>
        </div>
      )}
    </section>
  );
}