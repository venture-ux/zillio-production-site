import React, { useState, useEffect } from "react";
import { Search, ChevronDown, X, Menu } from "lucide-react";

const navItems = [
  { label: "ABOUT", sub: ["About NEOM", "Leadership", "Sustainability"] },
  { label: "REGIONS", sub: ["THE LINE", "Oxagon", "Trojena", "Sindalah", "Magna"] },
  { label: "OUR BUSINESS", sub: ["Energy", "Water", "Mobility", "Tech & Digital", "Tourism"] },
  { label: "NEWS", sub: ["All News", "Press Releases", "Stories", "Events"] },
  { label: "INVEST", sub: ["Why NEOM", "Investment Opportunities", "Contact"] },
  { label: "CAREERS", sub: ["Explore Careers", "Life at NEOM", "Apply Now"] },
];

export default function NeomNav() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState(null);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);

  return (
    <nav className="fixed top-0 left-0 w-full z-50 transition-all duration-500" style={{ background: scrolled ? "rgba(0,0,0,0.94)" : "linear-gradient(to bottom, rgba(0,0,0,0.55) 0%, transparent 100%)", backdropFilter: scrolled ? "blur(20px)" : "none", borderBottom: scrolled ? "1px solid rgba(255,255,255,0.06)" : "none" }}>
      <div className="flex items-center justify-between px-8 md:px-16 h-[70px]">
        <div className="flex items-center gap-3 z-10">
          <div className="w-9 h-9">
            <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
              <rect x="1" y="1" width="46" height="46" rx="3" fill="white" />
              <text x="50%" y="56%" dominantBaseline="middle" textAnchor="middle" fontSize="9" fontWeight="800" fill="#C41E3A" fontFamily="Inter, sans-serif" letterSpacing="0.5">NEOM</text>
            </svg>
          </div>
        </div>

        <ul className="hidden lg:flex items-center gap-7 xl:gap-9">
          {navItems.map((item) => (
            <li key={item.label} className="relative" onMouseEnter={() => setActiveDropdown(item.label)} onMouseLeave={() => setActiveDropdown(null)}>
              <button className="flex items-center gap-1.5 text-white text-xs font-light tracking-[0.18em] uppercase opacity-80 hover:opacity-100 transition-opacity py-2">
                {item.label}
                <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${activeDropdown === item.label ? "rotate-180" : ""}`} />
              </button>
              {activeDropdown === item.label && (
                <div className="absolute top-full left-0 mt-0 py-5 px-6 min-w-[200px]" style={{ background: "rgba(5,5,5,0.97)", backdropFilter: "blur(20px)", borderTop: "1px solid rgba(255,255,255,0.08)" }}>
                  {item.sub.map((s) => (
                    <div key={s} className="py-2.5 text-xs text-white/50 hover:text-white cursor-pointer tracking-[0.15em] uppercase transition-colors whitespace-nowrap font-light">{s}</div>
                  ))}
                </div>
              )}
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-5">
          <button className="text-white/60 hover:text-white transition-colors"><Search className="w-4 h-4" strokeWidth={1.5} /></button>
          <span className="hidden lg:block text-white/50 text-xs tracking-wider cursor-pointer hover:text-white transition-colors font-light">العربية</span>
          <button className="hidden lg:block text-white text-xs px-5 py-2.5 tracking-[0.15em] uppercase font-light hover:bg-white hover:text-black transition-all duration-250" style={{ border: "1px solid rgba(255,255,255,0.4)" }}>Get in Touch</button>
          <button className="lg:hidden text-white" onClick={() => setMobileOpen(true)}><Menu className="w-5 h-5" strokeWidth={1.5} /></button>
        </div>
      </div>

      {mobileOpen && (
        <div className="fixed inset-0 bg-black z-[100] flex flex-col p-8 overflow-y-auto">
          <div className="flex justify-between items-center mb-10">
            <div className="w-8 h-8">
              <svg viewBox="0 0 48 48" fill="none" className="w-full h-full">
                <rect x="1" y="1" width="46" height="46" rx="3" fill="white" />
                <text x="50%" y="56%" dominantBaseline="middle" textAnchor="middle" fontSize="9" fontWeight="800" fill="#C41E3A" fontFamily="Inter, sans-serif">NEOM</text>
              </svg>
            </div>
            <button onClick={() => setMobileOpen(false)} className="text-white/60 hover:text-white transition-colors"><X className="w-6 h-6" strokeWidth={1.5} /></button>
          </div>
          {navItems.map((item) => (
            <div key={item.label} className="border-b border-white/10 py-5">
              <div className="text-white text-sm font-light tracking-[0.2em] uppercase mb-4">{item.label}</div>
              {item.sub.map((s) => (
                <div key={s} className="py-2 pl-4 text-white/40 text-xs tracking-[0.15em] uppercase font-light hover:text-white/70 transition-colors">{s}</div>
              ))}
            </div>
          ))}
          <button className="mt-10 text-white text-xs px-6 py-4 tracking-[0.2em] uppercase font-light w-fit" style={{ border: "1px solid rgba(255,255,255,0.3)" }}>Get In Touch</button>
        </div>
      )}
    </nav>
  );
}