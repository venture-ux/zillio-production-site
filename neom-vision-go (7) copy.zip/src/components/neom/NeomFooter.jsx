import React from "react";

const footerLinks = {
  "About NEOM": ["About Us", "Leadership", "Sustainability", "NEOM in Numbers"],
  "Regions": ["THE LINE", "Oxagon", "Trojena", "Sindalah", "Magna"],
  "Our Business": ["Energy", "Water", "Mobility", "Tech & Digital", "Tourism"],
  "News": ["All News", "Press Releases", "Stories", "Events", "Media Kit"],
  "Invest": ["Why NEOM", "Opportunities", "Contact Invest"],
  "Careers": ["Explore Careers", "Life at NEOM", "Apply"],
};

const socialLinks = ["LinkedIn", "X", "Instagram", "YouTube", "Facebook"];

export default function NeomFooter() {
  return (
    <footer className="bg-black text-white border-t border-white/10">
      <div className="px-8 md:px-20 py-16 md:py-20">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 mb-16">
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h4 className="text-white/80 text-xs font-medium tracking-[0.2em] uppercase mb-6">{category}</h4>
              <ul className="space-y-3.5">
                {links.map((link) => (
                  <li key={link}><a href="#" className="text-white/35 text-xs hover:text-white/70 transition-colors tracking-wide font-light">{link}</a></li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="border-t border-white/10 pt-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <h4 className="text-white text-sm font-medium tracking-wider mb-2">Stay Informed</h4>
            <p className="text-white/35 text-xs font-light">Receive the latest news and updates from NEOM.</p>
          </div>
          <div className="flex gap-0 w-full md:w-auto">
            <input type="email" placeholder="Your email address" className="text-white text-xs px-5 py-3.5 flex-1 md:w-72 focus:outline-none placeholder-white/25 font-light" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.12)" }} />
            <button className="bg-white text-black text-xs px-6 py-3.5 font-medium tracking-[0.15em] uppercase hover:bg-white/90 transition-colors whitespace-nowrap">Subscribe</button>
          </div>
        </div>
      </div>
      <div className="border-t border-white/10 px-8 md:px-20 py-6 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-7 h-7">
            <svg viewBox="0 0 48 48" fill="none" className="w-full h-full">
              <rect x="1" y="1" width="46" height="46" rx="3" fill="rgba(255,255,255,0.1)" />
              <text x="50%" y="56%" dominantBaseline="middle" textAnchor="middle" fontSize="9" fontWeight="800" fill="white" fontFamily="Inter, sans-serif">NEOM</text>
            </svg>
          </div>
          <span className="text-white/30 text-xs font-light">© 2026 NEOM. All rights reserved.</span>
        </div>
        <div className="flex items-center gap-6">
          {socialLinks.map((s) => (<a key={s} href="#" className="text-white/30 text-xs hover:text-white/70 transition-colors font-light">{s}</a>))}
        </div>
        <div className="flex items-center gap-5">
          <a href="#" className="text-white/30 text-xs hover:text-white/70 transition-colors font-light">Privacy</a>
          <a href="#" className="text-white/30 text-xs hover:text-white/70 transition-colors font-light">Terms</a>
          <a href="#" className="text-white/30 text-xs hover:text-white/70 transition-colors font-light">Cookies</a>
          <span className="text-white/30 text-xs cursor-pointer hover:text-white/70 transition-colors font-light">العربية</span>
        </div>
      </div>
    </footer>
  );
}