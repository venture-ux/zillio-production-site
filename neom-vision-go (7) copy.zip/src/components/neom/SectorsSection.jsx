import React, { useState } from "react";
import { ArrowRight } from "lucide-react";

const sectors = [
  { name: "Mobility", desc: "Zero-emission transport systems — from high-speed rail to autonomous pods — creating seamless, intelligent movement through NEOM.", image: "https://images.unsplash.com/photo-1541432901042-2d8bd64b4a9b?w=800&q=90", number: "01" },
  { name: "Water", desc: "World-scale desalination powered entirely by renewables, pioneering a circular water future with zero liquid discharge.", image: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?w=800&q=90", number: "02" },
  { name: "Energy", desc: "Sun, wind and the Red Sea: NEOM's extraordinary natural resources become the foundations of a fully renewable energy ecosystem.", image: "https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?w=800&q=90", number: "03" },
  { name: "Tech & Digital", desc: "AI-powered infrastructure, 5G-native networks, and digital twin cities that adapt intelligently to the needs of every resident.", image: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&q=90", number: "04" },
  { name: "Tourism", desc: "From mountain peaks to coral reefs — NEOM offers curated experiences across landscapes that exist nowhere else on Earth.", image: "https://images.unsplash.com/photo-1476900543704-4312b650a425?w=800&q=90", number: "05" },
  { name: "Food & Agriculture", desc: "Vertical farms, hydroponic systems, and food-tech innovation — building food sovereignty in one of the world's most arid regions.", image: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800&q=90", number: "06" },
];

export default function SectorsSection() {
  const [hovered, setHovered] = useState(null);

  return (
    <section className="bg-black text-white border-t border-white/10">
      <div className="px-8 md:px-20 py-16 md:py-20 grid md:grid-cols-2 gap-10 items-end border-b border-white/10">
        <div>
          <div className="flex items-center gap-3 mb-6">
            <div className="h-px w-8" style={{ background: "rgba(201,167,108,0.7)" }} />
            <span className="text-xs tracking-[0.3em] uppercase font-light" style={{ color: "rgba(201,167,108,0.9)" }}>A Region in the Making</span>
          </div>
          <h2 className="font-bold text-white leading-tight" style={{ fontSize: "clamp(1.75rem, 4vw, 3.5rem)", letterSpacing: "-0.02em" }}>
            AN ECOSYSTEM OF<br />SECTORS &amp; INNOVATION
          </h2>
        </div>
        <div className="flex flex-col items-end gap-4">
          <p className="text-white/45 text-sm font-light leading-relaxed max-w-sm text-right">NEOM is enabled by a comprehensive network of advanced sectors, companies and strategic investments spanning multiple industries.</p>
          <div className="flex items-center gap-2 text-white/40 hover:text-white cursor-pointer transition-colors group">
            <span className="text-xs tracking-widest uppercase">Our Business</span>
            <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
        {sectors.map((sector, i) => (
          <div
            key={sector.name}
            className="relative overflow-hidden cursor-pointer group border-r border-b border-white/10"
            style={{ height: "360px" }}
            onMouseEnter={() => setHovered(i)}
            onMouseLeave={() => setHovered(null)}
          >
            <img src={sector.image} alt={sector.name} className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" style={{ filter: "brightness(0.35) saturate(0.8)" }} />
            <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0.2) 60%, transparent 100%)" }} />
            <div className="relative h-full flex flex-col justify-between p-8">
              <span className="text-white/15 font-bold" style={{ fontSize: "3.5rem", letterSpacing: "-0.04em", lineHeight: 1 }}>{sector.number}</span>
              <div>
                <h3 className="font-bold text-white text-xl mb-3" style={{ letterSpacing: "-0.01em" }}>{sector.name}</h3>
                <p className="text-white/55 text-sm font-light leading-relaxed mb-5 overflow-hidden transition-all duration-400" style={{ maxHeight: hovered === i ? "120px" : "0px", opacity: hovered === i ? 1 : 0, transition: "max-height 0.4s ease, opacity 0.3s ease" }}>{sector.desc}</p>
                <div className="flex items-center gap-2 text-white/40 group-hover:text-white/80 transition-colors">
                  <span className="text-xs tracking-widest uppercase">Explore</span>
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}