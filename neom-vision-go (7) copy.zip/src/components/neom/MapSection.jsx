import React, { useState } from "react";
import { ArrowRight } from "lucide-react";

const tabs = ["About Us", "Our Regions", "Our Nature"];

const regionData = [
  { name: "THE LINE", tag: "Linear City", image: "https://images.unsplash.com/photo-1486325212027-8081e485255e?w=1920&q=90", stats: [{ value: "170KM", label: "Length" }, { value: "9M", label: "Future Residents" }, { value: "0", label: "Carbon Emissions" }], desc: "THE LINE redefines urban life — a revolutionary mirrored city just 200 meters wide, stretching 170 kilometers through the Arabian landscape." },
  { name: "Oxagon", tag: "Industrial City", image: "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=1920&q=90", stats: [{ value: "48KM²", label: "Total Area" }, { value: "7", label: "Advanced Sectors" }, { value: "100%", label: "Clean Energy" }], desc: "Reimagining industry at the intersection of the Red Sea and global trade routes — Oxagon is the world's largest floating structure." },
  { name: "Trojena", tag: "Mountain Resort", image: "https://images.unsplash.com/photo-1519681393784-d120267933ba?w=1920&q=90", stats: [{ value: "2600M", label: "Above Sea Level" }, { value: "10°C", label: "Cooler than Gulf" }, { value: "2029", label: "Asian Winter Games" }], desc: "Perched in the Hisma mountains, Trojena offers ski slopes, adventure sports, and year-round cool temperatures — a first for the region." },
  { name: "Sindalah", tag: "Island Destination", image: "https://images.unsplash.com/photo-1559128010-7c1ad6e1b6a5?w=1920&q=90", stats: [{ value: "840", label: "Yacht Berths" }, { value: "86KM²", label: "Island Area" }, { value: "2025", label: "Opening Year" }], desc: "A world-class island experience on the Red Sea — luxury yachting, pristine beaches, and curated hospitality in an untouched setting." },
  { name: "Magna", tag: "Coastal Discovery", image: "https://images.unsplash.com/photo-1476900543704-4312b650a425?w=1920&q=90", stats: [{ value: "7", label: "Villages" }, { value: "4000HA", label: "Total Area" }, { value: "100%", label: "Renewable Energy" }], desc: "Where ancient valleys meet coral reefs — Magna is a new global tourism destination of extraordinary natural beauty." },
];

const aboutStats = [
  { value: "100+", label: "Nationalities" },
  { value: "26,500", label: "km² Land Footprint" },
  { value: "71%", label: "of Saudi population under 35" },
  { value: "10°C", label: "Cooler in mountain areas" },
];

const natureItems = [
  { name: "Marine Landscapes", image: "https://images.unsplash.com/photo-1559825481-12a05cc00344?w=1920&q=90", desc: "NEOM's coastline hosts vibrant coral ecosystems, mangroves, and rich marine biodiversity across the Red Sea." },
  { name: "Lower Desert", image: "https://images.unsplash.com/photo-1509316785289-025f5b846b35?w=1920&q=90", desc: "Vast erg deserts of golden dunes sculpted by wind over millennia — silent, ancient, and awe-inspiring." },
  { name: "Mountain Terrain", image: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1920&q=90", desc: "Dramatic granite peaks rising above 2,500 meters, blanketed in mist and cooled by fresh highland air." },
  { name: "Upper Valley", image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1920&q=90", desc: "Lush wadis carved through limestone cliffs, flowing into oases of unexpected greenery and wildlife." },
];

const natureStats = [
  { value: "41", label: "Islands" },
  { value: "468KM", label: "Coastline" },
  { value: "3", label: "Diverse Ecological Regions" },
  { value: "4.7M", label: "Plants & Shrubs Planted" },
];

export default function MapSection() {
  const [activeTab, setActiveTab] = useState(0);
  const [activeRegion, setActiveRegion] = useState(0);
  const [activeNature, setActiveNature] = useState(0);

  return (
    <section className="bg-black text-white">
      <div className="flex border-b border-white/10">
        {tabs.map((tab, i) => (
          <button key={tab} onClick={() => setActiveTab(i)} className={`flex-1 py-6 text-xs tracking-[0.25em] uppercase font-light transition-all duration-300 relative ${activeTab === i ? "text-white" : "text-white/35 hover:text-white/60"}`}>
            {tab}
            {activeTab === i && <div className="absolute bottom-0 left-0 right-0 h-px bg-white" />}
          </button>
        ))}
      </div>

      {activeTab === 0 && (
        <div>
          <div className="relative w-full overflow-hidden" style={{ height: "65vh", minHeight: "500px" }}>
            <img src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1920&q=90" alt="NEOM" className="w-full h-full object-cover" style={{ filter: "brightness(0.55)" }} />
            <div className="absolute inset-0" style={{ background: "linear-gradient(to top, #000 0%, rgba(0,0,0,0.3) 50%, transparent 100%)" }} />
          </div>
          <div className="px-8 md:px-20 py-14">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-10 mb-12 border-b border-white/10 pb-12">
              {aboutStats.map((s, i) => (
                <div key={i}>
                  <div className="font-bold text-white mb-2" style={{ fontSize: "clamp(1.5rem, 3vw, 2.5rem)", letterSpacing: "-0.02em" }}>{s.value}</div>
                  <div className="text-white/40 text-xs tracking-wide leading-snug font-light">{s.label}</div>
                </div>
              ))}
            </div>
            <div className="grid md:grid-cols-2 gap-16 items-end">
              <p className="text-white/55 text-base font-light leading-relaxed">NEOM is a bold vision of what a new future might look like — a region in northwest Saudi Arabia that will drive human progress and innovation, creating a better way to live for people and planet.</p>
              <div className="flex justify-end"><button className="neom-btn text-xs tracking-widest">About NEOM</button></div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 1 && (
        <div>
          <div className="relative w-full overflow-hidden" style={{ height: "65vh", minHeight: "500px" }}>
            <img src={regionData[activeRegion].image} alt={regionData[activeRegion].name} className="w-full h-full object-cover transition-all duration-700" style={{ filter: "brightness(0.5)" }} />
            <div className="absolute inset-0" style={{ background: "linear-gradient(to top, #000 0%, rgba(0,0,0,0.1) 60%, transparent 100%)" }} />
            <div className="absolute bottom-0 left-0 p-8 md:p-16">
              <div className="flex items-center gap-3 mb-4">
                <div className="h-px w-8" style={{ background: "rgba(201,167,108,0.8)" }} />
                <span className="text-xs tracking-[0.3em] uppercase font-light" style={{ color: "rgba(201,167,108,0.9)" }}>{regionData[activeRegion].tag}</span>
              </div>
              <h2 className="font-bold text-white mb-3" style={{ fontSize: "clamp(2.5rem, 6vw, 5rem)", letterSpacing: "-0.02em" }}>{regionData[activeRegion].name}</h2>
              <p className="text-white/55 text-sm max-w-lg font-light leading-relaxed">{regionData[activeRegion].desc}</p>
            </div>
          </div>
          <div className="flex border-b border-white/10 overflow-x-auto">
            {regionData.map((r, i) => (
              <button key={r.name} onClick={() => setActiveRegion(i)} className={`px-6 md:px-10 py-5 text-xs tracking-[0.2em] uppercase font-light whitespace-nowrap transition-all relative ${activeRegion === i ? "text-white" : "text-white/35 hover:text-white/60"}`}>
                {r.name}
                {activeRegion === i && <div className="absolute bottom-0 left-0 right-0 h-px bg-white" />}
              </button>
            ))}
          </div>
          <div className="px-8 md:px-20 py-12">
            <div className="grid grid-cols-3 gap-10 max-w-lg mb-10">
              {regionData[activeRegion].stats.map((s, i) => (
                <div key={i}>
                  <div className="font-bold text-white text-xl md:text-2xl mb-1" style={{ letterSpacing: "-0.01em" }}>{s.value}</div>
                  <div className="text-white/40 text-xs leading-snug font-light">{s.label}</div>
                </div>
              ))}
            </div>
            <div className="flex items-center gap-3 text-white/50 hover:text-white cursor-pointer transition-colors group">
              <span className="text-xs tracking-widest uppercase">Explore {regionData[activeRegion].name}</span>
              <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </div>
      )}

      {activeTab === 2 && (
        <div>
          <div className="relative w-full overflow-hidden" style={{ height: "65vh", minHeight: "500px" }}>
            <img src={natureItems[activeNature].image} alt={natureItems[activeNature].name} className="w-full h-full object-cover transition-all duration-700" style={{ filter: "brightness(0.5)" }} />
            <div className="absolute inset-0" style={{ background: "linear-gradient(to top, #000 0%, rgba(0,0,0,0.1) 60%, transparent 100%)" }} />
            <div className="absolute bottom-0 left-0 p-8 md:p-16">
              <h2 className="font-bold text-white mb-3" style={{ fontSize: "clamp(2.5rem, 6vw, 5rem)", letterSpacing: "-0.02em" }}>{natureItems[activeNature].name}</h2>
              <p className="text-white/55 text-sm max-w-lg font-light leading-relaxed">{natureItems[activeNature].desc}</p>
            </div>
          </div>
          <div className="flex border-b border-white/10 overflow-x-auto">
            {natureItems.map((n, i) => (
              <button key={n.name} onClick={() => setActiveNature(i)} className={`px-6 md:px-10 py-5 text-xs tracking-[0.2em] uppercase font-light whitespace-nowrap transition-all relative ${activeNature === i ? "text-white" : "text-white/35 hover:text-white/60"}`}>
                {n.name}
                {activeNature === i && <div className="absolute bottom-0 left-0 right-0 h-px bg-white" />}
              </button>
            ))}
          </div>
          <div className="px-8 md:px-20 py-12">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-10 mb-10">
              {natureStats.map((s, i) => (
                <div key={i}>
                  <div className="font-bold text-white text-xl md:text-2xl mb-1" style={{ letterSpacing: "-0.01em" }}>{s.value}</div>
                  <div className="text-white/40 text-xs leading-snug font-light">{s.label}</div>
                </div>
              ))}
            </div>
            <div className="flex items-center gap-3 text-white/50 hover:text-white cursor-pointer transition-colors group">
              <span className="text-xs tracking-widest uppercase">Explore Our Nature</span>
              <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </div>
      )}
    </section>
  );
}