import React, { useState, useEffect } from "react";

const slides = [
  {
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1920&q=90",
    eyebrow: "Northwest Saudi Arabia",
    title: "A NEW\nCIVILIZATION",
    subtitle: "A 26,500 km² vision — where humanity, nature and innovation converge at the edge of tomorrow.",
  },
  {
    image: "https://images.unsplash.com/photo-1518005020951-eccb494ad742?w=1920&q=90",
    eyebrow: "Oxagon",
    title: "ADVANCED\nINDUSTRY",
    subtitle: "The world's most sustainable industrial city, reimagining manufacturing on the shores of the Red Sea.",
  },
  {
    image: "https://images.unsplash.com/photo-1559128010-7c1ad6e1b6a5?w=1920&q=90",
    eyebrow: "Sindalah",
    title: "RED SEA\nLUXURY",
    subtitle: "NEOM's first island destination — a world-class yachting and tourism experience unlike any other.",
  },
];

export default function HeroSection() {
  const [current, setCurrent] = useState(0);
  const [fading, setFading] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setFading(true);
      setTimeout(() => {
        setCurrent((prev) => (prev + 1) % slides.length);
        setFading(false);
      }, 700);
    }, 7000);
    return () => clearInterval(timer);
  }, []);

  const goTo = (i) => {
    if (i === current) return;
    setFading(true);
    setTimeout(() => { setCurrent(i); setFading(false); }, 400);
  };

  const slide = slides[current];

  return (
    <section className="relative w-full h-screen min-h-[700px] overflow-hidden bg-black">
      <div className="absolute inset-0 transition-opacity duration-700" style={{ opacity: fading ? 0 : 1 }}>
        <img src={slide.image} alt={slide.title} className="w-full h-full object-cover" style={{ filter: "brightness(0.65)" }} />
        <div className="absolute inset-0" style={{ background: "linear-gradient(to right, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.2) 60%, transparent 100%)" }} />
        <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(0,0,0,0.8) 0%, transparent 50%)" }} />
      </div>

      <div className="absolute top-24 right-8 md:right-16 z-10">
        <span className="text-white/30 text-xs tracking-widest" style={{ fontSize: "10px" }}>
          {String(current + 1).padStart(2, "0")} / {String(slides.length).padStart(2, "0")}
        </span>
      </div>

      <div className="absolute inset-0 flex flex-col justify-end pb-20 md:pb-28 px-8 md:px-20 max-w-5xl transition-opacity duration-500" style={{ opacity: fading ? 0 : 1 }}>
        <p className="text-white/50 text-xs tracking-[0.3em] uppercase mb-5 font-light">{slide.eyebrow}</p>
        <h1 className="font-bold text-white leading-[0.9] mb-6" style={{ fontSize: "clamp(3.5rem, 9vw, 8rem)", letterSpacing: "-0.02em", whiteSpace: "pre-line" }}>
          {slide.title}
        </h1>
        <p className="text-white/60 font-light max-w-lg mb-10 leading-relaxed" style={{ fontSize: "clamp(0.875rem, 1.2vw, 1.1rem)" }}>
          {slide.subtitle}
        </p>
        <div className="flex items-center gap-6">
          <button className="neom-btn text-xs tracking-widest">Discover More</button>
          <button className="text-white/50 hover:text-white text-xs tracking-widest uppercase transition-colors">Watch Film →</button>
        </div>
      </div>

      <div className="absolute bottom-10 right-8 md:right-16 flex items-center gap-3 z-10">
        {slides.map((_, i) => (
          <button key={i} onClick={() => goTo(i)} className="transition-all duration-500" style={{ width: i === current ? "40px" : "6px", height: "1.5px", background: i === current ? "white" : "rgba(255,255,255,0.3)" }} />
        ))}
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-px" style={{ background: "linear-gradient(to right, transparent, rgba(201,167,108,0.4), transparent)" }} />
    </section>
  );
}