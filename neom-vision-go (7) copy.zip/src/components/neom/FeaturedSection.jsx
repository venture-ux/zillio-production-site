import React, { useState } from "react";
import { ArrowRight, Play } from "lucide-react";

const featured = [
  { tag: "Davos, Switzerland", eyebrow: "World Economic Forum 2026", title: "LEADING THE\nNEXT ERA", desc: "NEOM joined global leaders at the 56th WEF Annual Meeting, showcasing how the region is redefining the future of industry, sustainability and human progress.", cta: "Watch the sessions", image: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=1400&q=90", hasVideo: true },
  { tag: "Our Stories", eyebrow: "Conservation", title: "GUARDING THE\nRED SEA", desc: "Through pioneering techniques in coral restoration and mangrove planting, NEOM's conservation teams are reviving coastal ecosystems at unprecedented scale.", cta: "Read the story", image: "https://images.unsplash.com/photo-1559825481-12a05cc00344?w=1400&q=90", hasVideo: false },
  { tag: "Our Community", eyebrow: "NEOM Sports Club", title: "UNITED BY\nPASSION", desc: "NEOM S.C. is a growing community of athletes and fans — brought together by unity, performance and a shared belief in what sport can achieve.", cta: "Discover NEOM S.C.", image: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=1400&q=90", hasVideo: false },
];

export default function FeaturedSection() {
  const [current, setCurrent] = useState(0);
  const item = featured[current];

  return (
    <section className="bg-black text-white border-t border-white/10">
      <div className="grid md:grid-cols-2" style={{ minHeight: "580px" }}>
        <div className="flex flex-col justify-between p-8 md:p-16 lg:p-20 order-2 md:order-1">
          <div>
            <div className="flex items-center gap-3 mb-8">
              <div className="h-px w-8" style={{ background: "rgba(201,167,108,0.7)" }} />
              <span className="text-xs tracking-[0.3em] uppercase font-light" style={{ color: "rgba(201,167,108,0.9)" }}>{item.eyebrow}</span>
            </div>
            <h2 className="font-bold text-white mb-6 leading-[0.9]" style={{ fontSize: "clamp(2rem, 4.5vw, 4rem)", letterSpacing: "-0.02em", whiteSpace: "pre-line" }}>
              {item.title}
            </h2>
            <p className="text-white/50 font-light leading-relaxed mb-10 max-w-sm" style={{ fontSize: "0.9375rem" }}>{item.desc}</p>
            <div className="flex items-center gap-4">
              {item.hasVideo && (
                <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ border: "1px solid rgba(201,167,108,0.5)" }}>
                  <Play className="w-3 h-3 ml-0.5" fill="rgba(201,167,108,0.9)" />
                </div>
              )}
              <div className="flex items-center gap-2 text-white/60 hover:text-white cursor-pointer transition-colors group">
                <span className="text-xs tracking-widest uppercase">{item.cta}</span>
                <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </div>
          <div className="flex items-center gap-6 mt-12">
            <div className="flex gap-3">
              {featured.map((f, i) => (
                <button key={i} onClick={() => setCurrent(i)} style={{ opacity: i === current ? 1 : 0.3 }}>
                  <div className="w-16 h-10 overflow-hidden" style={{ border: i === current ? "1px solid rgba(255,255,255,0.3)" : "1px solid transparent" }}>
                    <img src={f.image} alt={f.title} className="w-full h-full object-cover" />
                  </div>
                </button>
              ))}
            </div>
            <div className="h-px flex-1 bg-white/10" />
            <span className="text-white/30 text-xs tracking-widest">{String(current + 1).padStart(2, "0")} / {String(featured.length).padStart(2, "0")}</span>
          </div>
        </div>
        <div className="relative overflow-hidden order-1 md:order-2" style={{ minHeight: "400px" }}>
          <img src={item.image} alt={item.title} className="w-full h-full object-cover transition-all duration-700" style={{ filter: "brightness(0.75)" }} />
          <div className="absolute inset-0" style={{ background: "linear-gradient(to right, rgba(0,0,0,0.6) 0%, transparent 50%)" }} />
          <div className="absolute top-6 left-6">
            <span className="text-white/60 text-xs tracking-widest uppercase border border-white/20 px-3 py-1.5 backdrop-blur-sm bg-black/20">{item.tag}</span>
          </div>
        </div>
      </div>
    </section>
  );
}