import React from "react";
import { ArrowRight } from "lucide-react";

const highlights = [
  { value: "100%", label: "Renewable Energy" },
  { value: "48KM²", label: "Total Footprint" },
  { value: "10K+", label: "Jobs by 2030" },
];

export default function OxagonSection() {
  return (
    <section className="bg-black text-white border-t border-white/10">
      <div className="grid md:grid-cols-2" style={{ minHeight: "600px" }}>
        <div className="relative overflow-hidden" style={{ minHeight: "400px" }}>
          <img src="https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=1400&q=90" alt="Oxagon" className="w-full h-full object-cover" style={{ filter: "brightness(0.55)" }} />
          <div className="absolute inset-0" style={{ background: "linear-gradient(to right, transparent 40%, rgba(0,0,0,0.7) 100%)" }} />
          <div className="absolute bottom-0 left-0 right-0 p-8 md:p-10">
            <div className="grid grid-cols-3 gap-6 border-t border-white/15 pt-6">
              {highlights.map((h, i) => (
                <div key={i}>
                  <div className="font-bold text-white text-xl md:text-2xl mb-1" style={{ letterSpacing: "-0.02em" }}>{h.value}</div>
                  <div className="text-white/40 text-xs font-light">{h.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="flex flex-col justify-center p-8 md:p-16 lg:p-20">
          <div className="flex items-center gap-3 mb-8">
            <div className="h-px w-8" style={{ background: "rgba(201,167,108,0.7)" }} />
            <span className="text-xs tracking-[0.3em] uppercase font-light" style={{ color: "rgba(201,167,108,0.9)" }}>Oxagon</span>
          </div>
          <h2 className="font-bold text-white mb-8 leading-tight" style={{ fontSize: "clamp(1.75rem, 4vw, 3.75rem)", letterSpacing: "-0.02em" }}>
            HOME OF ADVANCED<br />&amp; CLEAN INDUSTRIES
          </h2>
          <p className="text-white/50 font-light leading-relaxed mb-5 max-w-md" style={{ fontSize: "0.9375rem" }}>
            Strategically located where the Gulf of Aqaba meets the Red Sea, Oxagon redefines what an industrial city can be — clean, smart, and designed for human flourishing.
          </p>
          <p className="text-white/50 font-light leading-relaxed mb-10 max-w-md" style={{ fontSize: "0.9375rem" }}>
            At the Port of NEOM, expanded capabilities and a new terminal enable the seamless flow of goods at the crossroads of major global trade routes.
          </p>
          <div className="flex items-center gap-4">
            <button className="neom-btn text-xs tracking-widest">Explore Oxagon</button>
            <div className="flex items-center gap-2 text-white/40 hover:text-white cursor-pointer transition-colors group">
              <span className="text-xs tracking-widest uppercase">Watch Film</span>
              <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}