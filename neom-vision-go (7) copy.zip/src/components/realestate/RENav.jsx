import React, { useState, useEffect } from "react";
import { Search, ChevronDown, X, Menu, Phone, Mail } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const navItems = [
  { label: "Home", href: "REHome" },
  { label: "Properties", href: "Properties" },
  { label: "About", href: "About" },
  { label: "Services", href: "Services", sub: ["Architecture Design", "Interior Design", "Landscape Planning", "Visualisation Consult", "Furniture Design", "Lighting Design"] },
  { label: "Portfolio", href: "Portfolio" },
  { label: "News & Events", href: "NewsAndEvents" },
  { label: "Contact", href: "Contact" },
];

export default function RENav({ light = false }) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState(null);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);

  const bg = light
    ? scrolled ? "rgba(15,15,15,0.97)" : "rgba(255,255,255,0.98)"
    : scrolled ? "rgba(10,10,10,0.97)" : "transparent";

  const textColor = light && !scrolled ? "text-gray-900" : "text-white";

  return (
    <nav className="fixed top-0 left-0 w-full z-50 transition-all duration-400" style={{ background: bg, backdropFilter: "blur(20px)", borderBottom: scrolled ? "1px solid rgba(255,255,255,0.06)" : "none" }}>
      <div className="flex items-center justify-between px-6 md:px-12 h-[68px]">
        {/* Logo */}
        <Link to={createPageUrl("REHome")} className="flex items-center gap-2.5 z-10">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: "linear-gradient(135deg, #c9a76c, #a07840)" }}>
            <span className="text-white font-bold text-xs tracking-tight">ONE</span>
          </div>
          <span className={`font-bold text-sm tracking-wide ${textColor} transition-colors`}>OnePack</span>
        </Link>

        {/* Desktop Nav */}
        <ul className="hidden lg:flex items-center gap-6 xl:gap-8">
          {navItems.map((item) => (
            <li key={item.label} className="relative" onMouseEnter={() => setActiveDropdown(item.label)} onMouseLeave={() => setActiveDropdown(null)}>
              <Link to={createPageUrl(item.href || "REHome")} className={`flex items-center gap-1 text-xs font-medium tracking-wide uppercase transition-colors ${textColor} opacity-70 hover:opacity-100`}>
                {item.label}
                {item.sub && <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${activeDropdown === item.label ? "rotate-180" : ""}`} />}
              </Link>
              {item.sub && activeDropdown === item.label && (
                <div className="absolute top-full left-0 mt-1 py-3 px-0 min-w-[220px] rounded-xl shadow-2xl overflow-hidden" style={{ background: "rgba(10,10,10,0.97)", border: "1px solid rgba(255,255,255,0.08)" }}>
                  {item.sub.map((s) => (
                    <div key={s} className="px-5 py-2.5 text-xs text-white/50 hover:text-white hover:bg-white/5 cursor-pointer tracking-wide transition-colors whitespace-nowrap">{s}</div>
                  ))}
                </div>
              )}
            </li>
          ))}
        </ul>

        {/* Right Actions */}
        <div className="flex items-center gap-4">
          <div className="hidden md:flex items-center gap-2 text-xs" style={{ color: "#c9a76c" }}>
            <Phone className="w-3.5 h-3.5" />
            <span className="font-medium tracking-wide">+123 456 789</span>
          </div>
          <Link to={createPageUrl("Contact")} className="hidden lg:block text-white text-xs px-5 py-2.5 rounded-full font-medium tracking-wide transition-all hover:opacity-90" style={{ background: "linear-gradient(135deg, #c9a76c, #a07840)" }}>
            Get In Touch
          </Link>
          <button className="lg:hidden text-white" onClick={() => setMobileOpen(true)}>
            <Menu className="w-5 h-5" strokeWidth={1.5} />
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="fixed inset-0 z-[100] flex flex-col p-8 overflow-y-auto" style={{ background: "rgba(8,8,8,0.99)" }}>
          <div className="flex justify-between items-center mb-10">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: "linear-gradient(135deg, #c9a76c, #a07840)" }}>
                <span className="text-white font-bold text-xs">ONE</span>
              </div>
              <span className="text-white font-bold text-sm">OnePack</span>
            </div>
            <button onClick={() => setMobileOpen(false)} className="text-white/60 hover:text-white">
              <X className="w-6 h-6" strokeWidth={1.5} />
            </button>
          </div>
          {navItems.map((item) => (
            <div key={item.label} className="border-b border-white/10 py-4">
              <Link to={createPageUrl(item.href || "REHome")} onClick={() => setMobileOpen(false)} className="text-white text-sm font-medium tracking-wide uppercase block mb-2">{item.label}</Link>
              {item.sub?.map((s) => (
                <div key={s} className="py-1.5 pl-4 text-white/40 text-xs tracking-wide hover:text-white/70 transition-colors">{s}</div>
              ))}
            </div>
          ))}
          <Link to={createPageUrl("Contact")} onClick={() => setMobileOpen(false)} className="mt-8 text-white text-xs px-6 py-3.5 rounded-full font-medium text-center" style={{ background: "linear-gradient(135deg, #c9a76c, #a07840)" }}>
            Get In Touch
          </Link>
        </div>
      )}
    </nav>
  );
}