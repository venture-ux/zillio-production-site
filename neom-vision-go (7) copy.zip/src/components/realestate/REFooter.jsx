import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Phone, Mail, MapPin } from "lucide-react";

const footerCols = [
  { title: "OnePack", links: ["About Us", "Our Team", "Careers", "News & Blog"] },
  { title: "Services", links: ["Architecture Design", "Interior Design", "Landscape Planning", "Visualisation", "Furniture Design"] },
  { title: "Portfolio", links: ["Residential", "Commercial", "Luxury Homes", "Renovations"] },
  { title: "Get In Touch", contact: true },
];

export default function REFooter() {
  return (
    <footer style={{ background: "#0a0a0a" }} className="text-white border-t border-white/5">
      {/* Big brand watermark */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 flex items-end justify-center pointer-events-none select-none overflow-hidden" style={{ paddingBottom: "0px" }}>
          <span className="font-black text-white/[0.03] whitespace-nowrap" style={{ fontSize: "clamp(80px, 18vw, 200px)", letterSpacing: "-0.04em", lineHeight: 1 }}>REAL ESTATE GRO.</span>
        </div>
        <div className="relative px-8 md:px-16 lg:px-24 pt-16 pb-20 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand col */}
          <div>
            <div className="flex items-center gap-2.5 mb-6">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: "linear-gradient(135deg, #c9a76c, #a07840)" }}>
                <span className="text-white font-bold text-xs tracking-tight">ONE</span>
              </div>
              <span className="text-white font-bold text-base tracking-wide">OnePack</span>
            </div>
            <p className="text-white/35 text-xs font-light leading-relaxed mb-6 max-w-[220px]">
              We help you find the perfect property or getting value for your investment.
            </p>
            <div className="space-y-3">
              <div className="flex items-center gap-2.5 text-xs text-white/40 font-light">
                <Phone className="w-3.5 h-3.5 flex-shrink-0" style={{ color: "#c9a76c" }} />
                <span>+123 456 789</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs text-white/40 font-light">
                <Mail className="w-3.5 h-3.5 flex-shrink-0" style={{ color: "#c9a76c" }} />
                <span>hello@onepack.com</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs text-white/40 font-light">
                <MapPin className="w-3.5 h-3.5 flex-shrink-0" style={{ color: "#c9a76c" }} />
                <span>123 Main Street, NY 10001</span>
              </div>
            </div>
          </div>

          {/* Links cols */}
          {[
            { title: "Company", links: ["About Us", "Our Team", "Careers", "News & Blog", "FAQ"] },
            { title: "Services", links: ["Architecture Design", "Interior Design", "Landscape Planning", "Visualisation", "Furniture Design"] },
            { title: "Quick Links", links: ["Portfolio", "Properties", "Our Process", "Testimonials", "Contact"] },
          ].map((col) => (
            <div key={col.title}>
              <h4 className="text-white text-xs font-semibold tracking-[0.18em] uppercase mb-5">{col.title}</h4>
              <ul className="space-y-3">
                {col.links.map((link) => (
                  <li key={link}><a href="#" className="text-white/35 text-xs font-light hover:text-white/70 transition-colors tracking-wide">{link}</a></li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom bar */}
      <div className="px-8 md:px-16 py-5 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-3">
        <span className="text-white/25 text-xs font-light">© 2026 OnePack. All rights reserved.</span>
        <div className="flex items-center gap-5">
          {["Privacy Policy", "Terms of Service", "Cookie Policy"].map((l) => (
            <a key={l} href="#" className="text-white/25 text-xs font-light hover:text-white/50 transition-colors">{l}</a>
          ))}
        </div>
      </div>
    </footer>
  );
}