import React, { useState, useEffect } from "react";

export default function SideScrollDots({ sections = [] }) {
  const [active, setActive] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY;
      const windowH = window.innerHeight;
      let current = 0;
      sections.forEach((id, i) => {
        const el = document.getElementById(id);
        if (el && el.offsetTop - windowH / 2 <= scrollY) current = i;
      });
      setActive(current);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [sections]);

  const scrollTo = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="fixed right-5 top-1/2 -translate-y-1/2 z-40 flex flex-col gap-2.5">
      {sections.map((id, i) => (
        <button
          key={id}
          onClick={() => scrollTo(id)}
          className="w-2 h-2 rounded-full transition-all duration-300"
          style={{ background: i === active ? "#c9a76c" : "rgba(255,255,255,0.3)", transform: i === active ? "scale(1.4)" : "scale(1)" }}
        />
      ))}
    </div>
  );
}